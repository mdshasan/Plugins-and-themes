<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

delete_option( 'wpes_settings' );
delete_option( 'wpes_snapshots' );
delete_option( 'wpes_current_state' );
delete_option( 'wpes_file_baseline' );
delete_option( 'wpes_last_snapshot' );
wp_clear_scheduled_hook( 'wpes_scheduled_snapshot' );
