<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPES_Snapshot {

    public static function create( $source = 'automatic' ) {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $previous = get_option( 'wpes_current_state', array() );
        $current  = self::collect();
        $changes  = self::compare( $previous, $current );

        $snapshot = array(
            'id'      => wp_generate_uuid4(),
            'created' => current_time( 'timestamp' ),
            'source'  => sanitize_key( $source ),
            'changes' => $changes,
            'summary' => self::summary( $changes ),
            'state'   => array(
                'environment' => $current['environment'],
                'plugins'     => $current['plugins'],
                'themes'      => $current['themes'],
                'users'       => $current['users'],
                'options'     => $current['options'],
                'tables'      => $current['tables'],
                'cron'        => $current['cron'],
                'files'       => $current['files'],
            ),
        );

        $snapshots = get_option( 'wpes_snapshots', array() );
        $snapshots = is_array( $snapshots ) ? $snapshots : array();
        array_unshift( $snapshots, $snapshot );

        $settings = get_option( 'wpes_settings', array() );
        $retention = isset( $settings['retention'] ) ? absint( $settings['retention'] ) : 30;
        $retention = max( 2, min( 100, $retention ) );
        $snapshots = array_slice( $snapshots, 0, $retention );

        update_option( 'wpes_snapshots', $snapshots, false );
        update_option( 'wpes_current_state', $current, false );
        update_option( 'wpes_last_snapshot', $snapshot['created'], false );

        return $snapshot;
    }

    public static function collect() {
        global $wpdb;

        $plugins = get_plugins();
        $plugin_state = array();
        foreach ( $plugins as $file => $plugin ) {
            $plugin_state[ $file ] = array(
                'name'    => isset( $plugin['Name'] ) ? sanitize_text_field( $plugin['Name'] ) : $file,
                'version' => isset( $plugin['Version'] ) ? sanitize_text_field( $plugin['Version'] ) : '',
                'active'  => is_plugin_active( $file ),
            );
        }
        ksort( $plugin_state );

        $themes = array();
        foreach ( wp_get_themes() as $stylesheet => $theme ) {
            $themes[ $stylesheet ] = array(
                'name'    => $theme->get( 'Name' ),
                'version' => $theme->get( 'Version' ),
                'active'  => ( get_stylesheet() === $stylesheet ),
            );
        }
        ksort( $themes );

        $users = array();
        $user_query = new WP_User_Query(
            array(
                'fields'  => array( 'ID', 'user_login', 'user_email', 'user_registered' ),
                'orderby' => 'ID',
                'order'   => 'ASC',
            )
        );
        foreach ( $user_query->get_results() as $user ) {
            $roles = get_userdata( $user->ID )->roles;
            sort( $roles );
            $users[ (string) $user->ID ] = array(
                'login'      => sanitize_user( $user->user_login, true ),
                'email_hash' => hash( 'sha256', strtolower( (string) $user->user_email ) ),
                'roles'      => $roles,
                'registered' => $user->user_registered,
            );
        }

        $important_keys = array(
            'siteurl',
            'home',
            'admin_email',
            'active_plugins',
            'template',
            'stylesheet',
            'permalink_structure',
            'blog_public',
            'users_can_register',
            'default_role',
            'WPLANG',
        );
        $options = array();
        foreach ( $important_keys as $key ) {
            $value = get_option( $key, null );
            if ( is_array( $value ) ) {
                $value = wp_json_encode( $value );
            } elseif ( is_object( $value ) ) {
                $value = wp_json_encode( $value );
            } else {
                $value = (string) $value;
            }
            if ( 'admin_email' === $key ) {
                $value = hash( 'sha256', strtolower( $value ) );
            }
            $options[ $key ] = array( 'hash' => hash( 'sha256', $value ) );
        }

        $tables = array();
        $like = $wpdb->esc_like( $wpdb->prefix ) . '%';
        $table_names = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );
        foreach ( $table_names as $table ) {
            $columns = $wpdb->get_results( 'DESCRIBE `' . str_replace( '`', '``', $table ) . '`', ARRAY_A );
            $schema = array();
            foreach ( $columns as $column ) {
                $schema[] = array( $column['Field'], $column['Type'], $column['Null'], $column['Key'] );
            }
            $tables[ $table ] = hash( 'sha256', wp_json_encode( $schema ) );
        }
        ksort( $tables );

        $cron = self::cron_state();

        return array(
            'environment' => array(
                'wordpress'       => get_bloginfo( 'version' ),
                'php'             => PHP_VERSION,
                'memory_limit'    => ini_get( 'memory_limit' ),
                'language'        => get_locale(),
                'timezone'        => wp_timezone_string(),
                'home'            => home_url(),
                'siteurl'         => site_url(),
                'debug'           => defined( 'WP_DEBUG' ) && WP_DEBUG,
                'multisite'       => is_multisite(),
                'active_theme'    => wp_get_theme()->get( 'Name' ),
                'active_theme_ver'=> wp_get_theme()->get( 'Version' ),
            ),
            'plugins' => $plugin_state,
            'themes'  => $themes,
            'users'   => $users,
            'options' => $options,
            'tables'  => $tables,
            'cron'    => $cron,
            'files'   => WPES_Files::scan(),
        );
    }

    private static function cron_state() {
        $cron = _get_cron_array();
        $state = array();
        if ( is_array( $cron ) ) {
            foreach ( $cron as $timestamp => $hooks ) {
                foreach ( $hooks as $hook => $events ) {
                    foreach ( $events as $key => $event ) {
                        $state[ $hook . '|' . $key ] = array(
                            'timestamp' => (int) $timestamp,
                            'schedule'  => isset( $event['schedule'] ) ? (string) $event['schedule'] : '',
                        );
                    }
                }
            }
        }
        ksort( $state );
        return $state;
    }

    private static function compare( $old, $new ) {
        $changes = array();
        if ( empty( $old ) ) {
            $changes[] = self::event( 'info', 'baseline', 'Initial baseline created.' );
            return $changes;
        }

        $old_env = isset( $old['environment'] ) ? $old['environment'] : array();
        foreach ( $new['environment'] as $key => $value ) {
            if ( isset( $old_env[ $key ] ) && $old_env[ $key ] !== $value ) {
                $severity = in_array( $key, array( 'home', 'siteurl', 'debug' ), true ) ? 'high' : 'info';
                $changes[] = self::event( $severity, 'environment', sprintf( '%s changed: %s → %s', $key, $old_env[ $key ], $value ) );
            }
        }

        self::compare_plugins( $changes, $old['plugins'], $new['plugins'] );
        self::compare_themes( $changes, $old['themes'], $new['themes'] );
        self::compare_users( $changes, $old['users'], $new['users'] );
        self::compare_hash_map( $changes, 'option', $old['options'], $new['options'], 'high' );
        self::compare_hash_map( $changes, 'database_table', $old['tables'], $new['tables'], 'high' );
        self::compare_cron( $changes, $old['cron'], $new['cron'] );

        // File state is stored inside every snapshot. Comparing the previous
        // snapshot's file state avoids relying on a separate mutable baseline,
        // which could otherwise cause missed changes or comparisons against the
        // wrong point in time.
        $old_files = isset( $old['files'] ) ? $old['files'] : array();
        $file_changes = WPES_Files::compare( $old_files, $new['files'] );
        foreach ( $file_changes as $file_change ) {
            $changes[] = self::event(
                $file_change['severity'],
                'file',
                sprintf( '%s %s: %s', ucfirst( $file_change['kind'] ), $file_change['type'], $file_change['path'] ),
                array( 'path' => $file_change['path'], 'change' => $file_change['type'], 'kind' => $file_change['kind'] )
            );
        }

        return $changes;
    }

    private static function compare_plugins( &$changes, $old, $new ) {
        foreach ( $new as $file => $plugin ) {
            if ( ! isset( $old[ $file ] ) ) {
                $changes[] = self::event( 'warning', 'plugin', 'Plugin installed: ' . $plugin['name'], array( 'plugin' => $file ) );
                continue;
            }
            if ( $old[ $file ]['version'] !== $plugin['version'] ) {
                $changes[] = self::event( 'info', 'plugin', sprintf( 'Plugin updated: %s (%s → %s)', $plugin['name'], $old[ $file ]['version'], $plugin['version'] ) );
            }
            if ( $old[ $file ]['active'] !== $plugin['active'] ) {
                $changes[] = self::event( 'warning', 'plugin', sprintf( 'Plugin %s: %s', $plugin['active'] ? 'activated' : 'deactivated', $plugin['name'] ) );
            }
        }
        foreach ( $old as $file => $plugin ) {
            if ( ! isset( $new[ $file ] ) ) {
                $changes[] = self::event( 'warning', 'plugin', 'Plugin removed: ' . $plugin['name'] );
            }
        }
    }

    private static function compare_themes( &$changes, $old, $new ) {
        foreach ( $new as $slug => $theme ) {
            if ( ! isset( $old[ $slug ] ) ) {
                $changes[] = self::event( 'warning', 'theme', 'Theme installed: ' . $theme['name'] );
                continue;
            }
            if ( $old[ $slug ]['version'] !== $theme['version'] ) {
                $changes[] = self::event( 'info', 'theme', sprintf( 'Theme updated: %s (%s → %s)', $theme['name'], $old[ $slug ]['version'], $theme['version'] ) );
            }
            if ( $old[ $slug ]['active'] !== $theme['active'] && $theme['active'] ) {
                $changes[] = self::event( 'warning', 'theme', 'Theme activated: ' . $theme['name'] );
            }
        }
        foreach ( $old as $slug => $theme ) {
            if ( ! isset( $new[ $slug ] ) ) {
                $changes[] = self::event( 'warning', 'theme', 'Theme removed: ' . $theme['name'] );
            }
        }
    }

    private static function compare_users( &$changes, $old, $new ) {
        foreach ( $new as $id => $user ) {
            if ( ! isset( $old[ $id ] ) ) {
                $severity = in_array( 'administrator', $user['roles'], true ) ? 'critical' : 'warning';
                $changes[] = self::event( $severity, 'user', sprintf( 'User added: %s (%s)', $user['login'], implode( ', ', $user['roles'] ) ) );
                continue;
            }
            if ( $old[ $id ]['roles'] !== $user['roles'] ) {
                $severity = in_array( 'administrator', $user['roles'], true ) ? 'critical' : 'high';
                $changes[] = self::event( $severity, 'user', sprintf( 'User role changed: %s (%s → %s)', $user['login'], implode( ', ', $old[ $id ]['roles'] ), implode( ', ', $user['roles'] ) ) );
            }
            if ( $old[ $id ]['email_hash'] !== $user['email_hash'] ) {
                $changes[] = self::event( 'warning', 'user', 'User email changed: ' . $user['login'] );
            }
        }
        foreach ( $old as $id => $user ) {
            if ( ! isset( $new[ $id ] ) ) {
                $changes[] = self::event( 'warning', 'user', 'User removed: ' . $user['login'] );
            }
        }
    }

    private static function compare_cron( &$changes, $old, $new ) {
        // The plugin owns this event. Its internal cron key/timestamp can change
        // when the schedule is recreated, so it must not appear as an incident.
        foreach ( array( &$old, &$new ) as &$cron_state ) {
            if ( ! is_array( $cron_state ) ) {
                $cron_state = array();
                continue;
            }
            foreach ( array_keys( $cron_state ) as $key ) {
                if ( 0 === strpos( (string) $key, 'wpes_scheduled_snapshot|' ) ) {
                    unset( $cron_state[ $key ] );
                }
            }
        }
        unset( $cron_state );

        self::compare_hash_map( $changes, 'cron', $old, $new, 'warning' );
    }

    private static function compare_hash_map( &$changes, $type, $old, $new, $severity ) {
        foreach ( $new as $key => $value ) {
            $old_value = isset( $old[ $key ] ) ? $old[ $key ] : null;
            $new_hash = is_array( $value ) && isset( $value['hash'] ) ? $value['hash'] : wp_json_encode( $value );
            $old_hash = is_array( $old_value ) && isset( $old_value['hash'] ) ? $old_value['hash'] : wp_json_encode( $old_value );
            if ( null === $old_value ) {
                $changes[] = self::event( $severity, $type, sprintf( 'New %s detected: %s', $type, $key ) );
            } elseif ( $old_hash !== $new_hash ) {
                $changes[] = self::event( $severity, $type, sprintf( '%s changed: %s', ucfirst( str_replace( '_', ' ', $type ) ), $key ) );
            }
        }
        foreach ( $old as $key => $value ) {
            if ( ! isset( $new[ $key ] ) ) {
                $changes[] = self::event( $severity, $type, sprintf( '%s removed: %s', ucfirst( str_replace( '_', ' ', $type ) ), $key ) );
            }
        }
    }

    private static function event( $severity, $type, $message, $data = array() ) {
        return array(
            'severity' => $severity,
            'type'     => $type,
            'message'  => wp_strip_all_tags( $message ),
            'data'     => $data,
        );
    }

    private static function summary( $changes ) {
        $summary = array( 'critical' => 0, 'high' => 0, 'warning' => 0, 'info' => 0 );
        foreach ( $changes as $change ) {
            if ( isset( $summary[ $change['severity'] ] ) ) {
                $summary[ $change['severity'] ]++;
            }
        }
        return $summary;
    }

    public static function get_all() {
        $items = get_option( 'wpes_snapshots', array() );
        return is_array( $items ) ? $items : array();
    }

    public static function get( $id ) {
        foreach ( self::get_all() as $snapshot ) {
            if ( isset( $snapshot['id'] ) && (string) $snapshot['id'] === (string) $id ) {
                return $snapshot;
            }
        }
        return null;
    }

    public static function delete( $id ) {
        $snapshots = self::get_all();
        $snapshots = array_values( array_filter( $snapshots, function ( $snapshot ) use ( $id ) {
            return ! isset( $snapshot['id'] ) || (string) $snapshot['id'] !== (string) $id;
        } ) );
        update_option( 'wpes_snapshots', $snapshots, false );
    }
}
