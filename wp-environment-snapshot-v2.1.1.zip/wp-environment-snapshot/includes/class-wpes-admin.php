<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPES_Admin {

    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
        add_action( 'admin_post_wpes_create_snapshot', array( __CLASS__, 'create_snapshot' ) );
        add_action( 'admin_post_wpes_delete_snapshot', array( __CLASS__, 'delete_snapshot' ) );
        add_action( 'admin_post_wpes_save_settings', array( __CLASS__, 'save_settings' ) );
        add_action( 'admin_post_wpes_reset_baseline', array( __CLASS__, 'reset_baseline' ) );
    }

    public static function menu() {
        add_management_page(
            __( 'Environment Snapshots', 'wp-environment-snapshot' ),
            __( 'Environment Snapshots', 'wp-environment-snapshot' ),
            'manage_options',
            'wp-environment-snapshot',
            array( __CLASS__, 'page' )
        );
    }

    public static function assets( $hook ) {
        if ( 'tools_page_wp-environment-snapshot' !== $hook ) {
            return;
        }
        wp_enqueue_style( 'wpes-admin', WPES_URL . 'assets/css/admin.css', array(), WPES_VERSION );
    }

    public static function create_snapshot() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to do this.', 'wp-environment-snapshot' ) );
        }
        check_admin_referer( 'wpes_create_snapshot' );
        WPES_Snapshot::create( 'manual' );
        wp_safe_redirect( self::url( array( 'message' => 'created' ) ) );
        exit;
    }

    public static function delete_snapshot() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to do this.', 'wp-environment-snapshot' ) );
        }
        $id = isset( $_GET['id'] ) ? sanitize_text_field( wp_unslash( $_GET['id'] ) ) : '';
        check_admin_referer( 'wpes_delete_' . $id );
        WPES_Snapshot::delete( $id );
        wp_safe_redirect( self::url( array( 'message' => 'deleted' ) ) );
        exit;
    }

    public static function save_settings() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to do this.', 'wp-environment-snapshot' ) );
        }
        check_admin_referer( 'wpes_save_settings' );

        $interval = isset( $_POST['interval'] ) ? absint( $_POST['interval'] ) : 12;
        $interval = max( 1, min( 168, $interval ) );
        $retention = isset( $_POST['retention'] ) ? absint( $_POST['retention'] ) : 30;
        $retention = max( 2, min( 100, $retention ) );
        $enabled = isset( $_POST['enabled'] ) ? 1 : 0;

        update_option( 'wpes_settings', array( 'interval' => (string) $interval, 'retention' => $retention, 'enabled' => $enabled ), false );
        wpes_schedule_event();

        wp_safe_redirect( self::url( array( 'message' => 'settings' ) ) );
        exit;
    }

    public static function reset_baseline() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to do this.', 'wp-environment-snapshot' ) );
        }
        check_admin_referer( 'wpes_reset_baseline' );
        delete_option( 'wpes_current_state' );
        delete_option( 'wpes_file_baseline' );
        wp_safe_redirect( self::url( array( 'message' => 'reset' ) ) );
        exit;
    }

    private static function url( $args = array() ) {
        return add_query_arg( $args, admin_url( 'tools.php?page=wp-environment-snapshot' ) );
    }

    public static function page() {
        $snapshots = WPES_Snapshot::get_all();
        $settings = get_option( 'wpes_settings', array( 'interval' => '12', 'retention' => 30, 'enabled' => 1 ) );
        $next = wp_next_scheduled( 'wpes_scheduled_snapshot' );
        $compare_id = isset( $_GET['compare'] ) ? sanitize_text_field( wp_unslash( $_GET['compare'] ) ) : '';
        $compare = $compare_id ? WPES_Snapshot::get( $compare_id ) : null;
        ?>
        <div class="wrap wpes-wrap">
            <h1><?php esc_html_e( 'WP Environment Snapshot', 'wp-environment-snapshot' ); ?></h1>
            <p><?php esc_html_e( 'Monitor important WordPress environment, database, cron, user, and PHP/configuration-file changes so you can investigate what changed before a site broke or was compromised.', 'wp-environment-snapshot' ); ?></p>

            <?php self::notice(); ?>

            <div class="wpes-grid">
                <div class="wpes-card">
                    <h2><?php esc_html_e( 'Automatic Monitoring', 'wp-environment-snapshot' ); ?></h2>
                    <p><strong><?php esc_html_e( 'Status:', 'wp-environment-snapshot' ); ?></strong> <?php echo ! empty( $settings['enabled'] ) ? esc_html__( 'Enabled', 'wp-environment-snapshot' ) : esc_html__( 'Disabled', 'wp-environment-snapshot' ); ?></p>
                    <p><strong><?php esc_html_e( 'Interval:', 'wp-environment-snapshot' ); ?></strong> <?php printf( esc_html__( 'Every %d hours', 'wp-environment-snapshot' ), absint( $settings['interval'] ) ); ?></p>
                    <p><strong><?php esc_html_e( 'Last snapshot:', 'wp-environment-snapshot' ); ?></strong> <?php echo ! empty( $snapshots[0]['created'] ) ? esc_html( wp_date( 'Y-m-d H:i:s', $snapshots[0]['created'] ) ) : esc_html__( 'Never', 'wp-environment-snapshot' ); ?></p>
                    <p><strong><?php esc_html_e( 'Next snapshot:', 'wp-environment-snapshot' ); ?></strong> <?php echo $next ? esc_html( wp_date( 'Y-m-d H:i:s', $next ) ) : esc_html__( 'Not scheduled', 'wp-environment-snapshot' ); ?></p>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="wpes_create_snapshot">
                        <?php wp_nonce_field( 'wpes_create_snapshot' ); ?>
                        <?php submit_button( __( 'Create Snapshot Now', 'wp-environment-snapshot' ), 'primary', 'submit', false ); ?>
                    </form>
                </div>

                <div class="wpes-card">
                    <h2><?php esc_html_e( 'Monitoring Coverage', 'wp-environment-snapshot' ); ?></h2>
                    <ul>
                        <li><?php esc_html_e( 'WordPress, PHP, theme and plugin environment', 'wp-environment-snapshot' ); ?></li>
                        <li><?php esc_html_e( 'Plugin/theme installation, removal, activation and updates', 'wp-environment-snapshot' ); ?></li>
                        <li><?php esc_html_e( 'Users, roles, administrator creation and email changes', 'wp-environment-snapshot' ); ?></li>
                        <li><?php esc_html_e( 'Important WordPress options and database table schemas', 'wp-environment-snapshot' ); ?></li>
                        <li><?php esc_html_e( 'WP-Cron events', 'wp-environment-snapshot' ); ?></li>
                        <li><?php esc_html_e( 'PHP files plus wp-config.php and .htaccess fingerprints', 'wp-environment-snapshot' ); ?></li>
                    </ul>
                </div>
            </div>

            <div class="wpes-card">
                <h2><?php esc_html_e( 'Monitoring Settings', 'wp-environment-snapshot' ); ?></h2>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wpes-settings">
                    <input type="hidden" name="action" value="wpes_save_settings">
                    <?php wp_nonce_field( 'wpes_save_settings' ); ?>
                    <label><input type="checkbox" name="enabled" value="1" <?php checked( ! empty( $settings['enabled'] ) ); ?>> <?php esc_html_e( 'Enable automatic snapshots', 'wp-environment-snapshot' ); ?></label>
                    <label><?php esc_html_e( 'Snapshot interval (hours)', 'wp-environment-snapshot' ); ?> <input type="number" name="interval" min="1" max="168" value="<?php echo esc_attr( $settings['interval'] ); ?>"></label>
                    <label><?php esc_html_e( 'Keep snapshots', 'wp-environment-snapshot' ); ?> <input type="number" name="retention" min="2" max="100" value="<?php echo esc_attr( $settings['retention'] ); ?>"></label>
                    <?php submit_button( __( 'Save Settings', 'wp-environment-snapshot' ), 'secondary', 'submit', false ); ?>
                </form>
                <p class="description"><?php esc_html_e( 'Recommended default: every 12 hours. WP-Cron must run for scheduled snapshots to execute.', 'wp-environment-snapshot' ); ?></p>
            </div>

            <div class="wpes-card">
                <h2><?php esc_html_e( 'Snapshots & Investigation', 'wp-environment-snapshot' ); ?></h2>
                <?php if ( empty( $snapshots ) ) : ?>
                    <p><?php esc_html_e( 'No snapshots yet. Create one to establish the first baseline.', 'wp-environment-snapshot' ); ?></p>
                <?php else : ?>
                    <table class="widefat striped">
                        <thead><tr><th><?php esc_html_e( 'Date', 'wp-environment-snapshot' ); ?></th><th><?php esc_html_e( 'Source', 'wp-environment-snapshot' ); ?></th><th><?php esc_html_e( 'Changes', 'wp-environment-snapshot' ); ?></th><th><?php esc_html_e( 'Risk', 'wp-environment-snapshot' ); ?></th><th><?php esc_html_e( 'Actions', 'wp-environment-snapshot' ); ?></th></tr></thead>
                        <tbody>
                        <?php foreach ( $snapshots as $snapshot ) : $summary = $snapshot['summary']; ?>
                            <tr>
                                <td><?php echo esc_html( wp_date( 'Y-m-d H:i:s', $snapshot['created'] ) ); ?></td>
                                <td><?php echo esc_html( ucfirst( $snapshot['source'] ) ); ?></td>
                                <td><?php echo esc_html( array_sum( $summary ) ); ?></td>
                                <td><?php self::badges( $summary ); ?></td>
                                <td>
                                    <a class="button" href="<?php echo esc_url( self::url( array( 'compare' => $snapshot['id'] ) ) ); ?>"><?php esc_html_e( 'View Report', 'wp-environment-snapshot' ); ?></a>
                                    <a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpes_delete_snapshot&id=' . rawurlencode( $snapshot['id'] ) ), 'wpes_delete_' . $snapshot['id'] ) ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Delete this snapshot?', 'wp-environment-snapshot' ) ); ?>');"><?php esc_html_e( 'Delete', 'wp-environment-snapshot' ); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <?php if ( $compare ) : ?>
                <div class="wpes-card wpes-report">
                    <h2><?php esc_html_e( 'Change Investigation Report', 'wp-environment-snapshot' ); ?></h2>
                    <p><strong><?php esc_html_e( 'Snapshot:', 'wp-environment-snapshot' ); ?></strong> <?php echo esc_html( wp_date( 'Y-m-d H:i:s', $compare['created'] ) ); ?> (<?php echo esc_html( ucfirst( $compare['source'] ) ); ?>)</p>
                    <?php self::badges( $compare['summary'] ); ?>
                    <?php if ( empty( $compare['changes'] ) ) : ?>
                        <p><?php esc_html_e( 'No changes were detected compared with the previous baseline.', 'wp-environment-snapshot' ); ?></p>
                    <?php else : ?>
                        <div class="wpes-events">
                        <?php foreach ( $compare['changes'] as $event ) : ?>
                            <div class="wpes-event wpes-<?php echo esc_attr( $event['severity'] ); ?>">
                                <span class="wpes-severity"><?php echo esc_html( strtoupper( $event['severity'] ) ); ?></span>
                                <strong><?php echo esc_html( ucfirst( str_replace( '_', ' ', $event['type'] ) ) ); ?></strong>
                                <span><?php echo esc_html( $event['message'] ); ?></span>
                            </div>
                        <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <p><em><?php esc_html_e( 'A detected change is not automatically malicious. Use the timeline and file details with your backup, hosting, access, and security evidence when investigating an incident.', 'wp-environment-snapshot' ); ?></em></p>
                </div>
            <?php endif; ?>

            <div class="wpes-card">
                <h2><?php esc_html_e( 'Baseline', 'wp-environment-snapshot' ); ?></h2>
                <p><?php esc_html_e( 'Resetting the baseline causes the next snapshot to establish a new starting point. Existing reports are retained.', 'wp-environment-snapshot' ); ?></p>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <input type="hidden" name="action" value="wpes_reset_baseline">
                    <?php wp_nonce_field( 'wpes_reset_baseline' ); ?>
                    <?php submit_button( __( 'Reset Baseline', 'wp-environment-snapshot' ), 'secondary', 'submit', false ); ?>
                </form>
            </div>
        </div>
        <?php
    }

    private static function badges( $summary ) {
        foreach ( array( 'critical', 'high', 'warning', 'info' ) as $level ) {
            if ( ! empty( $summary[ $level ] ) ) {
                echo '<span class="wpes-badge wpes-badge-' . esc_attr( $level ) . '">' . esc_html( ucfirst( $level ) . ': ' . $summary[ $level ] ) . '</span> ';
            }
        }
    }

    private static function notice() {
        if ( empty( $_GET['message'] ) ) {
            return;
        }
        $messages = array(
            'created'  => __( 'Snapshot created successfully.', 'wp-environment-snapshot' ),
            'deleted'  => __( 'Snapshot deleted.', 'wp-environment-snapshot' ),
            'settings' => __( 'Monitoring settings saved.', 'wp-environment-snapshot' ),
            'reset'    => __( 'Baseline reset. The next snapshot will establish a new baseline.', 'wp-environment-snapshot' ),
        );
        $key = sanitize_key( wp_unslash( $_GET['message'] ) );
        if ( isset( $messages[ $key ] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $messages[ $key ] ) . '</p></div>';
        }
    }
}
