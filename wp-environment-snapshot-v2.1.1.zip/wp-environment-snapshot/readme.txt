=== WP Environment Snapshot ===
Contributors: ms-hasan
Tags: debugging, security, monitoring, troubleshooting, developer-tools
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 2.1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Monitor important WordPress environment, database, cron, user, and PHP/configuration-file changes to investigate broken sites and security incidents.

== Description ==
WP Environment Snapshot automatically creates periodic snapshots of important WordPress state and compares each new snapshot with the previous baseline.

It is designed to help answer: "What changed before the site broke?"

=== Monitored areas ===
* WordPress and PHP environment
* Active theme and installed themes
* Installed, removed, activated, deactivated and updated plugins
* Users, roles, administrator creation and user email changes
* Important WordPress options
* Database table/schema changes
* WP-Cron events
* PHP file additions, deletions and modifications
* New and deleted directory detection in monitored areas
* wp-config.php and .htaccess fingerprints
* Suspicious PHP files appearing in uploads are flagged with higher severity

=== Automatic snapshots ===
Snapshots can run automatically from every 1 to 168 hours. The default is every 12 hours. Snapshot retention is configurable.

=== Privacy ===
The plugin does not send data to an external service. User email addresses are represented by hashes in the stored snapshot state. wp-config.php contents are never stored; only a file fingerprint is recorded.

=== Important security note ===
A detected file or configuration change is not automatically malware. Legitimate WordPress updates and administrator actions also create changes. Use the plugin as an investigation and change-detection aid alongside reliable backups, hosting logs and appropriate security tools.

== Installation ==
1. Upload the plugin folder to `/wp-content/plugins/` or install the ZIP from Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Go to Tools > Environment Snapshots.
4. Create the first snapshot to establish a baseline.
5. Configure the automatic interval and retention settings.

== Frequently Asked Questions ==
= Does this replace a backup? =
No. It records state and change information. It does not create a full site backup.

= Does it scan all files? =
It fingerprints PHP files and records directory structure in the WordPress installation, plugins, themes and MU plugins, plus wp-config.php and .htaccess. Cache, upgrade and uploads directories are excluded from the recursive filesystem scan.

= Does it detect malware? =
It can identify suspicious file and configuration changes, but it does not claim that a changed file is malicious.

= Does it monitor post and page changes? =
No. Content changes are intentionally outside the current scope.

== Changelog ==
== 2.1.1 ==
* Improved snapshot-to-snapshot filesystem comparison.
* File and directory state is now stored in each snapshot, so additions, deletions, and modifications are compared against the actual previous snapshot.
* Removed the legacy mutable file-baseline dependency.

= 2.1.0 =
* Added directory structure change detection.
* Improved filesystem change reporting for files and directories.
* Excluded the plugin's own scheduled snapshot event from normal WP-Cron incident reports.

= 2.0.0 =
* Added automatic scheduled snapshots.
* Added configurable snapshot retention.
* Added user and role change detection.
* Added important option change detection.
* Added database table/schema change detection.
* Added WP-Cron change detection.
* Added PHP/configuration file fingerprint monitoring.
* Added change severity and investigation report UI.
* Added baseline reset functionality.

= 1.0.0 =
* Initial release.
