/**
 * NovaPress Core admin functionality.
 */
document.addEventListener( 'DOMContentLoaded', function () {
	const buttons = document.querySelectorAll( '.novapress-core-copy-shortcode' );

	buttons.forEach( function ( button ) {
		button.addEventListener( 'click', function () {
			const control = button.closest( '.novapress-core-shortcode-control' );
			const input   = control ? control.querySelector( '.novapress-core-shortcode-input' ) : null;

			if ( ! input ) {
				return;
			}

			const originalText = button.textContent;
			const copiedText   = button.getAttribute( 'data-copied-text' ) || originalText;
			const failedText   = button.getAttribute( 'data-copy-failed-text' ) || originalText;

			const showResult = function ( text ) {
				button.textContent = text;

				window.setTimeout( function () {
					button.textContent = originalText;
				}, 1500 );
			};

			const fallbackCopy = function () {
				input.focus();
				input.select();

				try {
					document.execCommand( 'copy' );
					showResult( copiedText );
				} catch ( error ) {
					showResult( failedText );
				}
			};

			if ( navigator.clipboard && window.isSecureContext ) {
				navigator.clipboard.writeText( input.value ).then( function () {
					showResult( copiedText );
				} ).catch( fallbackCopy );
				return;
			}

			fallbackCopy();
		} );
	} );
} );
