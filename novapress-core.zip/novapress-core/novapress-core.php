<?php
/**
 * Plugin Name: NovaPress Core
 * Description: Manage business information and multiple business locations from the WordPress dashboard.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: MS Hasan
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: novapress-core
 *
 * @package NovaPress_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'NOVAPRESS_CORE_VERSION', '1.0.0' );
define( 'NOVAPRESS_CORE_FILE', __FILE__ );
define( 'NOVAPRESS_CORE_PATH', plugin_dir_path( __FILE__ ) );
define( 'NOVAPRESS_CORE_URL', plugin_dir_url( __FILE__ ) );

require_once NOVAPRESS_CORE_PATH . 'includes/class-novapress-core-settings.php';
require_once NOVAPRESS_CORE_PATH . 'includes/class-novapress-core-locations.php';
require_once NOVAPRESS_CORE_PATH . 'includes/class-novapress-core-shortcodes.php';

/**
 * Register activation callback.
 *
 * @return void
 */
function novapress_core_activate() {
	NovaPress_Core_Locations::register_post_type();
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'novapress_core_activate' );

/**
 * Register deactivation callback.
 *
 * @return void
 */
function novapress_core_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'novapress_core_deactivate' );

NovaPress_Core_Settings::init();
NovaPress_Core_Locations::init();
NovaPress_Core_Shortcodes::init();
