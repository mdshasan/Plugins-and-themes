<?php
/**
 * Uninstall NovaPress Core.
 *
 * @package NovaPress_Core
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Remove plugin options.
 */
$options = array(
	'novapress_core_business_name',
	'novapress_core_phone',
	'novapress_core_email',
	'novapress_core_website',
	'novapress_core_address',
	'novapress_core_whatsapp',
	'novapress_core_hours',
);

foreach ( $options as $option ) {
	delete_option( $option );
}

/**
 * Remove business locations.
 */
$locations = get_posts(
	array(
		'post_type'      => 'novapress_location',
		'post_status'    => 'any',
		'posts_per_page' => -1,
		'fields'         => 'ids',
	)
);

foreach ( $locations as $location_id ) {
	wp_delete_post( $location_id, true );
}