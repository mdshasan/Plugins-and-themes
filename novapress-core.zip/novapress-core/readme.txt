=== NovaPress Core ===
Contributors: mshasan
Tags: business directory, business information, business locations, contact information, locations
Requires at least: 6.0
Requires PHP: 7.4
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage business information and multiple business locations from your WordPress dashboard.

== Description ==

NovaPress Core provides a centralized way to manage common business information and multiple business locations in WordPress.

The plugin allows website administrators to manage:

* Business name
* Phone number
* Email address
* Website
* Main business address
* WhatsApp number
* Business hours
* Multiple business locations
* Location addresses
* Location phone numbers
* Location email addresses
* Google Maps URLs

Business information can be displayed on the frontend using shortcodes.

== Features ==

* Centralized business information
* Multiple business locations
* Location details
* Business hours
* Contact information
* Responsive location display
* WordPress Settings API
* Custom Post Type
* Secure custom fields
* Shortcodes
* Translation-ready strings
* No external service required

== Shortcodes ==

[nova_business_name]

Displays the business name.

[nova_business_phone]

Displays the business phone number.

[nova_business_whatsapp]

Displays the business WhatsApp number.

[nova_business_email]

Displays the business email address.

[nova_business_website]

Displays the business website.

[nova_business_address]

Displays the main business address.

[nova_business_hours]

Displays the business hours.

[nova_business_locations]

Displays all published business locations.

== Installation ==

1. Upload the plugin to the `/wp-content/plugins/` directory or install it through the WordPress plugin installer.
2. Activate NovaPress Core through the Plugins menu.
3. Open NovaPress Core from the WordPress admin menu.
4. Enter your business information.
5. Save the settings.
6. Open Locations and create your business locations.
7. Use the available shortcodes on your website.

== Frequently Asked Questions ==

= Can I add multiple locations? =

Yes. You can create multiple business locations.

= Can I display the business information on any page? =

Yes. The provided shortcodes can be used in WordPress content areas that support shortcodes.

= Does NovaPress Core use an external service? =

No. NovaPress Core does not require an external API or third-party service.

= Can I use the plugin with any WordPress theme? =

Yes. The plugin is designed to work independently of the active WordPress theme.

== Privacy ==

NovaPress Core does not send business information or visitor information to external servers.

The plugin stores the information entered by administrators in the WordPress database.

== Changelog ==

= 1.0.0 =
* Initial release.