<?php
/**
 * Business information settings.
 *
 * @package NovaPress_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles business information settings.
 */
class NovaPress_Core_Settings {

	/**
	 * Initialize settings functionality.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'add_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Add admin menu.
	 *
	 * @return void
	 */
	public static function add_menu() {
		add_menu_page(
			__( 'NovaPress Core', 'novapress-core' ),
			__( 'NovaPress Core', 'novapress-core' ),
			'manage_options',
			'novapress-core',
			array( __CLASS__, 'settings_page' ),
			'dashicons-building',
			25
		);
	}

	/**
	 * Register settings.
	 *
	 * @return void
	 */
	public static function register_settings() {
		add_settings_section(
			'novapress_core_business_section',
			__( 'Business Information', 'novapress-core' ),
			array( __CLASS__, 'section_description' ),
			'novapress_core_settings'
		);

		$fields = array(
			'novapress_core_business_name' => array(
				'label'    => __( 'Business Name', 'novapress-core' ),
				'type'     => 'text',
				'sanitize' => 'sanitize_text_field',
			),
			'novapress_core_phone' => array(
				'label'    => __( 'Phone', 'novapress-core' ),
				'type'     => 'text',
				'sanitize' => 'sanitize_text_field',
			),
			'novapress_core_email' => array(
				'label'    => __( 'Email', 'novapress-core' ),
				'type'     => 'email',
				'sanitize' => 'sanitize_email',
			),
			'novapress_core_website' => array(
				'label'    => __( 'Website', 'novapress-core' ),
				'type'     => 'url',
				'sanitize' => 'esc_url_raw',
			),
			'novapress_core_address' => array(
				'label'    => __( 'Main Address', 'novapress-core' ),
				'type'     => 'textarea',
				'sanitize' => 'sanitize_textarea_field',
			),
			'novapress_core_whatsapp' => array(
				'label'    => __( 'WhatsApp', 'novapress-core' ),
				'type'     => 'text',
				'sanitize' => 'sanitize_text_field',
			),
			'novapress_core_hours' => array(
				'label'    => __( 'Business Hours', 'novapress-core' ),
				'type'     => 'textarea',
				'sanitize' => 'sanitize_textarea_field',
			),
		);

		foreach ( $fields as $option_name => $field ) {
			register_setting(
				'novapress_core_settings_group',
				$option_name,
				array(
					'sanitize_callback' => $field['sanitize'],
					'default'           => '',
				)
			);

			add_settings_field(
				$option_name,
				$field['label'],
				array( __CLASS__, 'render_field' ),
				'novapress_core_settings',
				'novapress_core_business_section',
				array(
					'option_name' => $option_name,
					'type'        => $field['type'],
				)
			);
		}
	}

	/**
	 * Section description.
	 *
	 * @return void
	 */
	public static function section_description() {
		echo '<p>';
		esc_html_e( 'Enter the main information for your business.', 'novapress-core' );
		echo '</p>';
	}

	/**
	 * Render a settings field.
	 *
	 * @param array $args Field arguments.
	 * @return void
	 */
	public static function render_field( $args ) {
		$option_name = $args['option_name'];
		$type        = $args['type'];
		$value       = get_option( $option_name, '' );

		if ( 'textarea' === $type ) {
			printf(
				'<textarea id="%1$s" name="%1$s" rows="4" class="large-text">%2$s</textarea>',
				esc_attr( $option_name ),
				esc_textarea( $value )
			);
			return;
		}

		printf(
			'<input type="%1$s" id="%2$s" name="%2$s" value="%3$s" class="regular-text">',
			esc_attr( $type ),
			esc_attr( $option_name ),
			esc_attr( $value )
		);
	}

	/**
	 * Render settings page.
	 *
	 * @return void
	 */
	public static function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap novapress-core-settings">
			<h1><?php esc_html_e( 'NovaPress Core', 'novapress-core' ); ?></h1>
			<p><?php esc_html_e( 'Manage your main business information.', 'novapress-core' ); ?></p>
			<form method="post" action="options.php">
				<?php
				settings_fields( 'novapress_core_settings_group' );
				do_settings_sections( 'novapress_core_settings' );
				submit_button( __( 'Save Information', 'novapress-core' ) );
				?>
			</form>
		</div>

		<div class="novapress-core-shortcodes">
			<h2><?php esc_html_e( 'Available Shortcodes', 'novapress-core' ); ?></h2>
			<p><?php esc_html_e( 'Copy a shortcode below and paste it into a page, post, widget, or shortcode block to display your saved business information.', 'novapress-core' ); ?></p>

			<?php
			$shortcodes = array(
				'nova_business_name'      => __( 'Business Name', 'novapress-core' ),
				'nova_business_phone'     => __( 'Business Phone', 'novapress-core' ),
				'nova_business_whatsapp'  => __( 'WhatsApp', 'novapress-core' ),
				'nova_business_email'     => __( 'Business Email', 'novapress-core' ),
				'nova_business_website'   => __( 'Business Website', 'novapress-core' ),
				'nova_business_address'   => __( 'Business Address', 'novapress-core' ),
				'nova_business_hours'     => __( 'Business Hours', 'novapress-core' ),
				'nova_business_locations' => __( 'Business Locations', 'novapress-core' ),
			);

			foreach ( $shortcodes as $shortcode => $label ) :
				$shortcode_text = '[' . $shortcode . ']';
				?>
				<div class="novapress-core-shortcode-row">
					<div>
						<strong><?php echo esc_html( $label ); ?></strong>
						<p class="description">
							<?php
							if ( 'nova_business_locations' === $shortcode ) {
								esc_html_e( 'Displays your published business locations.', 'novapress-core' );
							} else {
								printf(
									/* translators: %s: field name. */
									esc_html__( 'Displays your saved %s.', 'novapress-core' ),
									esc_html( strtolower( $label ) )
								);
							}
							?>
						</p>
					</div>
					<div class="novapress-core-shortcode-control">
						<input type="text" class="regular-text novapress-core-shortcode-input" value="<?php echo esc_attr( $shortcode_text ); ?>" readonly aria-label="<?php echo esc_attr( $label . ' shortcode' ); ?>">
						<button
							type="button"
							class="button novapress-core-copy-shortcode"
							data-copied-text="<?php esc_attr_e( 'Copied!', 'novapress-core' ); ?>"
							data-copy-failed-text="<?php esc_attr_e( 'Copy failed', 'novapress-core' ); ?>"
						>
							<?php esc_html_e( 'Copy', 'novapress-core' ); ?>
						</button>
					</div>
				</div>
				<?php
			endforeach;
			?>
		</div>
		<?php
	}

	/**
	 * Load admin assets only on our settings page.
	 *
	 * @param string $hook_suffix Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook_suffix ) {
		if ( 'toplevel_page_novapress-core' !== $hook_suffix ) {
			return;
		}

		wp_enqueue_style(
			'novapress-core-admin',
			NOVAPRESS_CORE_URL . 'assets/css/admin.css',
			array(),
			NOVAPRESS_CORE_VERSION
		);

		wp_enqueue_script(
			'novapress-core-admin',
			NOVAPRESS_CORE_URL . 'assets/js/admin.js',
			array(),
			NOVAPRESS_CORE_VERSION,
			true
		);
	}
}
