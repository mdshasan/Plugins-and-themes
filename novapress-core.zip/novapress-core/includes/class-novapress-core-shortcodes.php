<?php
/**
 * Frontend shortcodes.
 *
 * @package NovaPress_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles frontend shortcodes.
 */
class NovaPress_Core_Shortcodes {

	/**
	 * Initialize shortcodes.
	 *
	 * @return void
	 */
	public static function init() {
		add_shortcode( 'nova_business_name', array( __CLASS__, 'business_name' ) );
		add_shortcode( 'nova_business_phone', array( __CLASS__, 'business_phone' ) );
		add_shortcode( 'nova_business_whatsapp', array( __CLASS__, 'business_whatsapp' ) );
		add_shortcode( 'nova_business_email', array( __CLASS__, 'business_email' ) );
		add_shortcode( 'nova_business_website', array( __CLASS__, 'business_website' ) );
		add_shortcode( 'nova_business_address', array( __CLASS__, 'business_address' ) );
		add_shortcode( 'nova_business_hours', array( __CLASS__, 'business_hours' ) );
		add_shortcode( 'nova_business_locations', array( __CLASS__, 'business_locations' ) );

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Business name.
	 *
	 * @return string
	 */
	public static function business_name() {
		return esc_html( get_option( 'novapress_core_business_name', '' ) );
	}

	/**
	 * Business phone.
	 *
	 * @return string
	 */
	public static function business_phone() {
		return esc_html( get_option( 'novapress_core_phone', '' ) );
	}

	/**
	 * Business WhatsApp number.
	 *
	 * @return string
	 */
	public static function business_whatsapp() {
		return esc_html( get_option( 'novapress_core_whatsapp', '' ) );
	}

	/**
	 * Business email.
	 *
	 * @return string
	 */
	public static function business_email() {
		$email = get_option( 'novapress_core_email', '' );

		if ( empty( $email ) ) {
			return '';
		}

		return sprintf(
			'<a href="mailto:%1$s">%2$s</a>',
			esc_attr( $email ),
			esc_html( $email )
		);
	}

	/**
	 * Business website.
	 *
	 * @return string
	 */
	public static function business_website() {
		$website = get_option( 'novapress_core_website', '' );

		if ( empty( $website ) ) {
			return '';
		}

		return sprintf(
			'<a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
			esc_url( $website ),
			esc_html( $website )
		);
	}

	/**
	 * Business address.
	 *
	 * @return string
	 */
	public static function business_address() {
		$address = get_option( 'novapress_core_address', '' );

		return nl2br( esc_html( $address ) );
	}

	/**
	 * Business hours.
	 *
	 * @return string
	 */
	public static function business_hours() {
		$hours = get_option( 'novapress_core_hours', '' );

		return nl2br( esc_html( $hours ) );
	}

	/**
	 * Business locations.
	 *
	 * @return string
	 */
	public static function business_locations() {
		$query = new WP_Query(
			array(
				'post_type'      => 'novapress_location',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);

		if ( ! $query->have_posts() ) {
			return '';
		}

		ob_start();
		?>
		<div class="novapress-core-locations">
			<?php while ( $query->have_posts() ) : ?>
				<?php $query->the_post(); ?>
				<?php
				$location_id = get_the_ID();
				$address     = get_post_meta( $location_id, '_novapress_core_address', true );
				$phone       = get_post_meta( $location_id, '_novapress_core_phone', true );
				$email       = get_post_meta( $location_id, '_novapress_core_email', true );
				$map_url     = get_post_meta( $location_id, '_novapress_core_map_url', true );
				?>
				<article class="novapress-core-location">
					<h3 class="novapress-core-location__title">
						<?php echo esc_html( get_the_title() ); ?>
					</h3>

					<?php if ( $address ) : ?>
						<p>
							<strong><?php esc_html_e( 'Address:', 'novapress-core' ); ?></strong><br>
							<?php echo nl2br( esc_html( $address ) ); ?>
						</p>
					<?php endif; ?>

					<?php if ( $phone ) : ?>
						<p>
							<strong><?php esc_html_e( 'Phone:', 'novapress-core' ); ?></strong><br>
							<?php echo esc_html( $phone ); ?>
						</p>
					<?php endif; ?>

					<?php if ( $email ) : ?>
						<p>
							<strong><?php esc_html_e( 'Email:', 'novapress-core' ); ?></strong><br>
							<a href="mailto:<?php echo esc_attr( $email ); ?>">
								<?php echo esc_html( $email ); ?>
							</a>
						</p>
					<?php endif; ?>

					<?php if ( $map_url ) : ?>
						<p>
							<a href="<?php echo esc_url( $map_url ); ?>" target="_blank" rel="noopener noreferrer">
								<?php esc_html_e( 'View on Map', 'novapress-core' ); ?>
							</a>
						</p>
					<?php endif; ?>
				</article>
			<?php endwhile; ?>
		</div>
		<?php

		wp_reset_postdata();

		return ob_get_clean();
	}

	/**
	 * Enqueue frontend assets only when the locations shortcode is present.
	 *
	 * @return void
	 */
	public static function enqueue_assets() {
		if ( ! is_singular() ) {
			return;
		}

		global $post;

		if ( ! $post instanceof WP_Post ) {
			return;
		}

		if ( ! has_shortcode( $post->post_content, 'nova_business_locations' ) ) {
			return;
		}

		wp_enqueue_style(
			'novapress-core-frontend',
			NOVAPRESS_CORE_URL . 'assets/css/frontend.css',
			array(),
			NOVAPRESS_CORE_VERSION
		);
	}
}
