<?php
/**
 * Business locations.
 *
 * @package NovaPress_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles business locations.
 */
class NovaPress_Core_Locations {

	/**
	 * Initialize locations.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post_novapress_location', array( __CLASS__, 'save_location' ) );
	}

	/**
	 * Register locations post type.
	 *
	 * @return void
	 */
	public static function register_post_type() {
		$labels = array(
			'name'               => __( 'Locations', 'novapress-core' ),
			'singular_name'      => __( 'Location', 'novapress-core' ),
			'add_new'            => __( 'Add New', 'novapress-core' ),
			'add_new_item'       => __( 'Add New Location', 'novapress-core' ),
			'edit_item'          => __( 'Edit Location', 'novapress-core' ),
			'new_item'           => __( 'New Location', 'novapress-core' ),
			'view_item'          => __( 'View Location', 'novapress-core' ),
			'search_items'       => __( 'Search Locations', 'novapress-core' ),
			'not_found'          => __( 'No locations found.', 'novapress-core' ),
			'not_found_in_trash' => __( 'No locations found in Trash.', 'novapress-core' ),
			'menu_name'          => __( 'Locations', 'novapress-core' ),
		);

		register_post_type(
			'novapress_location',
			array(
				'labels'             => $labels,
				'public'             => true,
				'show_ui'            => true,
				'show_in_rest'       => true,
				'has_archive'        => true,
				'menu_icon'          => 'dashicons-location',
				'supports'           => array( 'title', 'editor', 'thumbnail' ),
				'rewrite'            => array( 'slug' => 'business-locations' ),
				'publicly_queryable' => true,
			)
		);
	}

	/**
	 * Add location meta box.
	 *
	 * @return void
	 */
	public static function add_meta_box() {
		add_meta_box(
			'novapress_core_location_details',
			__( 'Location Details', 'novapress-core' ),
			array( __CLASS__, 'render_meta_box' ),
			'novapress_location',
			'normal',
			'high'
		);
	}

	/**
	 * Render location meta box.
	 *
	 * @param WP_Post $post Current post.
	 * @return void
	 */
	public static function render_meta_box( $post ) {
		wp_nonce_field(
			'novapress_core_save_location',
			'novapress_core_location_nonce'
		);

		$address = get_post_meta( $post->ID, '_novapress_core_address', true );
		$phone   = get_post_meta( $post->ID, '_novapress_core_phone', true );
		$email   = get_post_meta( $post->ID, '_novapress_core_email', true );
		$map_url = get_post_meta( $post->ID, '_novapress_core_map_url', true );
		?>
		<p>
			<label for="novapress_core_address">
				<strong><?php esc_html_e( 'Address', 'novapress-core' ); ?></strong>
			</label>
		</p>

		<textarea id="novapress_core_address" name="novapress_core_address" rows="3" class="widefat"><?php echo esc_textarea( $address ); ?></textarea>

		<p>
			<label for="novapress_core_phone">
				<strong><?php esc_html_e( 'Phone', 'novapress-core' ); ?></strong>
			</label>
			<input type="text" id="novapress_core_phone" name="novapress_core_phone" value="<?php echo esc_attr( $phone ); ?>" class="widefat">
		</p>

		<p>
			<label for="novapress_core_email">
				<strong><?php esc_html_e( 'Email', 'novapress-core' ); ?></strong>
			</label>
			<input type="email" id="novapress_core_email" name="novapress_core_email" value="<?php echo esc_attr( $email ); ?>" class="widefat">
		</p>

		<p>
			<label for="novapress_core_map_url">
				<strong><?php esc_html_e( 'Google Maps URL', 'novapress-core' ); ?></strong>
			</label>
			<input type="url" id="novapress_core_map_url" name="novapress_core_map_url" value="<?php echo esc_attr( $map_url ); ?>" class="widefat">
		</p>
		<?php
	}

	/**
	 * Save location information.
	 *
	 * @param int $post_id Current post ID.
	 * @return void
	 */
	public static function save_location( $post_id ) {
		if ( ! isset( $_POST['novapress_core_location_nonce'] ) ) {
			return;
		}

		$nonce = sanitize_text_field(
			wp_unslash( $_POST['novapress_core_location_nonce'] )
		);

		if ( ! wp_verify_nonce( $nonce, 'novapress_core_save_location' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$fields = array(
			'novapress_core_address' => array(
				'meta_key' => '_novapress_core_address',
				'sanitize' => 'sanitize_textarea_field',
			),
			'novapress_core_phone' => array(
				'meta_key' => '_novapress_core_phone',
				'sanitize' => 'sanitize_text_field',
			),
			'novapress_core_email' => array(
				'meta_key' => '_novapress_core_email',
				'sanitize' => 'sanitize_email',
			),
			'novapress_core_map_url' => array(
				'meta_key' => '_novapress_core_map_url',
				'sanitize' => 'esc_url_raw',
			),
		);

		foreach ( $fields as $field_name => $field ) {
			if ( ! isset( $_POST[ $field_name ] ) ) {
				continue;
			}

			$value = call_user_func(
				$field['sanitize'],
				wp_unslash( $_POST[ $field_name ] )
			);

			update_post_meta(
				$post_id,
				$field['meta_key'],
				$value
			);
		}
	}
}
