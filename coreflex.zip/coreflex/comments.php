<?php
/**
 * Comments template.
 *
 * @package CoreFlex
 */

if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">

	<?php if ( have_comments() ) : ?>

		<h2 class="comments-title">
			<?php
			printf(
				esc_html(
					_n(
						'%1$s comment',
						'%1$s comments',
						get_comments_number(),
						'coreflex'
					)
				),
				esc_html( number_format_i18n( get_comments_number() ) )
			);
			?>
		</h2>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'      => 'ol',
					'short_ping' => true,
					'avatar_size'=> 60,
				)
			);
			?>
		</ol>

		<?php
		the_comments_pagination(
			array(
				'prev_text' => esc_html__( '← Older Comments', 'coreflex' ),
				'next_text' => esc_html__( 'Newer Comments →', 'coreflex' ),
			)
		);
		?>

	<?php endif; ?>

	<?php if ( comments_open() ) : ?>

		<?php comment_form(); ?>

	<?php elseif ( get_comments_number() ) : ?>

		<p class="no-comments">
			<?php esc_html_e( 'Comments are closed.', 'coreflex' ); ?>
		</p>

	<?php endif; ?>

</div>