CoreFlex

Version: 1.0.0

Author: MS Hasan

Description:

CoreFlex is a lightweight, responsive and flexible business theme
built with WordPress coding standards.

Features

- Responsive
- Accessibility Ready
- Translation Ready
- Custom Logo
- Custom Header
- Custom Background
- Featured Images
- Menus
- Widgets
- Customizer
- Blog
- Search
- Archives
- Comments
- 404 Page

License

GPL v2 or later