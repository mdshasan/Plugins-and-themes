<?php
/**
 * Template part for displaying posts.
 */
?>

<article <?php post_class( 'post-card' ); ?>>

	<?php if ( has_post_thumbnail() ) : ?>

		<div class="post-card-image">

			<a
				href="<?php the_permalink(); ?>"
				aria-label="<?php echo esc_attr( sprintf( __( 'Read %s', 'coreflex' ), get_the_title() ) ); ?>"
			>

				<?php the_post_thumbnail( 'large' ); ?>

			</a>

		</div>

	<?php endif; ?>


	<div class="post-card-content">

		<?php
		$categories = get_the_category();

		if ( ! empty( $categories ) ) :
			?>

			<p class="post-category">

				<a href="<?php echo esc_url( get_category_link( $categories[0]->term_id ) ); ?>">

					<?php echo esc_html( $categories[0]->name ); ?>

				</a>

			</p>

		<?php endif; ?>


		<h2 class="post-card-title">

			<a href="<?php the_permalink(); ?>">

				<?php the_title(); ?>

			</a>

		</h2>


		<div class="post-meta">

			<span>
				<?php
				printf(
					/* translators: %s: post date. */
					esc_html__( 'Published %s', 'coreflex' ),
					esc_html( get_the_date() )
				);
				?>
			</span>

			<span aria-hidden="true">•</span>

			<span>
				<?php
				printf(
					/* translators: %s: post author. */
					esc_html__( 'By %s', 'coreflex' ),
					esc_html( get_the_author() )
				);
				?>
			</span>

		</div>


		<div class="post-excerpt">

			<?php the_excerpt(); ?>

		</div>


		<a class="read-more" href="<?php the_permalink(); ?>">

			<?php esc_html_e( 'Read More', 'coreflex' ); ?>

			<span aria-hidden="true"> →</span>

		</a>

	</div>

</article>