<section class="no-results">

	<h2>

		<?php esc_html_e( 'Nothing Found', 'coreflex' ); ?>

	</h2>

	<p>

		<?php esc_html_e(
			'Sorry, no content matched your request.',
			'coreflex'
		); ?>

	</p>

	<?php get_search_form(); ?>

</section>