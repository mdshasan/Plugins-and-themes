<?php get_header(); ?>

<div class="container">

    <header class="archive-header">

        <h1><?php the_archive_title(); ?></h1>

        <?php the_archive_description(); ?>

    </header>

    <?php if ( have_posts() ) : ?>

        <?php while ( have_posts() ) : the_post(); ?>

            <?php get_template_part( 'template-parts/content' ); ?>

        <?php endwhile; ?>

        <?php the_posts_pagination(); ?>

    <?php else : ?>

        <?php get_template_part( 'template-parts/content', 'none' ); ?>

    <?php endif; ?>

</div>

<?php get_footer(); ?>