document.addEventListener('DOMContentLoaded', function () {

	const menuButton = document.querySelector('.menu-toggle');
	const navigation = document.querySelector('.main-navigation');

	if (!menuButton || !navigation) {
		return;
	}

	const label = menuButton.querySelector('.menu-toggle-label');

	menuButton.addEventListener('click', function () {

		const isExpanded = menuButton.getAttribute('aria-expanded') === 'true';

		menuButton.setAttribute(
			'aria-expanded',
			String(!isExpanded)
		);

		navigation.classList.toggle('is-open');

		if (label) {
			label.textContent = isExpanded
				? 'Open menu'
				: 'Close menu';
		}

	});

});