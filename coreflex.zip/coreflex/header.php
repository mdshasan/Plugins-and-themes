<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#primary">
	<?php esc_html_e( 'Skip to content', 'coreflex' ); ?>
</a>

<header class="site-header">

	<div class="container">

		<div class="site-branding">

			<?php the_custom_logo(); ?>

			<div class="site-title-description">

				<?php if ( is_front_page() && is_home() ) : ?>

					<h1 class="site-title">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
							<?php bloginfo( 'name' ); ?>
						</a>
					</h1>

				<?php else : ?>

					<p class="site-title">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
							<?php bloginfo( 'name' ); ?>
						</a>
					</p>

				<?php endif; ?>

				<?php $description = get_bloginfo( 'description', 'display' ); ?>

				<?php if ( $description ) : ?>

					<p class="site-description">
						<?php echo esc_html( $description ); ?>
					</p>

				<?php endif; ?>

			</div>

		</div>

		<button
	class="menu-toggle"
	type="button"
	aria-controls="primary-menu"
	aria-expanded="false"
>
	<span class="menu-toggle-label">
		<?php esc_html_e( 'Open menu', 'coreflex' ); ?>
	</span>

	<span aria-hidden="true">&#9776;</span>
</button>

		<nav
			class="main-navigation"
			aria-label="<?php esc_attr_e( 'Primary menu', 'coreflex' ); ?>"
		>

			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'menu_id'        => 'primary-menu',
					'menu_class'     => 'primary-menu',
					'container'      => false,
				)
			);
			?>

		</nav>

	</div>

</header>

<main id="primary" class="site-main">