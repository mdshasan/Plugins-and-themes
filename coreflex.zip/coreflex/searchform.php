<form
	role="search"
	method="get"
	class="search-form"
	action="<?php echo esc_url( home_url( '/' ) ); ?>"
>
	<label>
		<span class="screen-reader-text">
			<?php esc_html_e( 'Search for:', 'coreflex' ); ?>
		</span>

		<input
			type="search"
			class="search-field"
			placeholder="<?php echo esc_attr_x( 'Search …', 'placeholder', 'coreflex' ); ?>"
			value="<?php echo get_search_query(); ?>"
			name="s"
		>
	</label>

	<button type="submit">
		<?php esc_html_e( 'Search', 'coreflex' ); ?>
	</button>
</form>