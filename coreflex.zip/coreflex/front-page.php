<?php get_header(); ?>

<main id="primary" class="site-main">

	<?php if ( have_posts() ) : ?>

		<?php while ( have_posts() ) : the_post(); ?>

			<section class="hero-section">

				<div class="container hero-grid">

					<div class="hero-content">

						<p class="eyebrow">
							<?php esc_html_e( 'Build Something Better', 'coreflex' ); ?>
						</p>

						<h1><?php the_title(); ?></h1>

						<div class="hero-text">
							<?php the_content(); ?>
						</div>

						<div class="hero-actions">

							<a class="button button-primary" href="#latest-posts">
								<?php esc_html_e( 'Explore More', 'coreflex' ); ?>
							</a>

							<a class="button button-secondary" href="<?php echo esc_url( home_url( '/' ) ); ?>">
								<?php esc_html_e( 'Contact Us', 'coreflex' ); ?>
							</a>

						</div>

					</div>

					<?php if ( has_post_thumbnail() ) : ?>

						<div class="hero-image">

							<?php the_post_thumbnail( 'large' ); ?>

						</div>

					<?php endif; ?>

				</div>

			</section>

		<?php endwhile; ?>

	<?php endif; ?>


	<section class="features-section">

		<div class="container">

			<header class="section-header">

				<p class="eyebrow">
					<?php esc_html_e( 'Why CoreFlex', 'coreflex' ); ?>
				</p>

				<h2>
					<?php esc_html_e( 'Built for Modern Businesses', 'coreflex' ); ?>
				</h2>

			</header>


			<div class="features-grid">

				<article class="feature-card">

					<h3>
						<?php esc_html_e( 'Flexible', 'coreflex' ); ?>
					</h3>

					<p>
						<?php esc_html_e(
							'Create a website that can adapt to your business.',
							'coreflex'
						); ?>
					</p>

				</article>


				<article class="feature-card">

					<h3>
						<?php esc_html_e( 'Lightweight', 'coreflex' ); ?>
					</h3>

					<p>
						<?php esc_html_e(
							'Built with WordPress core without unnecessary dependencies.',
							'coreflex'
						); ?>
					</p>

				</article>


				<article class="feature-card">

					<h3>
						<?php esc_html_e( 'Accessible', 'coreflex' ); ?>
					</h3>

					<p>
						<?php esc_html_e(
							'Designed with accessibility and usability in mind.',
							'coreflex'
						); ?>
					</p>

				</article>

			</div>

		</div>

	</section>


	<section class="about-section">

		<div class="container about-grid">

			<div>

				<p class="eyebrow">
					<?php esc_html_e( 'About Your Business', 'coreflex' ); ?>
				</p>

				<h2>
					<?php esc_html_e(
						'A flexible foundation for your next website.',
						'coreflex'
					); ?>
				</h2>

			</div>

			<div>

				<p>
					<?php esc_html_e(
						'Use this section to introduce your company, explain what you do, and show visitors why they should work with you.',
						'coreflex'
					); ?>
				</p>

			</div>

		</div>

	</section>


	<section id="latest-posts" class="latest-posts-section">

		<div class="container">

			<header class="section-header">

				<p class="eyebrow">
					<?php esc_html_e( 'From the Blog', 'coreflex' ); ?>
				</p>

				<h2>
					<?php esc_html_e( 'Latest Posts', 'coreflex' ); ?>
				</h2>

			</header>


			<div class="posts-grid">

				<?php
				$latest_posts = new WP_Query(
					array(
						'post_type'      => 'post',
						'posts_per_page' => 3,
					)
				);
				?>

				<?php if ( $latest_posts->have_posts() ) : ?>

					<?php while ( $latest_posts->have_posts() ) : ?>

						<?php $latest_posts->the_post(); ?>

						<?php get_template_part( 'template-parts/content' ); ?>

					<?php endwhile; ?>

					<?php wp_reset_postdata(); ?>

				<?php endif; ?>

			</div>

		</div>

	</section>


	<section class="cta-section">

		<div class="container">

			<h2>
				<?php esc_html_e(
					'Ready to get started?',
					'coreflex'
				); ?>
			</h2>

			<p>
				<?php esc_html_e(
					'Create a website that grows with your business.',
					'coreflex'
				); ?>
			</p>

			<a
				class="button button-primary"
				href="<?php echo esc_url( home_url( '/' ) ); ?>"
			>
				<?php esc_html_e( 'Get Started', 'coreflex' ); ?>
			</a>

		</div>

	</section>

</main>

<?php get_footer(); ?>