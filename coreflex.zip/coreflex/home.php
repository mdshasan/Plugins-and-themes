<?php get_header(); ?>

<main id="primary" class="site-main">

	<div class="container">

		<header class="page-header">

			<h1><?php esc_html_e( 'Blog', 'coreflex' ); ?></h1>

		</header>

		<?php if ( have_posts() ) : ?>

			<div class="posts-grid">

				<?php while ( have_posts() ) : the_post(); ?>

					<?php get_template_part( 'template-parts/content' ); ?>

				<?php endwhile; ?>

			</div>

			<?php
			the_posts_pagination(
				array(
					'mid_size'  => 2,
					'prev_text' => __( '← Previous', 'coreflex' ),
					'next_text' => __( 'Next →', 'coreflex' ),
				)
			);
			?>

		<?php else : ?>

			<?php get_template_part( 'template-parts/content', 'none' ); ?>

		<?php endif; ?>

	</div>

</main>

<?php get_footer(); ?>