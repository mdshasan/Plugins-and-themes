<?php get_header(); ?>

<div class="container">

    <section class="error-404">

        <h1>

            <?php esc_html_e( 'Page Not Found', 'coreflex' ); ?>

        </h1>

        <p>

            <?php esc_html_e( 'Sorry, the page you are looking for does not exist.', 'coreflex' ); ?>

        </p>

        <?php get_search_form(); ?>

    </section>

</div>

<?php get_footer(); ?>