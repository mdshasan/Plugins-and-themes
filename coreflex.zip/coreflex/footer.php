<?php
/**
 * The footer for CoreFlex.
 */
?>

<footer class="site-footer">

	<div class="container">

		<div class="footer-widgets">

			<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>

				<div class="footer-widget-area">
					<?php dynamic_sidebar( 'footer-1' ); ?>
				</div>

			<?php endif; ?>

			<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>

				<div class="footer-widget-area">
					<?php dynamic_sidebar( 'footer-2' ); ?>
				</div>

			<?php endif; ?>

			<?php if ( is_active_sidebar( 'footer-3' ) ) : ?>

				<div class="footer-widget-area">
					<?php dynamic_sidebar( 'footer-3' ); ?>
				</div>

			<?php endif; ?>

		</div>

		<?php
		wp_nav_menu(
			array(
				'theme_location'      => 'footer',
				'menu_id'             => 'footer-menu',
				'menu_class'          => 'footer-menu',
				'container'           => 'nav',
				'container_class'     => 'footer-navigation',
				'container_aria_label' => __( 'Footer menu', 'coreflex' ),
				'fallback_cb'          => false,
			)
		);
		?>

		<?php
		$social_links = array(
			'facebook' => get_theme_mod( 'coreflex_social_facebook' ),
			'linkedin' => get_theme_mod( 'coreflex_social_linkedin' ),
			'x'        => get_theme_mod( 'coreflex_social_x' ),
		);
		?>

		<?php if ( array_filter( $social_links ) ) : ?>

			<div class="footer-social">

				<?php foreach ( $social_links as $network => $url ) : ?>

					<?php if ( $url ) : ?>

						<a
							href="<?php echo esc_url( $url ); ?>"
							rel="noopener noreferrer"
							target="_blank"
							aria-label="<?php echo esc_attr( ucfirst( $network ) ); ?>"
						>
							<?php echo esc_html( ucfirst( $network ) ); ?>
						</a>

					<?php endif; ?>

				<?php endforeach; ?>

			</div>

		<?php endif; ?>

		<div class="site-info">

			<?php
			$copyright = get_theme_mod(
				'coreflex_copyright',
				sprintf(
					/* translators: %s: current year. */
					__( '© %s CoreFlex', 'coreflex' ),
					date_i18n( 'Y' )
				)
			);
			?>

			<p><?php echo esc_html( $copyright ); ?></p>

		</div>

	</div>

</footer>

<?php wp_footer(); ?>

</body>
</html>