<?php get_header(); ?>

<div class="container">

    <header class="search-header">

        <h1>

            <?php
            printf(
                esc_html__( 'Search Results for: "%s"', 'coreflex' ),
                esc_html( get_search_query() )
            );
            ?>

        </h1>

    </header>

    <?php if ( have_posts() ) : ?>

        <?php while ( have_posts() ) : the_post(); ?>

            <?php get_template_part( 'template-parts/content' ); ?>

        <?php endwhile; ?>

        <?php the_posts_pagination(); ?>

    <?php else : ?>

        <?php get_template_part( 'template-parts/content', 'none' ); ?>

    <?php endif; ?>

</div>

<?php get_footer(); ?>