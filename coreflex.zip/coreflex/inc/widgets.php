<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function coreflex_widgets_init() {

	register_sidebar(
		array(
			'name'          => __( 'Main Sidebar', 'coreflex' ),
			'id'            => 'main-sidebar',
			'description'   => __( 'Main blog sidebar.', 'coreflex' ),
			'before_widget' => '<section class="widget">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Footer 1', 'coreflex' ),
			'id'            => 'footer-1',
			'description'   => __( 'First footer widget area.', 'coreflex' ),
			'before_widget' => '<section class="widget">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Footer 2', 'coreflex' ),
			'id'            => 'footer-2',
			'description'   => __( 'Second footer widget area.', 'coreflex' ),
			'before_widget' => '<section class="widget">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Footer 3', 'coreflex' ),
			'id'            => 'footer-3',
			'description'   => __( 'Third footer widget area.', 'coreflex' ),
			'before_widget' => '<section class="widget">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

}

add_action( 'widgets_init', 'coreflex_widgets_init' );