<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function coreflex_enqueue_assets() {

	wp_enqueue_style(
		'coreflex-style',
		get_stylesheet_uri(),
		array(),
		wp_get_theme()->get( 'Version' )
	);

	wp_enqueue_style(
		'coreflex-main-style',
		get_template_directory_uri() . '/assets/css/style.css',
		array( 'coreflex-style' ),
		wp_get_theme()->get( 'Version' )
	);

	wp_enqueue_script(
		'coreflex-main-js',
		get_template_directory_uri() . '/assets/js/main.js',
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);

}

add_action( 'wp_enqueue_scripts', 'coreflex_enqueue_assets' );