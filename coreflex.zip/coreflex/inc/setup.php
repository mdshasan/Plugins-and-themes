<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function coreflex_setup() {

	load_theme_textdomain(
		'coreflex',
		get_template_directory() . '/languages'
	);

	add_theme_support( 'title-tag' );

	add_theme_support( 'post-thumbnails' );

	add_theme_support( 'custom-logo' );

	add_theme_support( 'custom-background' );

	add_theme_support( 'custom-header' );
	add_theme_support( 'woocommerce' );

	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	register_nav_menus(
	array(
		'primary' => esc_html__( 'Primary Menu', 'coreflex' ),
		'footer'  => esc_html__( 'Footer Menu', 'coreflex' ),
	)
);

}

add_action( 'after_setup_theme', 'coreflex_setup' );