<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function coreflex_customize_register( $wp_customize ) {

	/*
	 * Contact Information
	 */
	$wp_customize->add_section(
		'coreflex_contact',
		array(
			'title'    => __( 'Contact Information', 'coreflex' ),
			'priority' => 30,
		)
	);

	$wp_customize->add_setting(
		'coreflex_phone',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	$wp_customize->add_control(
		'coreflex_phone',
		array(
			'label'   => __( 'Phone Number', 'coreflex' ),
			'section' => 'coreflex_contact',
			'type'    => 'text',
		)
	);

	$wp_customize->add_setting(
		'coreflex_email',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_email',
		)
	);

	$wp_customize->add_control(
		'coreflex_email',
		array(
			'label'   => __( 'Email Address', 'coreflex' ),
			'section' => 'coreflex_contact',
			'type'    => 'email',
		)
	);


	/*
	 * Social Links
	 */
	$wp_customize->add_section(
		'coreflex_social',
		array(
			'title'    => __( 'Social Links', 'coreflex' ),
			'priority' => 35,
		)
	);

	$social_networks = array(
		'facebook'  => __( 'Facebook URL', 'coreflex' ),
		'linkedin'  => __( 'LinkedIn URL', 'coreflex' ),
		'x'         => __( 'X URL', 'coreflex' ),
	);

	foreach ( $social_networks as $network => $label ) {

		$wp_customize->add_setting(
			'coreflex_social_' . $network,
			array(
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
			)
		);

		$wp_customize->add_control(
			'coreflex_social_' . $network,
			array(
				'label'   => $label,
				'section' => 'coreflex_social',
				'type'    => 'url',
			)
		);
	}


	/*
	 * Footer
	 */
	$wp_customize->add_section(
		'coreflex_footer',
		array(
			'title'    => __( 'Footer Settings', 'coreflex' ),
			'priority' => 40,
		)
	);

	$wp_customize->add_setting(
		'coreflex_copyright',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	$wp_customize->add_control(
		'coreflex_copyright',
		array(
			'label'       => __( 'Copyright Text', 'coreflex' ),
			'description' => __( 'Leave empty to use the default copyright text.', 'coreflex' ),
			'section'     => 'coreflex_footer',
			'type'        => 'text',
		)
	);

}

add_action( 'customize_register', 'coreflex_customize_register' );