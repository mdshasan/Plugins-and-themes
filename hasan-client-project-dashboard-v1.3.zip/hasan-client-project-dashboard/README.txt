# Hasan Client Project Dashboard v1.1

A client-specific WordPress project portal inspired by the supplied dashboard screenshot.

## What changed in v1.1
- Reworked frontend to closely match the supplied screenshot: compact header/brand block, project summary card, two-column card grid, timeline, links, action table, payment milestones, latest updates and footer.
- Added demo content for **Luxury Garden Landscape**.
- Added demo project photo and demo brand/logo assets.
- Added a backend-managed logo URL field.
- Fixed the repeater system: **+ Add item** now creates a real editable row in Timeline, Links, Actions, Payments and Updates.
- Remove buttons work and row names are rebuilt before saving.
- Repeater values are saved as normal WordPress post meta arrays rather than depending on a hidden JSON field created by JavaScript.
- Added six demo updates so **View All Updates** can expand additional updates.
- Kept client-specific data: every Client Dashboard post has its own shortcode and its own information.
- Client Contact Us / Need Help form still sends email through `wp_mail()` to that dashboard's recipient email.

## Installation
1. Remove/deactivate the previous version if necessary.
2. Upload this ZIP through **Plugins → Add New → Upload Plugin**.
3. Activate the plugin.
4. Go to **Client Dashboards**.
5. A demo dashboard named **Demo – Luxury Garden Landscape** is created automatically on activation.
6. Open the demo dashboard and change any information from the backend.
7. Copy its shortcode from the **Frontend Shortcode** box.
8. Put that shortcode on the client's private page.

Shortcode example:
`[client_project_dashboard id="123"]`

## Backend repeaters
These tabs now have working add/remove controls:
- 3. Timeline
- 4. Links
- 5. Actions
- 6. Payments
- 7. Updates

Click **+ Add item**, fill the new row, then click **Update** or **Publish**. The item will appear on the client dashboard.

## Client-specific setup
Create one Client Dashboard post per client. For example:
- Client A → Dashboard post ID 101 → `[client_project_dashboard id="101"]`
- Client B → Dashboard post ID 102 → `[client_project_dashboard id="102"]`

Each client therefore sees only the information stored in their own dashboard post.

## Email messaging
The frontend message form sends the message to the **Message recipient email** configured in that client's Support tab. For reliable delivery, configure an SMTP plugin such as WP Mail SMTP.


PRIVATE DASHBOARD ACCESS (v1.2)
--------------------------------
1. Create a WordPress user for each client (Users -> Add New).
2. Edit that client's Client Dashboard.
3. In the Project tab, select that user's name under "Client login user".
4. Put the dashboard shortcode on the client's page.
5. A logged-out visitor is sent to WordPress login. A logged-in user who is not assigned to the dashboard receives Access Restricted. Administrators can always view every dashboard.

IMPORTANT: Exclude client dashboard pages from full-page caching/CDN caching, or configure caching to vary by logged-in user. Otherwise a cached private page could be served to another visitor. Files linked from the dashboard (such as PDFs) are not automatically protected by this feature; use protected/private document storage if those files are confidential.
