<?php
/**
 * Plugin Name: Hasan Client Project Dashboard
 * Description: Client-specific project dashboards with a polished client portal, editable repeaters, payment milestones, updates, links, action items and email messaging.
 * Version: 1.3.0
 * Author: Hasan
 */

if (!defined('ABSPATH')) exit;

class Hasan_Client_Project_Dashboard {
    const CPT = 'hpd_client';
    const NONCE = 'hpd_nonce';
    const VERSION = '1.3.0';

    public function __construct() {
        add_action('init', [$this, 'register_cpt']);
        add_action('add_meta_boxes', [$this, 'add_meta_boxes']);
        add_action('save_post_' . self::CPT, [$this, 'save_meta'], 10, 2);
        add_shortcode('client_project_dashboard', [$this, 'shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'register_frontend']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin']);
        add_action('admin_init', [$this, 'maybe_create_demo']);
        add_action('wp_ajax_hpd_send_message', [$this, 'send_message']);
        add_filter('manage_' . self::CPT . '_posts_columns', [$this, 'columns']);
        add_action('manage_' . self::CPT . '_posts_custom_column', [$this, 'column_content'], 10, 2);
    }

    public static function activate() {
        $self = new self();
        $self->register_cpt();
        flush_rewrite_rules();
        if (!get_option('hpd_demo_created')) {
            $self->create_demo();
            update_option('hpd_demo_created', 1);
        }
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    public function maybe_create_demo() {
        if (!current_user_can('manage_options') || get_option('hpd_demo_created')) return;
        $existing = get_posts(['post_type'=>self::CPT, 'post_status'=>'any', 'numberposts'=>1, 'fields'=>'ids']);
        if (!$existing) $this->create_demo();
        update_option('hpd_demo_created', 1);
    }

    private function create_demo() {
        $id = wp_insert_post([
            'post_type' => self::CPT,
            'post_status' => 'publish',
            'post_title' => 'Demo – Luxury Garden Landscape',
        ]);
        if (is_wp_error($id) || !$id) return;

        $values = [
            'welcome' => "Welcome, John! Here's the latest update on your project.",
            'client' => 'John Doe',
            'project' => 'Luxury Garden Landscape',
            'type' => 'Website Development',
            'project_id' => 'LG-2505',
            'start_date' => 'May 20, 2025',
            'completion' => 'June 30, 2025',
            'manager' => 'Imran Hossain',
            'status' => 'In Progress',
            'progress' => 65,
            'project_image' => plugins_url('assets/demo-house.jpg', __FILE__),
            'logo' => plugins_url('assets/demo-logo.jpg', __FILE__),
            'current_phase' => 'Homepage Design',
            'overview_text' => 'We are currently working on the homepage design. Once you approve, we will move forward with inner pages development.',
            'support_hours' => 'Mon – Fri (10 AM – 7 PM)',
            'support_email' => get_option('admin_email'),
            'support_phone' => '+880 1723-XXXXXX',
            'recipient_email' => get_option('admin_email'),
            'footer_note' => 'Your project is in safe hands. We are committed to delivering high quality work and a great experience.',
            'privacy_note' => 'These links are private and only for you. Please do not share them with others.',
        ];
        foreach ($values as $key => $value) update_post_meta($id, '_hpd_' . $key, $value);

        $repeaters = [
            'timeline' => [
                ['title'=>'Discovery & Requirements','date'=>'May 20, 2025','status'=>'Completed'],
                ['title'=>'Proposal Approved','date'=>'May 22, 2025','status'=>'Completed'],
                ['title'=>'Deposit Received','date'=>'May 23, 2025','status'=>'Completed'],
                ['title'=>'Homepage Design','date'=>'','status'=>'In Progress'],
                ['title'=>'Development','date'=>'','status'=>'Pending'],
                ['title'=>'Testing & Review','date'=>'','status'=>'Pending'],
                ['title'=>'Launch','date'=>'','status'=>'Pending'],
            ],
            'links' => [
                ['title'=>'Proposal PDF','url'=>'https://example.com/proposal','subtitle'=>'View Proposal'],
                ['title'=>'Invoice','url'=>'https://example.com/invoice','subtitle'=>'View Invoice'],
                ['title'=>'Payment Guide','url'=>'https://example.com/payment-guide','subtitle'=>'Payment Details'],
                ['title'=>'Staging Website','url'=>'https://example.com/staging','subtitle'=>'Open Site'],
                ['title'=>'Google Drive','url'=>'https://drive.google.com/','subtitle'=>'Project Assets'],
                ['title'=>'Meeting Notes','url'=>'https://example.com/meeting-notes','subtitle'=>'View Notes'],
            ],
            'actions' => [
                ['task'=>'Provide Logo','priority'=>'Low','status'=>'Pending','due'=>'May 25, 2025'],
                ['task'=>'Brand Guide / Colors','priority'=>'Medium','status'=>'Pending','due'=>'May 25, 2025'],
                ['task'=>'Homepage Content','priority'=>'High','status'=>'Pending','due'=>'May 27, 2025'],
                ['task'=>'Team Photos','priority'=>'Low','status'=>'Pending','due'=>'May 30, 2025'],
            ],
            'payments' => [
                ['milestone'=>'1. Deposit (30%)','amount'=>'$900','status'=>'Paid','due'=>'May 23, 2025'],
                ['milestone'=>'2. Development (30%)','amount'=>'$900','status'=>'Pending','due'=>'June 10, 2025'],
                ['milestone'=>'3. Final Payment (40%)','amount'=>'$1,200','status'=>'Pending','due'=>'June 30, 2025'],
            ],
            'updates' => [
                ['date'=>'May 28, 2025','time'=>'10:30 AM','title'=>'Homepage design completed','text'=>'Homepage design is ready for your review. Please check the staging website.','badge'=>'New'],
                ['date'=>'May 28, 2025','time'=>'09:15 PM','title'=>'Received all required content','text'=>'Thank you! We have received the content you provided.','badge'=>''],
                ['date'=>'May 24, 2025','time'=>'11:20 AM','title'=>'Project kick-off meeting completed','text'=>'We discussed the project goals, scope and timeline.','badge'=>''],
                ['date'=>'May 22, 2025','time'=>'02:45 PM','title'=>'Proposal approved','text'=>'Thank you for approving the proposal. Let’s build something amazing together!','badge'=>''],
                ['date'=>'May 21, 2025','time'=>'04:10 PM','title'=>'Project workspace created','text'=>'Your private project workspace is ready and the initial project files have been organised.','badge'=>''],
            ],
        ];
        foreach ($repeaters as $key => $rows) update_post_meta($id, '_hpd_' . $key, wp_json_encode($rows));
    }

    public function register_cpt() {
        register_post_type(self::CPT, [
            'labels' => [
                'name' => 'Client Dashboards',
                'singular_name' => 'Client Dashboard',
                'add_new_item' => 'Add Client Dashboard',
                'edit_item' => 'Edit Client Dashboard',
                'menu_name' => 'Client Dashboards',
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-dashboard',
            'supports' => ['title'],
            'capability_type' => 'post',
            'map_meta_cap' => true,
        ]);
    }

    public function add_meta_boxes() {
        add_meta_box('hpd_details', 'Client Project Dashboard', [$this, 'render_meta_box'], self::CPT, 'normal', 'high');
        add_meta_box('hpd_shortcode', 'Frontend Shortcode', [$this, 'render_shortcode_box'], self::CPT, 'side', 'high');
    }

    private function get($post_id, $key, $default = '') {
        $v = get_post_meta($post_id, '_hpd_' . $key, true);
        return $v === '' ? $default : $v;
    }

    private function demo_rows($type) {
        $demo = [
            'timeline' => [
                ['title'=>'Discovery & Requirements','date'=>'May 20, 2025','status'=>'Completed'],
                ['title'=>'Proposal Approved','date'=>'May 22, 2025','status'=>'Completed'],
                ['title'=>'Deposit Received','date'=>'May 23, 2025','status'=>'Completed'],
                ['title'=>'Homepage Design','date'=>'','status'=>'In Progress'],
                ['title'=>'Development','date'=>'','status'=>'Pending'],
                ['title'=>'Testing & Review','date'=>'','status'=>'Pending'],
                ['title'=>'Launch','date'=>'','status'=>'Pending'],
            ],
            'links' => [
                ['title'=>'Proposal PDF','url'=>'https://example.com/proposal','subtitle'=>'View Proposal'],
                ['title'=>'Invoice','url'=>'https://example.com/invoice','subtitle'=>'View Invoice'],
                ['title'=>'Payment Guide','url'=>'https://example.com/payment-guide','subtitle'=>'Payment Details'],
                ['title'=>'Staging Website','url'=>'https://example.com/staging','subtitle'=>'Open Site'],
                ['title'=>'Google Drive','url'=>'https://drive.google.com/','subtitle'=>'Project Assets'],
                ['title'=>'Meeting Notes','url'=>'https://example.com/meeting-notes','subtitle'=>'View Notes'],
            ],
            'actions' => [
                ['task'=>'Provide Logo','priority'=>'Low','status'=>'Pending','due'=>'May 25, 2025'],
                ['task'=>'Brand Guide / Colors','priority'=>'Medium','status'=>'Pending','due'=>'May 25, 2025'],
                ['task'=>'Homepage Content','priority'=>'High','status'=>'Pending','due'=>'May 27, 2025'],
                ['task'=>'Team Photos','priority'=>'Low','status'=>'Pending','due'=>'May 30, 2025'],
            ],
            'payments' => [
                ['milestone'=>'1. Deposit (30%)','amount'=>'$900','status'=>'Paid','due'=>'May 23, 2025'],
                ['milestone'=>'2. Development (30%)','amount'=>'$900','status'=>'Pending','due'=>'June 10, 2025'],
                ['milestone'=>'3. Final Payment (40%)','amount'=>'$1,200','status'=>'Pending','due'=>'June 30, 2025'],
            ],
            'updates' => [
                ['date'=>'May 28, 2025','time'=>'10:30 AM','title'=>'Homepage design completed','text'=>'Homepage design is ready for your review. Please check the staging website.','badge'=>'New'],
                ['date'=>'May 28, 2025','time'=>'09:15 PM','title'=>'Received all required content','text'=>'Thank you! We have received the content you provided.','badge'=>''],
                ['date'=>'May 24, 2025','time'=>'11:20 AM','title'=>'Project kick-off meeting completed','text'=>'We discussed the project goals, scope and timeline.','badge'=>''],
                ['date'=>'May 22, 2025','time'=>'02:45 PM','title'=>'Proposal approved','text'=>'Thank you for approving the proposal. Let’s build something amazing together!','badge'=>''],
                ['date'=>'May 21, 2025','time'=>'04:10 PM','title'=>'Project workspace created','text'=>'Your private project workspace is ready and the initial project files have been organised.','badge'=>''],
            ],
        ];
        return isset($demo[$type]) ? $demo[$type] : [];
    }

    private function repeater_data($post_id, $type) {
        $raw = get_post_meta($post_id, '_hpd_' . $type, true);
        if ($raw === '') return $this->demo_rows($type);
        $rows = is_array($raw) ? $raw : json_decode($raw, true);
        return is_array($rows) ? $rows : [];
    }

    public function render_shortcode_box($post) {
        $shortcode = '[client_project_dashboard id="' . $post->ID . '"]';
        echo '<p>Put this shortcode on this client\'s private WordPress page.</p>';
        echo '<input type="text" readonly class="widefat" value="' . esc_attr($shortcode) . '" onclick="this.select();">';
        echo '<p><small>Every Client Dashboard post stores its own project data. Five client pages can therefore use five different dashboard IDs.</small></p>';
    }

    private function text_input($label, $name, $value, $placeholder = '') {
        echo '<div class="hpd-field"><label><strong>' . esc_html($label) . '</strong></label>';
        echo '<input type="text" name="hpd[' . esc_attr($name) . ']" value="' . esc_attr($value) . '" placeholder="' . esc_attr($placeholder) . '">';
        echo '</div>';
    }

    private function textarea($label, $name, $value, $placeholder = '') {
        echo '<div class="hpd-field"><label><strong>' . esc_html($label) . '</strong></label>';
        echo '<textarea name="hpd[' . esc_attr($name) . ']" rows="4" placeholder="' . esc_attr($placeholder) . '">' . esc_textarea($value) . '</textarea>';
        echo '</div>';
    }

    public function render_meta_box($post) {
        wp_nonce_field(self::NONCE, self::NONCE);
        $d = function($k, $def='') use ($post) { return $this->get($post->ID, $k, $def); };
        $timeline = $this->repeater_data($post->ID, 'timeline');
        $links = $this->repeater_data($post->ID, 'links');
        $actions = $this->repeater_data($post->ID, 'actions');
        $payments = $this->repeater_data($post->ID, 'payments');
        $updates = $this->repeater_data($post->ID, 'updates');
        ?>
        <div class="hpd-admin-wrap">
            <div class="hpd-admin-tabs" role="tablist">
                <button type="button" class="active" data-tab="basic">1. Project</button>
                <button type="button" data-tab="overview">2. Overview</button>
                <button type="button" data-tab="timeline">3. Timeline</button>
                <button type="button" data-tab="links">4. Links</button>
                <button type="button" data-tab="actions">5. Actions</button>
                <button type="button" data-tab="payments">6. Payments</button>
                <button type="button" data-tab="updates">7. Updates</button>
                <button type="button" data-tab="support">8. Support</button>
            </div>

            <section class="hpd-tab active" id="hpd-tab-basic">
                <h3>Project Header</h3>
                <?php
                $this->text_input('Welcome line', 'welcome', $d('welcome','Welcome, {client}! Here\'s the latest update on your project.'));
                $this->text_input('Client name', 'client', $d('client','John Doe'));
                $this->text_input('Project title', 'project', $d('project','Luxury Garden Landscape'));
                $this->text_input('Project type', 'type', $d('type','Website Development'));
                $this->text_input('Project ID', 'project_id', $d('project_id','LG-2505'));
                $this->text_input('Start date', 'start_date', $d('start_date','May 20, 2025'));
                $this->text_input('Estimated completion', 'completion', $d('completion','June 30, 2025'));
                $this->text_input('Project manager', 'manager', $d('manager','Imran Hossain'));
                $this->text_input('Status label', 'status', $d('status','In Progress'));
                ?>
                <div class="hpd-field"><label><strong>Overall progress (%)</strong></label>
                    <input type="number" min="0" max="100" name="hpd[progress]" value="<?php echo esc_attr($d('progress','65')); ?>">
                </div>
                <?php
                $this->text_input('Project image URL', 'project_image', $d('project_image',plugins_url('assets/demo-house.jpg',__FILE__)), 'Paste image URL or Media Library URL');
                $this->text_input('Brand/logo image URL', 'logo', $d('logo',plugins_url('assets/demo-logo.jpg',__FILE__)), 'Optional logo URL');
                ?>
                <div class="hpd-field">
                    <label><strong>Client login user</strong></label>
                    <?php $assigned_user = absint($d('client_user_id', 0)); ?>
                    <select name="hpd[client_user_id]" style="width:100%;">
                        <option value="0">— Select the WordPress user who owns this dashboard —</option>
                        <?php
                        $users = get_users(['orderby'=>'display_name','order'=>'ASC','fields'=>['ID','display_name','user_email']]);
                        foreach ($users as $user) {
                            printf('<option value="%d" %s>%s (%s)</option>', absint($user->ID), selected($assigned_user, $user->ID, false), esc_html($user->display_name), esc_html($user->user_email));
                        }
                        ?>
                    </select>
                    <p class="description">Only this logged-in WordPress user can view this dashboard. Administrators can always access it.</p>
                </div>
                <p class="description">For client-specific images, upload them in Media → Library and paste the URL here.</p>
            </section>

            <section class="hpd-tab" id="hpd-tab-overview">
                <h3>Project Overview</h3>
                <?php
                $this->text_input('Current phase', 'current_phase', $d('current_phase','Homepage Design'));
                $this->textarea('Overview description', 'overview_text', $d('overview_text','We are currently working on the homepage design. Once you approve, we will move forward with the inner pages development.'));
                ?>
            </section>

            <?php $this->render_repeater_tab('timeline', 'Project Timeline', $timeline, ['title'=>'Stage', 'date'=>'Date', 'status'=>'Status']); ?>
            <?php $this->render_repeater_tab('links', 'Important Links', $links, ['title'=>'Link title', 'url'=>'URL', 'subtitle'=>'Small description']); ?>
            <?php $this->render_repeater_tab('actions', 'Action Required From You', $actions, ['task'=>'Task', 'priority'=>'Priority', 'status'=>'Status', 'due'=>'Due date']); ?>
            <?php $this->render_repeater_tab('payments', 'Payment Milestones', $payments, ['milestone'=>'Milestone', 'amount'=>'Amount', 'status'=>'Status', 'due'=>'Due date']); ?>
            <?php $this->render_repeater_tab('updates', 'Latest Updates', $updates, ['date'=>'Date', 'time'=>'Time', 'title'=>'Update title', 'text'=>'Update details', 'badge'=>'Badge']); ?>

            <section class="hpd-tab" id="hpd-tab-support">
                <h3>Support & Client Messaging</h3>
                <?php
                $this->text_input('Support hours', 'support_hours', $d('support_hours','Mon – Fri (10 AM – 7 PM)'));
                $this->text_input('Support email', 'support_email', $d('support_email', get_option('admin_email')));
                $this->text_input('Support phone / WhatsApp', 'support_phone', $d('support_phone','+880 1723-XXXXXX'));
                $this->text_input('Message recipient email', 'recipient_email', $d('recipient_email', get_option('admin_email')));
                $this->textarea('Footer safety note', 'footer_note', $d('footer_note','Your project is in safe hands. We are committed to delivering high quality work and a great experience.'));
                $this->textarea('Private links note', 'privacy_note', $d('privacy_note','These links are private and only for you. Please do not share them with others.'));
                ?>
                <p><strong>Client messaging:</strong> the frontend Contact Us / Need Help form sends an email to the per-client Message Recipient Email.</p>
            </section>
        </div>
        <?php
    }

    private function render_repeater_tab($id, $heading, $rows, $fields) {
        $template = [];
        foreach ($fields as $key => $label) $template[$key] = '';
        ?>
        <section class="hpd-tab" id="hpd-tab-<?php echo esc_attr($id); ?>">
            <div class="hpd-repeater-head">
                <div><h3><?php echo esc_html($heading); ?></h3><p>Click <strong>+ Add item</strong> to add another <?php echo esc_html(rtrim(strtolower($heading), 's')); ?>. You can remove or edit any item before updating the dashboard.</p></div>
                <button type="button" class="button button-primary hpd-add-row">+ Add item</button>
            </div>
            <div class="hpd-repeater" data-repeater="<?php echo esc_attr($id); ?>">
                <div class="hpd-repeater-rows">
                    <?php foreach ($rows as $index => $row) $this->render_repeater_row($id, $fields, $row, $index); ?>
                </div>
                <template class="hpd-row-template"><?php $this->render_repeater_row($id, $fields, $template, '__INDEX__'); ?></template>
            </div>
        </section>
        <?php
    }

    private function render_repeater_row($type, $fields, $row, $index) {
        echo '<div class="hpd-row" data-type="' . esc_attr($type) . '" data-index="' . esc_attr($index) . '">';
        foreach ($fields as $key => $label) {
            $val = isset($row[$key]) ? $row[$key] : '';
            $name = 'hpd[' . $type . '][' . $index . '][' . $key . ']';
            $tag = in_array($key, ['text','subtitle'], true) ? 'textarea' : 'input';
            echo '<div class="hpd-row-field"><label>' . esc_html($label) . '</label>';
            if ($tag === 'textarea') {
                echo '<textarea name="' . esc_attr($name) . '" data-key="' . esc_attr($key) . '" rows="2">' . esc_textarea($val) . '</textarea>';
            } else {
                echo '<input type="text" name="' . esc_attr($name) . '" data-key="' . esc_attr($key) . '" value="' . esc_attr($val) . '">';
            }
            echo '</div>';
        }
        echo '<button type="button" class="button-link-delete hpd-remove-row">Remove</button>';
        echo '</div>';
    }

    public function save_meta($post_id, $post) {
        if (!isset($_POST[self::NONCE]) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::NONCE])), self::NONCE)) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;
        if (!isset($_POST['hpd']) || !is_array($_POST['hpd'])) return;

        $raw = wp_unslash($_POST['hpd']);
        $simple = ['welcome','client','project','type','project_id','start_date','completion','manager','status','project_image','logo','current_phase','overview_text','support_hours','support_email','support_phone','recipient_email','footer_note','privacy_note'];
        foreach ($simple as $key) {
            if (!isset($raw[$key])) continue;
            $value = in_array($key, ['support_email','recipient_email'], true) ? sanitize_email($raw[$key]) : sanitize_textarea_field($raw[$key]);
            if (in_array($key, ['project_image','logo'], true)) $value = esc_url_raw($raw[$key]);
            update_post_meta($post_id, '_hpd_' . $key, $value);
        }
        if (isset($raw['client_user_id'])) update_post_meta($post_id, '_hpd_client_user_id', absint($raw['client_user_id']));
        if (isset($raw['progress'])) update_post_meta($post_id, '_hpd_progress', max(0, min(100, intval($raw['progress']))));

        $field_sets = [
            'timeline' => ['title','date','status'],
            'links' => ['title','url','subtitle'],
            'actions' => ['task','priority','status','due'],
            'payments' => ['milestone','amount','status','due'],
            'updates' => ['date','time','title','text','badge'],
        ];
        foreach ($field_sets as $type => $keys) {
            if (!isset($raw[$type]) || !is_array($raw[$type])) {
                update_post_meta($post_id, '_hpd_' . $type, wp_json_encode([]));
                continue;
            }
            $clean = [];
            foreach ($raw[$type] as $row) {
                if (!is_array($row)) continue;
                $item = [];
                foreach ($keys as $key) {
                    if (!array_key_exists($key, $row)) continue;
                    $item[$key] = $key === 'url' ? esc_url_raw($row[$key]) : sanitize_textarea_field($row[$key]);
                }
                $has_value = false;
                foreach ($item as $value) { if ($value !== '') { $has_value = true; break; } }
                if ($has_value) $clean[] = $item;
            }
            update_post_meta($post_id, '_hpd_' . $type, wp_json_encode($clean));
        }
    }

    public function enqueue_admin($hook) {
        global $post;
        if (($hook === 'post.php' || $hook === 'post-new.php') && $post && $post->post_type === self::CPT) {
            wp_enqueue_style('hpd-admin', plugins_url('assets/admin.css', __FILE__), [], self::VERSION);
            wp_enqueue_script('hpd-admin', plugins_url('assets/admin.js', __FILE__), ['jquery'], self::VERSION, true);
        }
    }

    public function register_frontend() {
        wp_register_style('hpd-front', plugins_url('assets/frontend.css', __FILE__), [], self::VERSION);
        wp_register_script('hpd-front', plugins_url('assets/frontend.js', __FILE__), ['jquery'], self::VERSION, true);
        wp_localize_script('hpd-front', 'HPD_AJAX', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('hpd_message'),
        ]);
    }

    private function data($post_id) {
        $d = function($k,$def='') use ($post_id){ return $this->get($post_id,$k,$def); };
        return [
            'welcome'=>$d('welcome',"Welcome, John! Here's the latest update on your project."),
            'client'=>$d('client','John Doe'),
            'project'=>$d('project','Luxury Garden Landscape'),
            'type'=>$d('type','Website Development'),
            'project_id'=>$d('project_id','LG-2505'),
            'start_date'=>$d('start_date','May 20, 2025'),
            'completion'=>$d('completion','June 30, 2025'),
            'manager'=>$d('manager','Imran Hossain'),
            'status'=>$d('status','In Progress'),
            'progress'=>max(0,min(100,intval($d('progress','65')))),
            'project_image'=>$d('project_image',plugins_url('assets/demo-house.jpg',__FILE__)),
            'logo'=>$d('logo',plugins_url('assets/demo-logo.jpg',__FILE__)),
            'client_user_id'=>absint($d('client_user_id',0)),
            'current_phase'=>$d('current_phase','Homepage Design'),
            'overview_text'=>$d('overview_text','We are currently working on the homepage design. Once you approve, we will move forward with the inner pages development.'),
            'timeline'=>$this->repeater_data($post_id,'timeline'),
            'links'=>$this->repeater_data($post_id,'links'),
            'actions'=>$this->repeater_data($post_id,'actions'),
            'payments'=>$this->repeater_data($post_id,'payments'),
            'updates'=>$this->repeater_data($post_id,'updates'),
            'support_hours'=>$d('support_hours','Mon – Fri (10 AM – 7 PM)'),
            'support_email'=>$d('support_email',get_option('admin_email')),
            'support_phone'=>$d('support_phone','+880 1723-XXXXXX'),
            'recipient_email'=>$d('recipient_email',get_option('admin_email')),
            'footer_note'=>$d('footer_note','Your project is in safe hands. We are committed to delivering high quality work and a great experience.'),
            'privacy_note'=>$d('privacy_note','These links are private and only for you. Please do not share them with others.'),
        ];
    }

    private function icon($name) {
        $icons = [
            'calendar'=>'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="17" rx="3"></rect><path d="M8 2v4M16 2v4M3 9h18"></path></svg>',
            'link'=>'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.1.1l2-2a5 5 0 0 0-7.1-7.1l-1.1 1.1"></path><path d="M14 11a5 5 0 0 0-7.1-.1l-2 2A5 5 0 0 0 7 20l1.1-1.1"></path></svg>',
            'user'=>'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"></circle><path d="M5 20a7 7 0 0 1 14 0"></path></svg>',
            'project'=>'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="3"></rect><path d="m3 16 5-5 4 4 3-3 6 6"></path></svg>',
            'shield'=>'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 20 6v5c0 5-3.3 8.4-8 10-4.7-1.6-8-5-8-10V6l8-3Z"></path><path d="m8.5 12 2.2 2.2 4.8-5"></path></svg>',
            'chat'=>'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5.5A3.5 3.5 0 0 1 7.5 2h9A3.5 3.5 0 0 1 20 5.5v6A3.5 3.5 0 0 1 16.5 15H11l-5 4v-4.4A3.5 3.5 0 0 1 4 11.5v-6Z"></path></svg>',
        ];
        return isset($icons[$name]) ? $icons[$name] : '';
    }

    private function replace_client($text,$client) { return str_replace(['{client}','[client]'], $client, $text); }

    private function can_access_dashboard($post_id) {
        if (!$post_id || get_post_type($post_id) !== self::CPT) return false;
        if (current_user_can('manage_options')) return true;
        if (!is_user_logged_in()) return false;
        $assigned_user = absint(get_post_meta($post_id, '_hpd_client_user_id', true));
        return $assigned_user > 0 && get_current_user_id() === $assigned_user;
    }

    private function access_denied_markup($id) {
        if (!is_user_logged_in()) {
            $login_url = wp_login_url(get_permalink());
            return '<div class="hpd-access-denied"><h3>Client Login Required</h3><p>Please log in with the WordPress account assigned to this project to access your private dashboard.</p><a href="' . esc_url($login_url) . '">Log in to your dashboard</a></div>';
        }
        return '<div class="hpd-access-denied"><h3>Access Restricted</h3><p>This dashboard is private and is only available to the assigned client account.</p></div>';
    }

    public function shortcode($atts) {
        $atts=shortcode_atts(['id'=>0],$atts,'client_project_dashboard');
        $id=absint($atts['id']);
        if (!$id || get_post_type($id)!==self::CPT) return '<p>Client dashboard not found.</p>';
        if (!$this->can_access_dashboard($id)) return $this->access_denied_markup($id);
        wp_enqueue_style('hpd-front');
        wp_enqueue_script('hpd-front');
        $d=$this->data($id);
        ob_start();
        ?>
        <div class="hpd-dashboard" data-dashboard-id="<?php echo esc_attr($id); ?>">
            <header class="hpd-top">
                <div class="hpd-brand"><div class="hpd-logo-wrap"><?php if($d['logo']): ?><img src="<?php echo esc_url($d['logo']); ?>" alt="Brand logo"><?php endif; ?></div></div>
                <div class="hpd-welcome"><h1>Client Project Dashboard <span>👋</span></h1><p><?php echo esc_html($this->replace_client($d['welcome'],$d['client'])); ?></p></div>
                <button type="button" class="hpd-contact-btn" data-open-message><span class="hpd-help-icon"><?php echo $this->icon('chat'); ?></span><span><small>Need Help?</small>Contact Us</span></button>
            </header>

            <section class="hpd-hero">
                <div class="hpd-project-image"><img src="<?php echo esc_url($d['project_image']); ?>" alt="<?php echo esc_attr($d['project']); ?>"></div>
                <div class="hpd-project-main">
                    <div class="hpd-title-row"><h2><?php echo esc_html($d['project']); ?></h2><span class="hpd-pill"><?php echo esc_html($d['status']); ?></span></div>
                    <div class="hpd-type"><?php echo $this->icon('project'); ?> <?php echo esc_html($d['type']); ?></div>
                    <div class="hpd-meta">
                        <?php if ($d['project_id']): ?><div><span class="hpd-meta-icon"><?php echo $this->icon('project'); ?></span><small>Project ID</small><strong><?php echo esc_html($d['project_id']); ?></strong></div><?php endif; ?>
                        <?php if ($d['start_date']): ?><div><span class="hpd-meta-icon"><?php echo $this->icon('calendar'); ?></span><small>Start Date</small><strong><?php echo esc_html($d['start_date']); ?></strong></div><?php endif; ?>
                        <?php if ($d['completion']): ?><div><span class="hpd-meta-icon"><?php echo $this->icon('link'); ?></span><small>Est. Completion</small><strong><?php echo esc_html($d['completion']); ?></strong></div><?php endif; ?>
                        <?php if ($d['manager']): ?><div><span class="hpd-meta-icon"><?php echo $this->icon('user'); ?></span><small>Project Manager</small><strong><?php echo esc_html($d['manager']); ?></strong></div><?php endif; ?>
                    </div>
                    <div class="hpd-progress-line"><span>Overall Progress</span><div><i style="width:<?php echo esc_attr($d['progress']); ?>%"></i></div><b><?php echo esc_html($d['progress']); ?>%</b></div>
                </div>
            </section>

            <div class="hpd-grid">
                <section class="hpd-card">
                    <h3><span class="hpd-section-number">1.</span> Project Overview</h3>
                    <div class="hpd-overview">
                        <p><span>Current Phase</span><strong><?php echo esc_html($d['current_phase']); ?></strong></p>
                        <p><span>Status</span><strong class="hpd-accent"><?php echo esc_html($d['status']); ?></strong></p>
                        <p><span>Progress</span><strong><?php echo esc_html($d['progress']); ?>%</strong></p>
                        <div class="hpd-small-progress"><i style="width:<?php echo esc_attr($d['progress']); ?>%"></i></div>
                        <p class="hpd-description"><?php echo nl2br(esc_html($d['overview_text'])); ?></p>
                    </div>
                </section>

                <section class="hpd-card">
                    <h3><span class="hpd-section-number">2.</span> Project Timeline</h3>
                    <div class="hpd-timeline">
                        <?php foreach ($d['timeline'] as $row): $st=strtolower($row['status']??''); $done=in_array($st,['complete','completed','done','approved','received','paid'],true); ?>
                            <div class="hpd-timeline-item <?php echo $done?'done':''; ?>"><span class="hpd-dot"></span><div><strong><?php echo esc_html($row['title']??''); ?></strong><em><?php echo esc_html($row['date']??''); ?></em></div><b><?php echo esc_html($row['status']??''); ?></b></div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <section class="hpd-card">
                    <h3><span class="hpd-section-number">3.</span> Important Links</h3>
                    <div class="hpd-links">
                        <?php foreach ($d['links'] as $row): if(empty($row['url'])) continue; ?><a href="<?php echo esc_url($row['url']); ?>" target="_blank" rel="noopener"><span class="hpd-link-icon">↗</span><span><strong><?php echo esc_html($row['title']??'Link'); ?></strong><small><?php echo esc_html($row['subtitle']??'Open link'); ?></small></span></a><?php endforeach; ?>
                    </div>
                    <div class="hpd-note"><span>◈</span><?php echo esc_html($d['privacy_note']); ?></div>
                </section>

                <section class="hpd-card">
                    <h3><span class="hpd-section-number">4.</span> Action Required From You</h3>
                    <div class="hpd-alert"><span>●</span>Your feedback and content are important for us to move forward.<br>Please complete the following.</div>
                    <div class="hpd-table">
                        <div class="hpd-table-head"><span>Task</span><span>Priority</span><span>Status</span><span>Due Date</span></div>
                        <?php foreach ($d['actions'] as $row): ?><div class="hpd-table-row"><span><?php echo esc_html($row['task']??''); ?></span><span><i class="hpd-priority <?php echo esc_attr(strtolower($row['priority']??'')); ?>"><?php echo esc_html($row['priority']??''); ?></i></span><span><i class="hpd-status"><?php echo esc_html($row['status']??''); ?></i></span><span><?php echo esc_html($row['due']??''); ?></span></div><?php endforeach; ?>
                    </div>
                    <button type="button" class="hpd-text-button" data-open-message>◌ Need help? Let us know if you have any questions.</button>
                </section>

                <section class="hpd-card">
                    <h3><span class="hpd-section-number">5.</span> Payment Milestones</h3>
                    <div class="hpd-table payments"><div class="hpd-table-head"><span>Milestone</span><span>Amount</span><span>Status</span><span>Due Date</span></div>
                        <?php foreach ($d['payments'] as $row): ?><div class="hpd-table-row"><span><?php echo esc_html($row['milestone']??''); ?></span><span><?php echo esc_html($row['amount']??''); ?></span><span><i class="hpd-status <?php echo esc_attr(strtolower($row['status']??'')); ?>"><?php echo esc_html($row['status']??''); ?></i></span><span><?php echo esc_html($row['due']??''); ?></span></div><?php endforeach; ?>
                    </div>
                    <div class="hpd-success"><span>✓</span><div>Thank you! Your deposit has been received.<small>We will notify you for upcoming payments.</small></div></div>
                    <div class="hpd-payments-via"><strong>We Accept Payments Via</strong><div><span>▣ Wire Transfer</span><span>𝕏 Xoom</span><span>▣ Remitly</span><span>◉ Other (Ask Us)</span></div></div>
                </section>

                <section class="hpd-card">
                    <h3><span class="hpd-section-number">6.</span> Latest Updates</h3>
                    <div class="hpd-updates">
                        <?php foreach (array_slice($d['updates'],0,5) as $row): ?><article><div class="hpd-update-date"><?php echo esc_html($row['date']??''); ?><small><?php echo esc_html($row['time']??''); ?></small></div><div><strong><?php echo esc_html($row['title']??''); ?> <?php if(!empty($row['badge'])): ?><span class="hpd-new"><?php echo esc_html($row['badge']); ?></span><?php endif; ?></strong><p><?php echo nl2br(esc_html($row['text']??'')); ?></p></div></article><?php endforeach; ?>
                    </div>
                    <button type="button" class="hpd-view-updates" data-open-updates>View All Updates</button>
                </section>
            </div>

            <footer class="hpd-footer">
                <div class="hpd-footer-safe"><div class="hpd-shield"><?php echo $this->icon('shield'); ?></div><p><strong><?php echo esc_html($d['footer_note']); ?></strong><small>We are committed to delivering quality work and a great experience.</small></p></div>
                <div><strong>Support Hours</strong><p><?php echo esc_html($d['support_hours']); ?><br>We usually respond within 24 hours.</p></div>
                <div><strong>Have a Question?</strong><p><?php if($d['support_email']): ?>✉ <a href="mailto:<?php echo esc_attr($d['support_email']); ?>"><?php echo esc_html($d['support_email']); ?></a><br><?php endif; ?><?php if($d['support_phone']): ?>◉ <?php echo esc_html($d['support_phone']); ?><?php endif; ?></p></div>
            </footer>

            <div class="hpd-modal" aria-hidden="true"><div class="hpd-modal-inner"><button type="button" class="hpd-close" aria-label="Close">×</button><h3>Send us a message</h3><p>Tell us what you need help with and we will get back to you.</p><form class="hpd-message-form"><input type="hidden" name="dashboard_id" value="<?php echo esc_attr($id); ?>"><label>Name<input type="text" name="name" required></label><label>Email<input type="email" name="email" required></label><label>Message<textarea name="message" rows="5" required></textarea></label><button type="submit">Send Message</button><div class="hpd-form-result" aria-live="polite"></div></form></div></div>
            <div class="hpd-updates-modal" aria-hidden="true"><div class="hpd-updates-modal-inner"><button type="button" class="hpd-updates-close" aria-label="Close">×</button><h3>All Project Updates</h3><div><?php foreach($d['updates'] as $row): ?><article><div class="hpd-update-date"><?php echo esc_html($row['date']??''); ?><small><?php echo esc_html($row['time']??''); ?></small></div><div><strong><?php echo esc_html($row['title']??''); ?> <?php if(!empty($row['badge'])): ?><span class="hpd-new"><?php echo esc_html($row['badge']); ?></span><?php endif; ?></strong><p><?php echo nl2br(esc_html($row['text']??'')); ?></p></div></article><?php endforeach; ?></div></div></div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function send_message() {
        check_ajax_referer('hpd_message','nonce');
        $id=isset($_POST['dashboard_id'])?absint($_POST['dashboard_id']):0;
        if(!$id || get_post_type($id)!==self::CPT) wp_send_json_error(['message'=>'Invalid dashboard.'],422);
        if(!$this->can_access_dashboard($id)) wp_send_json_error(['message'=>'You are not authorised to use this dashboard.'],403);
        $name=isset($_POST['name'])?sanitize_text_field(wp_unslash($_POST['name'])):'';
        $email=isset($_POST['email'])?sanitize_email(wp_unslash($_POST['email'])):'';
        $message=isset($_POST['message'])?sanitize_textarea_field(wp_unslash($_POST['message'])):'';
        if(!$name || !$email || !is_email($email) || !$message) wp_send_json_error(['message'=>'Please complete all fields.'],422);
        $d=$this->data($id); $to=sanitize_email($d['recipient_email']); if(!$to || !is_email($to)) $to=get_option('admin_email');
        $subject='Client Dashboard Message — '.$d['client'].' — '.$d['project'];
        $body="A client sent a message from the project dashboard.\n\nClient: {$d['client']}\nProject: {$d['project']}\nProject ID: {$d['project_id']}\nSender: {$name}\nEmail: {$email}\n\nMessage:\n{$message}\n\nDashboard: ".get_permalink(get_queried_object_id());
        $headers=['Content-Type: text/plain; charset=UTF-8','Reply-To: '.$name.' <'.$email.'>'];
        $sent=wp_mail($to,$subject,$body,$headers);
        if(!$sent) wp_send_json_error(['message'=>'The message could not be sent. Please try again or email support directly.'],500);
        wp_send_json_success(['message'=>'Your message has been sent successfully.']);
    }

    public function columns($columns) { $columns['hpd_client']='Client'; $columns['hpd_project']='Project'; $columns['hpd_progress']='Progress'; return $columns; }
    public function column_content($column,$post_id) { $d=$this->data($post_id); if($column==='hpd_client') echo esc_html($d['client']); if($column==='hpd_project') echo esc_html($d['project']); if($column==='hpd_progress') echo esc_html($d['progress']).'%'; }
}

register_activation_hook(__FILE__, ['Hasan_Client_Project_Dashboard','activate']);
register_deactivation_hook(__FILE__, ['Hasan_Client_Project_Dashboard','deactivate']);
new Hasan_Client_Project_Dashboard();
