jQuery(function($){
  function refreshIndexes(box){
    box.find('.hpd-row').each(function(index){
      $(this).attr('data-index', index);
      $(this).find('[name]').each(function(){
        var name=$(this).attr('name');
        $(this).attr('name', name.replace(/\[[^\]]+\]\[[^\]]+\]$/, function(){ return '['+index+']' + name.substring(name.lastIndexOf(']')+1); }));
      });
    });
  }

  $('.hpd-admin-tabs').on('click','button',function(){
    var tab=$(this).data('tab');
    $('.hpd-admin-tabs button').removeClass('active');
    $(this).addClass('active');
    $('.hpd-tab').removeClass('active');
    $('#hpd-tab-'+tab).addClass('active');
  });

  $('.hpd-repeater').each(function(){
    var box=$(this), rows=box.find('.hpd-repeater-rows'), template=box.find('.hpd-row-template').html();
    var section=box.closest('.hpd-tab');

    section.on('click','.hpd-add-row',function(e){
      e.preventDefault();
      var index=rows.children('.hpd-row').length;
      var html=template.replace(/__INDEX__/g,index);
      rows.append(html);
      rows.children('.hpd-row').last().find('input,textarea').first().trigger('focus');
    });

    box.on('click','.hpd-remove-row',function(e){
      e.preventDefault();
      $(this).closest('.hpd-row').remove();
      // Rebuild names so PHP receives a clean array after removals.
      var type=box.data('repeater');
      rows.children('.hpd-row').each(function(index){
        $(this).attr('data-index',index);
        $(this).find('[name]').each(function(){
          var key=$(this).data('key');
          $(this).attr('name','hpd['+type+']['+index+']['+key+']');
        });
      });
    });
  });
});
