jQuery(function($){
  $('.hpd-dashboard').each(function(){
    const box=$(this), modal=box.find('.hpd-modal'), updatesModal=box.find('.hpd-updates-modal');

    box.on('click','[data-open-message]',function(){
      modal.addClass('open').attr('aria-hidden','false');
      setTimeout(()=>modal.find('input[name=name]').trigger('focus'),50);
    });
    box.on('click','.hpd-close',function(){
      modal.removeClass('open').attr('aria-hidden','true');
    });
    modal.on('click',function(e){
      if(e.target===this) modal.removeClass('open').attr('aria-hidden','true');
    });

    box.on('click','[data-open-updates]',function(){
      updatesModal.addClass('open').attr('aria-hidden','false');
    });
    box.on('click','.hpd-updates-close',function(){
      updatesModal.removeClass('open').attr('aria-hidden','true');
    });
    updatesModal.on('click',function(e){
      if(e.target===this) updatesModal.removeClass('open').attr('aria-hidden','true');
    });

    $(document).on('keydown.hpd',function(e){
      if(e.key==='Escape'){
        modal.removeClass('open').attr('aria-hidden','true');
        updatesModal.removeClass('open').attr('aria-hidden','true');
      }
    });

    box.on('submit','.hpd-message-form',function(e){
      e.preventDefault();
      const form=$(this), result=form.find('.hpd-form-result'), btn=form.find('button[type=submit]');
      result.removeClass('ok err').text('Sending...');
      btn.prop('disabled',true);
      const data=form.serializeArray();
      data.push({name:'action',value:'hpd_send_message'});
      data.push({name:'nonce',value:HPD_AJAX.nonce});
      $.post(HPD_AJAX.ajax_url,data).done(function(resp){
        if(resp.success){
          result.addClass('ok').text(resp.data.message);
          form[0].reset();
        } else {
          result.addClass('err').text(resp.data && resp.data.message ? resp.data.message : 'Something went wrong.');
        }
      }).fail(function(xhr){
        let msg='Something went wrong. Please try again.';
        if(xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) msg=xhr.responseJSON.data.message;
        result.addClass('err').text(msg);
      }).always(function(){btn.prop('disabled',false);});
    });
  });
});
