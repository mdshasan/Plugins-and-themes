<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class WPES_Snapshot {

    public static function create( $source = 'automatic', $archive = true, $apply_retention = true ) {
        if ( ! function_exists( 'get_plugins' ) ) { require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
        $previous = get_option( 'wpes_current_state', array() );
        $current  = self::collect();
        $changes  = self::compare( $previous, $current );
        $id       = wp_generate_uuid4();
        $snapshot = array(
            'id' => $id, 'created' => current_time( 'timestamp' ), 'source' => sanitize_key( $source ),
            'changes' => $changes, 'summary' => self::summary( $changes ),
            'state' => array(
                'environment' => $current['environment'], 'plugins' => $current['plugins'], 'themes' => $current['themes'],
                'users' => $current['users'], 'options' => $current['options'], 'tables' => $current['tables'],
                'cron' => $current['cron'], 'files' => $current['files'],
            ),
            'archive' => array( 'enabled' => false, 'path' => '', 'files' => 0, 'bytes' => 0 ),
        );

        if ( $archive ) {
            $snapshot['archive'] = self::create_archive( $id, $current['files'] );
        }

        $snapshots = get_option( 'wpes_snapshots', array() );
        $snapshots = is_array( $snapshots ) ? $snapshots : array();
        array_unshift( $snapshots, $snapshot );
        $settings = get_option( 'wpes_settings', array() );
        $retention = isset( $settings['retention'] ) ? absint( $settings['retention'] ) : 30;
        $retention = max( 2, min( 100, $retention ) );
        if ( $apply_retention ) {
            $removed = array_slice( $snapshots, $retention );
            foreach ( $removed as $old ) { if ( isset( $old['archive']['path'] ) ) { self::delete_archive( $old['archive']['path'] ); } }
            $snapshots = array_slice( $snapshots, 0, $retention );
        }
        update_option( 'wpes_snapshots', $snapshots, false );
        update_option( 'wpes_current_state', $current, false );
        update_option( 'wpes_last_snapshot', $snapshot['created'], false );
        return $snapshot;
    }

    public static function collect() {
        global $wpdb;
        $plugins = get_plugins(); $plugin_state = array();
        foreach ( $plugins as $file => $plugin ) {
            $plugin_state[$file] = array('name'=>isset($plugin['Name'])?sanitize_text_field($plugin['Name']):$file,'version'=>isset($plugin['Version'])?sanitize_text_field($plugin['Version']):'','active'=>is_plugin_active($file));
        } ksort($plugin_state);
        $themes = array();
        foreach ( wp_get_themes() as $stylesheet => $theme ) { $themes[$stylesheet]=array('name'=>$theme->get('Name'),'version'=>$theme->get('Version'),'active'=>(get_stylesheet()===$stylesheet)); }
        ksort($themes);
        $users=array();
        $user_query=new WP_User_Query(array('fields'=>array('ID','user_login','user_email','user_registered'),'orderby'=>'ID','order'=>'ASC'));
        foreach($user_query->get_results() as $user){$roles=get_userdata($user->ID)->roles;sort($roles);$users[(string)$user->ID]=array('login'=>sanitize_user($user->user_login,true),'email_hash'=>hash('sha256',strtolower((string)$user->user_email)),'roles'=>$roles,'registered'=>$user->user_registered);}
        $important_keys=array('siteurl','home','admin_email','active_plugins','template','stylesheet','permalink_structure','blog_public','users_can_register','default_role','WPLANG'); $options=array();
        foreach($important_keys as $key){$value=get_option($key,null);$value=is_array($value)||is_object($value)?wp_json_encode($value):(string)$value;if('admin_email'===$key){$value=hash('sha256',strtolower($value));}$options[$key]=array('hash'=>hash('sha256',$value));}
        $tables=array(); $like=$wpdb->esc_like($wpdb->prefix).'%'; $table_names=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$like));
        foreach($table_names as $table){$columns=$wpdb->get_results('DESCRIBE `'.str_replace('`','``',$table).'`',ARRAY_A);$schema=array();foreach($columns as $column){$schema[]=array($column['Field'],$column['Type'],$column['Null'],$column['Key']);}$tables[$table]=hash('sha256',wp_json_encode($schema));} ksort($tables);
        return array('environment'=>array('wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'memory_limit'=>ini_get('memory_limit'),'language'=>get_locale(),'timezone'=>wp_timezone_string(),'home'=>home_url(),'siteurl'=>site_url(),'debug'=>defined('WP_DEBUG')&&WP_DEBUG,'multisite'=>is_multisite(),'active_theme'=>wp_get_theme()->get('Name'),'active_theme_ver'=>wp_get_theme()->get('Version')),'plugins'=>$plugin_state,'themes'=>$themes,'users'=>$users,'options'=>$options,'tables'=>$tables,'cron'=>self::cron_state(),'files'=>WPES_Files::scan());
    }

    private static function cron_state(){ $cron=_get_cron_array();$state=array();if(is_array($cron)){foreach($cron as $timestamp=>$hooks){foreach($hooks as $hook=>$events){foreach($events as $key=>$event){$state[$hook.'|'.$key]=array('timestamp'=>(int)$timestamp,'schedule'=>isset($event['schedule'])?(string)$event['schedule']:'');}}}}ksort($state);return $state; }

    private static function compare($old,$new){
        $changes=array(); if(empty($old)){ $changes[]=self::event('info','baseline','Initial baseline created.'); return $changes; }
        $old_env=isset($old['environment'])?$old['environment']:array(); foreach($new['environment'] as $key=>$value){if(isset($old_env[$key])&&$old_env[$key]!==$value){$severity=in_array($key,array('home','siteurl','debug'),true)?'high':'info';$changes[]=self::event($severity,'environment',sprintf('%s changed: %s → %s',$key,$old_env[$key],$value));}}
        self::compare_plugins($changes,isset($old['plugins'])?$old['plugins']:array(),$new['plugins']); self::compare_themes($changes,isset($old['themes'])?$old['themes']:array(),$new['themes']); self::compare_users($changes,isset($old['users'])?$old['users']:array(),$new['users']); self::compare_hash_map($changes,'option',isset($old['options'])?$old['options']:array(),$new['options'],'high'); self::compare_hash_map($changes,'database_table',isset($old['tables'])?$old['tables']:array(),$new['tables'],'high'); self::compare_cron($changes,isset($old['cron'])?$old['cron']:array(),$new['cron']);
        $file_changes=WPES_Files::compare(isset($old['files'])?$old['files']:array(),$new['files']); foreach($file_changes as $fc){$changes[]=self::event($fc['severity'],'file',sprintf('%s %s: %s',ucfirst($fc['kind']),$fc['type'],$fc['path']),array('path'=>$fc['path'],'change'=>$fc['type'],'kind'=>$fc['kind']));} return $changes;
    }
    private static function compare_plugins(&$c,$old,$new){foreach($new as $file=>$p){if(!isset($old[$file])){$c[]=self::event('warning','plugin','Plugin installed: '.$p['name'],array('plugin'=>$file));continue;}if($old[$file]['version']!==$p['version']){$c[]=self::event('info','plugin',sprintf('Plugin updated: %s (%s → %s)',$p['name'],$old[$file]['version'],$p['version']));}if($old[$file]['active']!==$p['active']){$c[]=self::event('warning','plugin',sprintf('Plugin %s: %s',$p['active']?'activated':'deactivated',$p['name']));}}foreach($old as $file=>$p){if(!isset($new[$file])){$c[]=self::event('warning','plugin','Plugin removed: '.$p['name']);}}}
    private static function compare_themes(&$c,$old,$new){foreach($new as $slug=>$t){if(!isset($old[$slug])){$c[]=self::event('warning','theme','Theme installed: '.$t['name']);continue;}if($old[$slug]['version']!==$t['version']){$c[]=self::event('info','theme',sprintf('Theme updated: %s (%s → %s)',$t['name'],$old[$slug]['version'],$t['version']));}if($old[$slug]['active']!==$t['active']&&$t['active']){$c[]=self::event('warning','theme','Theme activated: '.$t['name']);}}foreach($old as $slug=>$t){if(!isset($new[$slug])){$c[]=self::event('warning','theme','Theme removed: '.$t['name']);}}}
    private static function compare_users(&$c,$old,$new){foreach($new as $id=>$u){if(!isset($old[$id])){$c[]=self::event(in_array('administrator',$u['roles'],true)?'critical':'warning','user',sprintf('User added: %s (%s)',$u['login'],implode(', ',$u['roles'])));continue;}if($old[$id]['roles']!==$u['roles']){$c[]=self::event(in_array('administrator',$u['roles'],true)?'critical':'high', 'user',sprintf('User role changed: %s (%s → %s)',$u['login'],implode(', ',$old[$id]['roles']),implode(', ',$u['roles'])));}if($old[$id]['email_hash']!==$u['email_hash']){$c[]=self::event('warning','user','User email changed: '.$u['login']);}}foreach($old as $id=>$u){if(!isset($new[$id])){$c[]=self::event('warning','user','User removed: '.$u['login']);}}}
    private static function compare_cron(&$c,$old,$new){foreach(array(&$old,&$new) as &$state){if(!is_array($state)){$state=array();continue;}foreach(array_keys($state) as $key){if(0===strpos((string)$key,'wpes_scheduled_snapshot|'))unset($state[$key]);}}unset($state);self::compare_hash_map($c,'cron',$old,$new,'warning');}
    private static function compare_hash_map(&$c,$type,$old,$new,$severity){foreach($new as $key=>$value){$ov=isset($old[$key])?$old[$key]:null;$nh=is_array($value)&&isset($value['hash'])?$value['hash']:wp_json_encode($value);$oh=is_array($ov)&&isset($ov['hash'])?$ov['hash']:wp_json_encode($ov);if(null===$ov)$c[]=self::event($severity,$type,sprintf('New %s detected: %s',$type,$key));elseif($oh!==$nh)$c[]=self::event($severity,$type,sprintf('%s changed: %s',ucfirst(str_replace('_',' ',$type)),$key));}foreach($old as $key=>$value){if(!isset($new[$key]))$c[]=self::event($severity,$type,sprintf('%s removed: %s',ucfirst(str_replace('_',' ',$type)),$key));}}
    private static function event($severity,$type,$message,$data=array()){return array('severity'=>$severity,'type'=>$type,'message'=>wp_strip_all_tags($message),'data'=>$data);}
    private static function summary($changes){$s=array('critical'=>0,'high'=>0,'warning'=>0,'info'=>0);foreach($changes as $c){if(isset($s[$c['severity']]))$s[$c['severity']]++;}return $s;}

    private static function archive_dir(){ $upload=wp_upload_dir(); $base=trailingslashit($upload['basedir']).'wpes-archives'; if(!is_dir($base)){wp_mkdir_p($base);@file_put_contents(trailingslashit($base).'index.html','');} return wp_normalize_path($base); }
    private static function create_archive($id,$files){
        $root=self::archive_dir(); $dir=trailingslashit($root).$id; if(!wp_mkdir_p($dir))return array('enabled'=>false,'path'=>'','files'=>0,'bytes'=>0);
        $count=0;$bytes=0;
        foreach($files as $relative=>$meta){if(!isset($meta['type'])||'file'!==$meta['type'])continue;$source=ABSPATH.ltrim($relative,'/');if(!is_file($source)||!is_readable($source))continue;
            // Never archive the plugin's own archive directory or uploads because it is excluded from scans.
            if(0===strpos(wp_normalize_path($source),wp_normalize_path(trailingslashit(WP_CONTENT_DIR). 'uploads/')))continue;
            $target=trailingslashit($dir).ltrim($relative,'/'); $parent=dirname($target); if(!is_dir($parent)&&!wp_mkdir_p($parent))continue; if(@copy($source,$target)){@chmod($target,0644);$count++;$size=@filesize($target);if(false!==$size)$bytes+=(int)$size;}
        }
        return array('enabled'=>true,'path'=>$id,'files'=>$count,'bytes'=>$bytes);
    }
    public static function delete_archive($id){if(!$id)return; $root=self::archive_dir();$dir=trailingslashit($root).basename($id);if(!is_dir($dir))return;self::rrmdir($dir);}
    private static function rrmdir( $dir ) {
        if ( ! is_dir( $dir ) ) {
            return false;
        }
        $items = @scandir( $dir );
        if ( false === $items ) {
            return false;
        }
        $success = true;
        foreach ( $items as $item ) {
            if ( '.' === $item || '..' === $item ) {
                continue;
            }
            $path = trailingslashit( $dir ) . $item;
            if ( is_dir( $path ) && ! is_link( $path ) ) {
                if ( ! self::rrmdir( $path ) ) {
                    $success = false;
                }
            } elseif ( ! @unlink( $path ) ) {
                $success = false;
            }
        }
        if ( ! @rmdir( $dir ) ) {
            $success = false;
        }
        return $success;
    }

    public static function enforce_retention() {
        $snapshots = self::get_all();
        $settings = get_option( 'wpes_settings', array() );
        $retention = isset( $settings['retention'] ) ? absint( $settings['retention'] ) : 30;
        $retention = max( 2, min( 100, $retention ) );
        if ( count( $snapshots ) <= $retention ) {
            return;
        }
        $removed = array_slice( $snapshots, $retention );
        foreach ( $removed as $old ) {
            if ( isset( $old['archive']['path'] ) ) {
                self::delete_archive( $old['archive']['path'] );
            }
        }
        update_option( 'wpes_snapshots', array_slice( $snapshots, 0, $retention ), false );
    }

    public static function restore( $id, $scope = 'all', $remove_post_snapshot = false ) {
        if ( 'all' !== $scope && ! in_array( $scope, array( 'core', 'plugins', 'themes', 'mu-plugins', 'configuration' ), true ) ) {
            return new WP_Error( 'wpes_invalid_scope', 'Invalid restore scope.' );
        }

        $snapshot = self::get( $id );
        if ( ! $snapshot || empty( $snapshot['archive']['enabled'] ) ) {
            return new WP_Error( 'wpes_no_archive', 'This snapshot does not contain a usable archive.' );
        }

        $root = self::archive_root_for_snapshot( $snapshot );
        if ( is_wp_error( $root ) ) {
            return $root;
        }

        $good_state = isset( $snapshot['state']['files'] ) && is_array( $snapshot['state']['files'] ) ? $snapshot['state']['files'] : array();
        $current_state = WPES_Files::scan();
        $archive_files = self::archive_files( $root );
        $areas = array( 'core' => true, 'plugins' => true, 'themes' => true, 'mu-plugins' => true, 'configuration' => true );
        if ( 'all' !== $scope ) {
            $areas = array_fill_keys( array_keys( $areas ), false );
            $areas[ $scope ] = true;
        }

        $restored = 0; $deleted = 0; $deleted_directories = 0; $skipped = 0; $errors = array();

        foreach ( $archive_files as $relative => $source ) {
            $relative = self::safe_relative_path( $relative );
            if ( is_wp_error( $relative ) ) { $errors[] = $relative->get_error_message(); continue; }
            $area = self::area_for_path( $relative );
            if ( empty( $areas[ $area ] ) ) { $skipped++; continue; }
            if ( ! isset( $good_state[ $relative ] ) || 'file' !== ( isset( $good_state[ $relative ]['type'] ) ? $good_state[ $relative ]['type'] : 'file' ) ) { $errors[] = 'Archive/state mismatch: ' . $relative; continue; }

            $target = self::target_for_path( $relative );
            if ( is_wp_error( $target ) ) { $errors[] = $target->get_error_message(); continue; }
            $good = $good_state[ $relative ];
            $current = isset( $current_state[ $relative ] ) ? $current_state[ $relative ] : null;
            $needs_restore = ! is_file( $target ) || ! isset( $current['hash'], $good['hash'] ) || $current['hash'] !== $good['hash'];
            if ( ! $needs_restore ) { continue; }

            if ( ! is_file( $source ) || ! is_readable( $source ) || ! self::verify_archive_file( $source, $good ) ) {
                $errors[] = 'Archive integrity check failed: ' . $relative;
                continue;
            }
            if ( is_dir( $target ) && ! is_link( $target ) && ! self::rrmdir( $target ) ) { $errors[] = 'Could not remove directory conflict: ' . $relative; continue; }
            if ( is_link( $target ) && ! @unlink( $target ) ) { $errors[] = 'Could not remove link conflict: ' . $relative; continue; }
            $parent = dirname( $target );
            if ( ! is_dir( $parent ) && ! wp_mkdir_p( $parent ) ) { $errors[] = 'Could not create destination directory: ' . $relative; continue; }
            $tmp = $target . '.wpes-recovery-' . wp_generate_password( 8, false, false );
            if ( ! @copy( $source, $tmp ) || ! self::verify_archive_file( $tmp, $good ) ) {
                @unlink( $tmp ); $errors[] = 'Could not safely stage restore: ' . $relative; continue;
            }
            @chmod( $tmp, 0644 );
            if ( ! @rename( $tmp, $target ) ) { @unlink( $tmp ); $errors[] = 'Could not commit restore: ' . $relative; continue; }
            $restored++;
        }

        if ( $remove_post_snapshot ) {
            $extra_files = array(); $extra_dirs = array();
            foreach ( $current_state as $relative => $meta ) {
                $relative = self::safe_relative_path( $relative );
                if ( is_wp_error( $relative ) ) { $errors[] = $relative->get_error_message(); continue; }
                $area = self::area_for_path( $relative );
                if ( empty( $areas[ $area ] ) || isset( $good_state[ $relative ] ) ) { continue; }
                // Never delete wp-config.php automatically. A missing config in an old snapshot
                // must not turn an all-scope cleanup into a site-breaking operation.
                if ( 'wp-config.php' === $relative ) { $errors[] = 'Skipped protected configuration file: wp-config.php'; continue; }
                if ( 'directory' === ( isset( $meta['type'] ) ? $meta['type'] : 'file' ) ) { $extra_dirs[] = $relative; } else { $extra_files[] = $relative; }
            }
            foreach ( $extra_files as $relative ) {
                $target = self::target_for_path( $relative );
                if ( is_wp_error( $target ) ) { $errors[] = $target->get_error_message(); continue; }
                if ( is_file( $target ) || is_link( $target ) ) {
                    if ( @unlink( $target ) ) { $deleted++; } else { $errors[] = 'Could not delete added file: ' . $relative; }
                }
            }
            usort( $extra_dirs, function ( $a, $b ) { return substr_count( $b, '/' ) - substr_count( $a, '/' ); } );
            foreach ( $extra_dirs as $relative ) {
                $target = self::target_for_path( $relative );
                if ( is_wp_error( $target ) ) { $errors[] = $target->get_error_message(); continue; }
                if ( ! is_dir( $target ) ) { continue; }
                if ( self::rrmdir( $target ) ) { $deleted_directories++; } else { $errors[] = 'Could not delete added directory: ' . $relative; }
            }
        }

        $verification = self::verify_recovery( $snapshot, $areas );
        return array( 'restored' => $restored, 'deleted' => $deleted, 'deleted_directories' => $deleted_directories, 'skipped' => $skipped, 'errors' => $errors, 'cleanup' => (bool) $remove_post_snapshot, 'verified' => $verification['ok'], 'verification' => $verification, 'snapshot' => $snapshot );
    }

    public static function verify_recovery( $snapshot, $areas = null ) {
        $areas = is_array( $areas ) ? $areas : array( 'core'=>true, 'plugins'=>true, 'themes'=>true, 'mu-plugins'=>true, 'configuration'=>true );
        $good = isset( $snapshot['state']['files'] ) && is_array( $snapshot['state']['files'] ) ? $snapshot['state']['files'] : array();
        $current = WPES_Files::scan(); $missing = array(); $modified = array(); $unexpected = array();
        foreach ( $good as $path => $meta ) {
            if ( 'file' !== ( isset( $meta['type'] ) ? $meta['type'] : 'file' ) || empty( $areas[ self::area_for_path( $path ) ] ) ) continue;
            if ( ! isset( $current[ $path ] ) ) { $missing[] = $path; continue; }
            if ( isset( $meta['hash'], $current[ $path ]['hash'] ) && $meta['hash'] !== $current[ $path ]['hash'] ) $modified[] = $path;
        }
        foreach ( $current as $path => $meta ) {
            if ( empty( $areas[ self::area_for_path( $path ) ] ) || isset( $good[ $path ] ) ) continue;
            if ( 'wp-config.php' === $path ) continue;
            $unexpected[] = $path;
        }
        return array( 'ok' => empty( $missing ) && empty( $modified ) && empty( $unexpected ), 'missing' => $missing, 'modified' => $modified, 'unexpected' => $unexpected );
    }

    public static function recovery_analysis( $id ) {
        $snapshot = self::get( $id );
        if ( ! $snapshot || empty( $snapshot['archive']['enabled'] ) ) {
            return new WP_Error( 'wpes_no_archive', 'This snapshot does not contain a usable archive.' );
        }
        $good = isset( $snapshot['state']['files'] ) && is_array( $snapshot['state']['files'] ) ? $snapshot['state']['files'] : array();
        $current = WPES_Files::scan();
        $items = array();
        $summary = array( 'modified' => 0, 'missing' => 0, 'added' => 0, 'added_directories' => 0 );

        foreach ( $good as $path => $meta ) {
            $type = isset( $meta['type'] ) ? $meta['type'] : 'file';
            if ( 'directory' === $type ) {
                continue;
            }
            if ( ! isset( $current[ $path ] ) ) {
                $items[] = array( 'path' => $path, 'type' => $type, 'change' => 'missing' );
                $summary['missing']++;
            } elseif ( isset( $current[ $path ]['hash'], $meta['hash'] ) && $current[ $path ]['hash'] !== $meta['hash'] ) {
                $items[] = array( 'path' => $path, 'type' => $type, 'change' => 'modified' );
                $summary['modified']++;
            }
        }

        foreach ( $current as $path => $meta ) {
            if ( isset( $good[ $path ] ) ) {
                continue;
            }
            $type = isset( $meta['type'] ) ? $meta['type'] : 'file';
            $items[] = array( 'path' => $path, 'type' => $type, 'change' => 'added' );
            if ( 'directory' === $type ) {
                $summary['added_directories']++;
            } else {
                $summary['added']++;
            }
        }

        usort( $items, function( $a, $b ) {
            return strcmp( $a['path'], $b['path'] );
        } );
        return array( 'items' => $items, 'summary' => $summary );
    }

    public static function recover_item( $id, $path, $action ) {
        $snapshot = self::get( $id );
        if ( ! $snapshot || empty( $snapshot['archive']['enabled'] ) ) return new WP_Error( 'wpes_no_archive', 'This snapshot does not contain a usable archive.' );
        $path = self::safe_relative_path( $path );
        if ( is_wp_error( $path ) ) return $path;
        $root = self::archive_root_for_snapshot( $snapshot );
        if ( is_wp_error( $root ) ) return $root;
        $good = isset( $snapshot['state']['files'][ $path ] ) ? $snapshot['state']['files'][ $path ] : null;
        $source = trailingslashit( $root ) . $path;
        $target = self::target_for_path( $path );
        if ( is_wp_error( $target ) ) return $target;
        $current = WPES_Files::scan();

        if ( 'restore' === $action ) {
            if ( ! $good || 'file' !== $good['type'] || ! is_file( $source ) || ! self::verify_archive_file( $source, $good ) ) return new WP_Error( 'wpes_restore_unavailable', 'The known-good file is unavailable or failed its integrity check.' );
            if ( isset( $current[ $path ] ) && isset( $current[ $path ]['hash'], $good['hash'] ) && $current[ $path ]['hash'] === $good['hash'] ) return array( 'action'=>'restore','status'=>'unchanged','path'=>$path );
            if ( is_dir( $target ) && ! is_link( $target ) && ! self::rrmdir( $target ) ) return new WP_Error( 'wpes_restore_conflict', 'Could not remove a directory occupying the file path.' );
            if ( is_link( $target ) && ! @unlink( $target ) ) return new WP_Error( 'wpes_restore_conflict', 'Could not remove a link occupying the file path.' );
            $parent=dirname($target); if(!is_dir($parent)&&!wp_mkdir_p($parent)) return new WP_Error('wpes_restore_directory','Could not create the destination directory.');
            $tmp=$target.'.wpes-recovery-'.wp_generate_password(8,false,false);
            if(!@copy($source,$tmp)||!self::verify_archive_file($tmp,$good)){@unlink($tmp);return new WP_Error('wpes_restore_copy','Could not safely stage the file restore.');}
            @chmod($tmp,0644); if(!@rename($tmp,$target)){@unlink($tmp);return new WP_Error('wpes_restore_copy','Could not commit the file restore.');}
            return array('action'=>'restore','status'=>'restored','path'=>$path);
        }
        if ( 'delete' === $action ) {
            if ( isset( $good[ 'type' ] ) ) return new WP_Error( 'wpes_delete_known_good', 'This item exists in the known-good snapshot and cannot be deleted by cleanup.' );
            if ( 'wp-config.php' === $path ) return new WP_Error( 'wpes_delete_protected', 'wp-config.php is protected from deletion.' );
            if ( isset($current[$path]) && 'directory' === $current[$path]['type'] ) {
                if ( is_dir($target) && self::rrmdir($target) ) return array('action'=>'delete','status'=>'deleted','path'=>$path);
                return new WP_Error('wpes_delete_directory','Could not delete the directory.');
            }
            if ( is_file($target) || is_link($target) ) { if(@unlink($target)) return array('action'=>'delete','status'=>'deleted','path'=>$path); return new WP_Error('wpes_delete_file','Could not delete the file.'); }
            return array('action'=>'delete','status'=>'already_absent','path'=>$path);
        }
        return new WP_Error( 'wpes_invalid_action', 'Invalid recovery action.' );
    }

    private static function archive_root_for_snapshot( $snapshot ) {
        $archive_id = isset( $snapshot['archive']['path'] ) ? sanitize_file_name( basename( $snapshot['archive']['path'] ) ) : '';
        if ( '' === $archive_id || empty( $snapshot['id'] ) || $archive_id !== sanitize_file_name( basename( $snapshot['id'] ) ) ) {
            return new WP_Error( 'wpes_invalid_archive', 'Snapshot archive identity is invalid.' );
        }
        $root = trailingslashit( self::archive_dir() ) . $archive_id;
        $real_root = realpath( $root );
        $real_base = realpath( self::archive_dir() );
        if ( false === $real_root || false === $real_base || 0 !== strpos( wp_normalize_path( $real_root ), trailingslashit( wp_normalize_path( $real_base ) ) ) ) {
            return new WP_Error( 'wpes_missing_archive', 'Snapshot archive is missing or outside the archive directory.' );
        }
        return wp_normalize_path( $real_root );
    }

    private static function safe_relative_path( $path ) {
        $path = wp_normalize_path( ltrim( (string) $path, '/' ) );
        if ( '' === $path || '.' === $path || false !== strpos( $path, "\0" ) || false !== strpos( $path, '../' ) || false !== strpos( $path, '/..' ) || '..' === $path ) {
            return new WP_Error( 'wpes_invalid_path', 'Invalid recovery path.' );
        }
        return $path;
    }

    private static function target_for_path( $relative ) {
        $relative = self::safe_relative_path( $relative );
        if ( is_wp_error( $relative ) ) return $relative;
        $base = realpath( ABSPATH );
        if ( false === $base ) return new WP_Error( 'wpes_invalid_root', 'WordPress root could not be resolved.' );
        $target = wp_normalize_path( trailingslashit( $base ) . $relative );
        $parent = realpath( dirname( $target ) );
        if ( false !== $parent && 0 !== strpos( $parent, trailingslashit( wp_normalize_path( $base ) ) ) && wp_normalize_path( $parent ) !== wp_normalize_path( $base ) ) {
            return new WP_Error( 'wpes_unsafe_target', 'Recovery target is outside the WordPress directory.' );
        }
        return $target;
    }

    private static function verify_archive_file( $source, $good ) {
        if ( ! is_file( $source ) || ! isset( $good['hash'] ) ) return false;
        $hash = @md5_file( $source );
        return false !== $hash && hash_equals( (string) $good['hash'], (string) $hash );
    }

    private static function archive_files( $root ) {
        $result = array();
        $it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ) );
        foreach ( $it as $file ) {
            if ( ! $file->isFile() ) {
                continue;
            }
            $relative = wp_normalize_path( substr( $file->getPathname(), strlen( trailingslashit( $root ) ) ) );
            $result[ $relative ] = $file->getPathname();
        }
        return $result;
    }

    private static function area_for_path( $path ) {
        $path = wp_normalize_path( $path );
        if ( 'wp-config.php' === $path || '.htaccess' === $path ) {
            return 'configuration';
        }
        if ( 0 === strpos( $path, 'wp-content/mu-plugins/' ) ) {
            return 'mu-plugins';
        }
        if ( 0 === strpos( $path, 'wp-content/plugins/' ) ) {
            return 'plugins';
        }
        if ( 0 === strpos( $path, 'wp-content/themes/' ) ) {
            return 'themes';
        }
        return 'core';
    }

    public static function get_all(){ $items=get_option('wpes_snapshots',array());return is_array($items)?$items:array(); }
    public static function get($id){foreach(self::get_all() as $s){if(isset($s['id'])&&(string)$s['id']===(string)$id)return$s;}return null;}
    public static function delete($id){$snapshots=self::get_all();$kept=array();foreach($snapshots as $s){if(isset($s['id'])&&(string)$s['id']===(string)$id){if(isset($s['archive']['path']))self::delete_archive($s['archive']['path']);continue;}$kept[]=$s;}update_option('wpes_snapshots',array_values($kept),false);}
}
