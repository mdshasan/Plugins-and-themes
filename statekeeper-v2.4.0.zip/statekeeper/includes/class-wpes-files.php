<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPES_Files {

    public static function scan() {
        $roots = array(
            'core'       => ABSPATH,
            'plugins'    => WP_PLUGIN_DIR,
            'themes'     => get_theme_root(),
            'mu-plugins' => WPMU_PLUGIN_DIR,
        );

        $files = array();
        $excluded = array(
            wp_normalize_path( WP_CONTENT_DIR . '/cache' ),
            wp_normalize_path( WP_CONTENT_DIR . '/upgrade' ),
            wp_normalize_path( WP_CONTENT_DIR . '/uploads' ),
        );

        foreach ( $roots as $area => $root ) {
            if ( ! is_dir( $root ) ) {
                continue;
            }
            self::walk( $root, $area, $files, $excluded );
        }

        $special = array( ABSPATH . '.htaccess', ABSPATH . 'wp-config.php' );
        foreach ( $special as $file ) {
            if ( is_file( $file ) && is_readable( $file ) ) {
                $key = self::relative_path( $file );
                $hash = md5_file( $file );
                if ( $hash ) {
                    $files[ $key ] = array(
                        'type' => 'file',
                        'hash' => $hash,
                        'area' => 'configuration',
                    );
                }
            }
        }

        ksort( $files );
        return $files;
    }

    private static function walk( $dir, $area, &$files, $excluded ) {
        $dir = wp_normalize_path( $dir );
        $iterator = @new DirectoryIterator( $dir );

        foreach ( $iterator as $item ) {
            if ( $item->isDot() ) {
                continue;
            }

            $path = wp_normalize_path( $item->getPathname() );

            foreach ( $excluded as $skip ) {
                if ( $path === $skip || 0 === strpos( $path, trailingslashit( $skip ) ) ) {
                    continue 2;
                }
            }

            if ( $item->isDir() && ! $item->isLink() ) {
                $relative = self::relative_path( $path );

                // Record directory structure so newly created/removed folders
                // can be identified during an incident investigation.
                if ( $relative && $relative !== '.' ) {
                    $files[ trailingslashit( $relative ) ] = array(
                        'type' => 'directory',
                        'area' => $area,
                    );
                }

                self::walk( $path, $area, $files, $excluded );
                continue;
            }

            if ( ! $item->isFile() || ! $item->isReadable() ) {
                continue;
            }

            $extension = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
            if ( 'php' !== $extension ) {
                continue;
            }

            $hash = @md5_file( $path );
            if ( ! $hash ) {
                continue;
            }

            $files[ self::relative_path( $path ) ] = array(
                'type' => 'file',
                'hash' => $hash,
                'area' => $area,
            );
        }
    }

    private static function relative_path( $path ) {
        $path = wp_normalize_path( $path );
        $root = untrailingslashit( wp_normalize_path( ABSPATH ) );
        if ( 0 === strpos( $path, $root ) ) {
            return ltrim( substr( $path, strlen( $root ) ), '/' );
        }
        return $path;
    }

    public static function compare( $old, $new ) {
        $changes = array();
        $old = is_array( $old ) ? $old : array();
        $new = is_array( $new ) ? $new : array();

        foreach ( $new as $path => $data ) {
            if ( ! isset( $old[ $path ] ) ) {
                $kind = isset( $data['type'] ) ? $data['type'] : 'file';
                $changes[] = array(
                    'type' => 'added',
                    'kind' => $kind,
                    'severity' => self::severity_for_new_file( $path, $kind ),
                    'path' => $path,
                    'area' => $data['area'],
                );
            } elseif ( 'file' === ( isset( $data['type'] ) ? $data['type'] : 'file' ) && isset( $old[ $path ]['hash'] ) && $old[ $path ]['hash'] !== $data['hash'] ) {
                $changes[] = array(
                    'type' => 'modified',
                    'kind' => 'file',
                    'severity' => self::severity_for_modified_file( $path ),
                    'path' => $path,
                    'area' => $data['area'],
                );
            }
        }

        foreach ( $old as $path => $data ) {
            if ( ! isset( $new[ $path ] ) ) {
                $kind = isset( $data['type'] ) ? $data['type'] : 'file';
                $changes[] = array(
                    'type' => 'deleted',
                    'kind' => $kind,
                    'severity' => self::severity_for_deleted_file( $path, $kind ),
                    'path' => $path,
                    'area' => $data['area'],
                );
            }
        }

        return $changes;
    }

    private static function severity_for_new_file( $path, $kind = 'file' ) {
        if ( 'directory' === $kind ) {
            if ( 0 === strpos( $path, 'wp-content/mu-plugins/' ) ) {
                return 'high';
            }
            return 'warning';
        }

        if ( 0 === strpos( $path, 'wp-content/uploads/' ) && '.php' === substr( $path, -4 ) ) {
            return 'critical';
        }
        if ( 'configuration' === self::area_from_path( $path ) || 0 === strpos( $path, 'wp-content/mu-plugins/' ) ) {
            return 'high';
        }
        return 'warning';
    }

    private static function severity_for_modified_file( $path ) {
        if ( in_array( $path, array( 'wp-config.php', '.htaccess' ), true ) ) {
            return 'critical';
        }
        if ( 0 === strpos( $path, 'wp-content/mu-plugins/' ) ) {
            return 'high';
        }
        return 'warning';
    }

    private static function severity_for_deleted_file( $path, $kind = 'file' ) {
        if ( 'directory' === $kind ) {
            if ( 0 === strpos( $path, 'wp-content/mu-plugins/' ) ) {
                return 'high';
            }
            return 'warning';
        }

        if ( in_array( $path, array( 'wp-config.php', '.htaccess' ), true ) ) {
            return 'critical';
        }
        return 'warning';
    }

    private static function area_from_path( $path ) {
        if ( in_array( $path, array( 'wp-config.php', '.htaccess' ), true ) ) {
            return 'configuration';
        }
        return '';
    }
}
