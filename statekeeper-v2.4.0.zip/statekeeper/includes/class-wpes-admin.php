<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class WPES_Admin {
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
        add_action( 'admin_post_wpes_create_snapshot', array( __CLASS__, 'create_snapshot' ) );
        add_action( 'admin_post_wpes_delete_snapshot', array( __CLASS__, 'delete_snapshot' ) );
        add_action( 'admin_post_wpes_save_settings', array( __CLASS__, 'save_settings' ) );
        add_action( 'admin_post_wpes_reset_baseline', array( __CLASS__, 'reset_baseline' ) );
        add_action( 'admin_post_wpes_restore_snapshot', array( __CLASS__, 'restore_snapshot' ) );
        add_action( 'admin_post_wpes_recover_item', array( __CLASS__, 'recover_item' ) );
    }

    public static function menu() { add_management_page( __( 'Environment Snapshots', 'wp-environment-snapshot' ), __( 'Environment Snapshots', 'wp-environment-snapshot' ), 'manage_options', 'wp-environment-snapshot', array( __CLASS__, 'page' ) ); }
    public static function assets( $hook ) { if ( 'tools_page_wp-environment-snapshot' === $hook ) wp_enqueue_style( 'wpes-admin', WPES_URL . 'assets/css/admin.css', array(), WPES_VERSION ); }
    private static function require_cap() { if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'You are not allowed to do this.', 'wp-environment-snapshot' ) ); }

    public static function create_snapshot() { self::require_cap(); check_admin_referer( 'wpes_create_snapshot' ); WPES_Snapshot::create( 'manual', true ); wp_safe_redirect( self::url( array( 'message' => 'created' ) ) ); exit; }
    public static function delete_snapshot() { self::require_cap(); $id = isset( $_GET['id'] ) ? sanitize_text_field( wp_unslash( $_GET['id'] ) ) : ''; check_admin_referer( 'wpes_delete_' . $id ); WPES_Snapshot::delete( $id ); wp_safe_redirect( self::url( array( 'message' => 'deleted' ) ) ); exit; }

    public static function save_settings() {
        self::require_cap(); check_admin_referer( 'wpes_save_settings' );
        $interval = max( 1, min( 168, isset( $_POST['interval'] ) ? absint( $_POST['interval'] ) : 12 ) );
        $retention = max( 2, min( 100, isset( $_POST['retention'] ) ? absint( $_POST['retention'] ) : 30 ) );
        $enabled = isset( $_POST['enabled'] ) ? 1 : 0;
        update_option( 'wpes_settings', array( 'interval' => (string) $interval, 'retention' => $retention, 'enabled' => $enabled ), false );
        wpes_schedule_event(); wp_safe_redirect( self::url( array( 'message' => 'settings' ) ) ); exit;
    }

    public static function reset_baseline() { self::require_cap(); check_admin_referer( 'wpes_reset_baseline' ); delete_option( 'wpes_current_state' ); delete_option( 'wpes_file_baseline' ); wp_safe_redirect( self::url( array( 'message' => 'reset' ) ) ); exit; }

    public static function restore_snapshot() {
        self::require_cap();
        $id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
        $scope = isset( $_POST['scope'] ) ? sanitize_key( $_POST['scope'] ) : 'all';
        $cleanup = ! empty( $_POST['cleanup'] );
        check_admin_referer( 'wpes_restore_' . $id );
        $emergency = WPES_Snapshot::create( 'pre-restore', true, false );
        if ( empty( $emergency['archive']['enabled'] ) ) { wp_safe_redirect( self::url( array( 'message' => 'restore_error', 'error' => 'emergency_snapshot_failed' ) ) ); exit; }
        $result = WPES_Snapshot::restore( $id, $scope, $cleanup );
        WPES_Snapshot::enforce_retention();
        if ( is_wp_error( $result ) ) { wp_safe_redirect( self::url( array( 'message' => 'restore_error', 'error' => $result->get_error_code() ) ) ); exit; }
        $args = array( 'message' => empty( $result['errors'] ) && ! empty( $result['verified'] ) ? 'restored' : 'restore_warning', 'compare' => $id, 'restored' => $result['restored'], 'deleted' => $result['deleted'], 'directories' => $result['deleted_directories'], 'emergency' => $emergency['id'] );
        wp_safe_redirect( self::url( $args ) ); exit;
    }

    public static function recover_item() {
        self::require_cap();
        $id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
        $path = isset( $_POST['path'] ) ? sanitize_text_field( wp_unslash( $_POST['path'] ) ) : '';
        $action = isset( $_POST['recover_action'] ) ? sanitize_key( $_POST['recover_action'] ) : '';
        check_admin_referer( 'wpes_recover_item_' . $id . '_' . $path . '_' . $action );
        $emergency = WPES_Snapshot::create( 'pre-recovery', true, false );
        if ( empty( $emergency['archive']['enabled'] ) ) { wp_safe_redirect( self::url( array( 'compare' => $id, 'message' => 'item_recovery_error' ) ) ); exit; }
        $result = WPES_Snapshot::recover_item( $id, $path, $action );
        WPES_Snapshot::enforce_retention();
        wp_safe_redirect( self::url( array( 'compare' => $id, 'message' => is_wp_error( $result ) ? 'item_recovery_error' : 'item_recovered', 'emergency' => $emergency['id'] ) ) ); exit;
    }

    private static function url( $args = array() ) { return add_query_arg( $args, admin_url( 'tools.php?page=wp-environment-snapshot' ) ); }
    private static function badges( $summary ) { foreach ( array( 'critical', 'high', 'warning', 'info' ) as $level ) if ( ! empty( $summary[ $level ] ) ) echo '<span class="wpes-badge wpes-badge-' . esc_attr( $level ) . '">' . esc_html( ucfirst( $level ) . ': ' . $summary[ $level ] ) . '</span> '; }
    private static function recovery_count( $analysis ) { return array_sum( array( $analysis['summary']['modified'], $analysis['summary']['missing'], $analysis['summary']['added'], $analysis['summary']['added_directories'] ) ); }

    public static function page() {
        self::notice();
        $settings = get_option( 'wpes_settings', array( 'interval' => '12', 'retention' => 30, 'enabled' => 1 ) );
        $snapshots = WPES_Snapshot::get_all();
        $compare = isset( $_GET['compare'] ) ? WPES_Snapshot::get( sanitize_text_field( wp_unslash( $_GET['compare'] ) ) ) : null;
        $next = wp_next_scheduled( 'wpes_scheduled_snapshot' );
        $latest = ! empty( $snapshots ) ? $snapshots[0] : null;
        $latest_analysis = $latest ? WPES_Snapshot::recovery_analysis( $latest['id'] ) : null;
        ?>
        <div class="wrap wpes-wrap">
            <h1>WP Environment Snapshot</h1>
            <p class="wpes-lead">Detect changes, investigate incidents, and recover monitored files from a known-good snapshot.</p>

            <div class="wpes-flow">
                <div class="wpes-flow-step"><span>1</span><strong>Detect</strong><small>Automatic snapshots</small></div>
                <div class="wpes-flow-arrow">→</div>
                <div class="wpes-flow-step"><span>2</span><strong>Investigate</strong><small>See what changed</small></div>
                <div class="wpes-flow-arrow">→</div>
                <div class="wpes-flow-step"><span>3</span><strong>Recover</strong><small>Restore only what changed</small></div>
            </div>

            <div class="wpes-grid wpes-top-grid">
                <div class="wpes-card wpes-status-card">
                    <div class="wpes-card-heading"><h2>Detect</h2><span class="wpes-status <?php echo ! empty( $settings['enabled'] ) ? 'is-on' : 'is-off'; ?>"><?php echo ! empty( $settings['enabled'] ) ? 'Monitoring active' : 'Monitoring disabled'; ?></span></div>
                    <div class="wpes-status-row"><strong>Last snapshot</strong><span><?php echo $latest ? esc_html( wp_date( 'Y-m-d H:i:s', $latest['created'] ) ) : 'None yet'; ?></span></div>
                    <div class="wpes-status-row"><strong>Next snapshot</strong><span><?php echo $next ? esc_html( wp_date( 'Y-m-d H:i:s', $next ) ) : 'Not scheduled'; ?></span></div>
                    <div class="wpes-status-row"><strong>Interval</strong><span>Every <?php echo absint( $settings['interval'] ); ?> hours</span></div>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="wpes_create_snapshot"><?php wp_nonce_field( 'wpes_create_snapshot' ); ?><button class="button button-primary" type="submit">Create Snapshot Now</button></form>
                </div>
                <div class="wpes-card wpes-recovery-card">
                    <div class="wpes-card-heading"><h2>Recover</h2><span class="wpes-trust">Known-good recovery</span></div>
                    <p>Recovery is targeted: <strong>unchanged files are skipped</strong>. Modified or missing known-good files are restored, and post-snapshot additions can be removed.</p>
                    <ul class="wpes-check-list"><li>Emergency snapshot before recovery</li><li>Archive integrity checked before restore</li><li>Staged restore before commit</li><li>Post-recovery verification</li></ul>
                    <?php if ( $latest && ! empty( $latest['archive']['enabled'] ) ) : ?><a class="button" href="<?php echo esc_url( self::url( array( 'compare' => $latest['id'] ) ) ); ?>">Open Latest Investigation</a><?php endif; ?>
                </div>
            </div>

            <?php if ( $latest_analysis && ! is_wp_error( $latest_analysis ) ) : ?>
            <div class="wpes-card wpes-detect-card">
                <div class="wpes-card-heading"><h2>Latest Snapshot Changes</h2><a href="<?php echo esc_url( self::url( array( 'compare' => $latest['id'] ) ) ); ?>">View investigation →</a></div>
                <div class="wpes-metrics">
                    <div><strong><?php echo esc_html( $latest_analysis['summary']['modified'] ); ?></strong><span>Modified</span></div>
                    <div><strong><?php echo esc_html( $latest_analysis['summary']['missing'] ); ?></strong><span>Missing</span></div>
                    <div><strong><?php echo esc_html( $latest_analysis['summary']['added'] ); ?></strong><span>New files</span></div>
                    <div><strong><?php echo esc_html( $latest_analysis['summary']['added_directories'] ); ?></strong><span>New folders</span></div>
                </div>
            </div>
            <?php endif; ?>

            <div class="wpes-card">
                <div class="wpes-card-heading"><h2>Monitoring Settings</h2><span>Retention: <?php echo absint( $settings['retention'] ); ?> snapshots</span></div>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wpes-settings"><input type="hidden" name="action" value="wpes_save_settings"><?php wp_nonce_field( 'wpes_save_settings' ); ?><label><input type="checkbox" name="enabled" value="1" <?php checked( ! empty( $settings['enabled'] ) ); ?>> Enable automatic snapshots</label><label>Interval <input type="number" name="interval" min="1" max="168" value="<?php echo esc_attr( $settings['interval'] ); ?>"> hours</label><label>Keep <input type="number" name="retention" min="2" max="100" value="<?php echo esc_attr( $settings['retention'] ); ?>"> snapshots</label><?php submit_button( 'Save Settings', 'secondary', 'submit', false ); ?></form>
            </div>

            <div class="wpes-card">
                <div class="wpes-card-heading"><h2>Known-Good Snapshots</h2><span>Choose a snapshot as the recovery point</span></div>
                <?php if ( empty( $snapshots ) ) : ?><p>No snapshots yet. Create one to establish the first baseline.</p><?php else : ?>
                <table class="widefat striped wpes-snapshots"><thead><tr><th>Date</th><th>Source</th><th>Changes</th><th>Risk</th><th>Archive</th><th>Actions</th></tr></thead><tbody>
                <?php foreach ( $snapshots as $snapshot ) : $summary = $snapshot['summary']; ?>
                    <tr><td><strong><?php echo esc_html( wp_date( 'Y-m-d H:i:s', $snapshot['created'] ) ); ?></strong></td><td><?php echo esc_html( ucfirst( $snapshot['source'] ) ); ?></td><td><?php echo esc_html( array_sum( $summary ) ); ?></td><td><?php self::badges( $summary ); ?></td><td><?php echo ! empty( $snapshot['archive']['enabled'] ) ? esc_html( number_format_i18n( $snapshot['archive']['files'] ) . ' files / ' . size_format( $snapshot['archive']['bytes'] ) ) : 'No archive'; ?></td><td class="wpes-actions"><a class="button" href="<?php echo esc_url( self::url( array( 'compare' => $snapshot['id'] ) ) ); ?>">Investigate</a><?php if ( ! empty( $snapshot['archive']['enabled'] ) ) : ?><button type="button" class="button button-primary" onclick="document.getElementById('wpes-restore-<?php echo esc_attr( $snapshot['id'] ); ?>').classList.toggle('is-open')">Recover</button><?php endif; ?> <a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpes_delete_snapshot&id=' . rawurlencode( $snapshot['id'] ) ), 'wpes_delete_' . $snapshot['id'] ) ); ?>" onclick="return confirm('Delete this snapshot and its archive?')">Delete</a></td></tr>
                    <?php if ( ! empty( $snapshot['archive']['enabled'] ) ) : ?><tr><td colspan="6"><div id="wpes-restore-<?php echo esc_attr( $snapshot['id'] ); ?>" class="wpes-restore-panel"><strong>Recovery options</strong><p>Only missing or modified known-good files are restored. Unchanged files are skipped.</p><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="wpes_restore_snapshot"><input type="hidden" name="id" value="<?php echo esc_attr( $snapshot['id'] ); ?>"><?php wp_nonce_field( 'wpes_restore_' . $snapshot['id'] ); ?><select name="scope"><option value="all">All monitored files</option><option value="core">WordPress core</option><option value="plugins">Plugins</option><option value="themes">Themes</option><option value="mu-plugins">MU plugins</option><option value="configuration">Configuration</option></select><label class="wpes-cleanup"><input type="checkbox" name="cleanup" value="1"> Remove files and folders added after this snapshot</label><button class="button button-primary" type="submit" onclick="return confirm('An emergency snapshot will be created first. Recovery will restore only changed or missing known-good files. If cleanup is enabled, post-snapshot additions will be deleted. Continue?')">Start Recovery</button></form></div></td></tr><?php endif; ?>
                <?php endforeach; ?></tbody></table><?php endif; ?>
            </div>

            <?php if ( $compare ) : self::render_investigation( $compare ); endif; ?>

            <div class="wpes-card wpes-footer-settings"><h2>Known-Good State</h2><p>Resetting the baseline causes the next snapshot to establish a new starting point. Existing reports remain.</p><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="wpes_reset_baseline"><?php wp_nonce_field( 'wpes_reset_baseline' ); ?><?php submit_button( 'Reset Baseline', 'secondary', 'submit', false ); ?></form></div>
        </div>
        <?php
    }

    private static function render_investigation( $snapshot ) {
        $analysis = WPES_Snapshot::recovery_analysis( $snapshot['id'] );
        echo '<div class="wpes-card wpes-investigation"><div class="wpes-card-heading"><h2>Investigate → Recover</h2><span>Known-good: ' . esc_html( wp_date( 'Y-m-d H:i:s', $snapshot['created'] ) ) . '</span></div>';
        if ( is_wp_error( $analysis ) ) { echo '<div class="notice notice-error"><p>' . esc_html( $analysis->get_error_message() ) . '</p></div></div>'; return; }
        $s = $analysis['summary'];
        echo '<p class="wpes-recovery-intro">This is a recovery preview. The plugin will leave unchanged files untouched and restore only files that are missing or different from this snapshot.</p>';
        echo '<div class="wpes-metrics wpes-preview-metrics"><div><strong>' . esc_html( $s['modified'] ) . '</strong><span>Restore: modified</span></div><div><strong>' . esc_html( $s['missing'] ) . '</strong><span>Restore: missing</span></div><div><strong>' . esc_html( $s['added'] ) . '</strong><span>Remove: new files</span></div><div><strong>' . esc_html( $s['added_directories'] ) . '</strong><span>Remove: new folders</span></div></div>';
        if ( empty( $analysis['items'] ) ) { echo '<div class="wpes-safe-message">✓ Current monitored files match this known-good snapshot. No recovery is required.</div>'; }
        else {
            echo '<table class="widefat striped wpes-preview-table"><thead><tr><th>Path</th><th>Detected state</th><th>Recovery action</th></tr></thead><tbody>';
            foreach ( $analysis['items'] as $item ) {
                $change = $item['change']; $label = ucfirst( $change ); $action = 'No action';
                if ( in_array( $change, array( 'modified', 'missing' ), true ) && 'file' === $item['type'] ) $action = '<span class="wpes-action-restore">Restore known-good file</span>';
                elseif ( 'added' === $change ) $action = '<span class="wpes-action-delete">Remove post-snapshot ' . ( 'directory' === $item['type'] ? 'folder' : 'file' ) . '</span>';
                echo '<tr><td><code>' . esc_html( $item['path'] ) . '</code></td><td>' . esc_html( $label ) . '</td><td>' . $action . ' ';
                if ( in_array( $change, array( 'modified', 'missing' ), true ) && 'file' === $item['type'] ) self::item_form( $snapshot['id'], $item['path'], 'restore', 'Restore' );
                elseif ( 'added' === $change ) self::item_form( $snapshot['id'], $item['path'], 'delete', 'Remove' );
                echo '</td></tr>';
            }
            echo '</tbody></table>';
            echo '<div class="wpes-recovery-action"><div><strong>Ready for recovery?</strong><p>Create an emergency snapshot, restore only the changed/missing known-good files, optionally remove post-snapshot additions, then verify the result.</p></div><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="wpes_restore_snapshot"><input type="hidden" name="id" value="' . esc_attr( $snapshot['id'] ) . '"><input type="hidden" name="scope" value="all"><input type="hidden" name="cleanup" value="1">' . wp_nonce_field( 'wpes_restore_' . $snapshot['id'], '_wpnonce', true, false ) . '<button class="button button-primary button-hero" type="submit" onclick="return confirm(\'An emergency snapshot will be created first. This will restore changed/missing files and remove post-snapshot additions. Continue?\')">Restore &amp; Remove Post-Snapshot Changes</button></form></div>';
        }
        echo '<p class="description wpes-safety-note">A detected change is not automatically malicious. This recovery tool operates only on monitored files and creates an emergency snapshot before destructive actions. wp-config.php is protected from automatic deletion.</p></div>';
    }

    private static function item_form( $id, $path, $action, $label ) {
        echo '<form class="wpes-inline-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="wpes_recover_item"><input type="hidden" name="id" value="' . esc_attr( $id ) . '"><input type="hidden" name="path" value="' . esc_attr( $path ) . '"><input type="hidden" name="recover_action" value="' . esc_attr( $action ) . '">' . wp_nonce_field( 'wpes_recover_item_' . $id . '_' . $path . '_' . $action, '_wpnonce', true, false ) . '<button class="button" type="submit" onclick="return confirm(\'' . esc_js( 'A pre-recovery emergency snapshot will be created first. Continue?' ) . '\')">' . esc_html( $label ) . '</button></form>';
    }

    private static function notice() {
        if ( empty( $_GET['message'] ) ) return;
        $m = sanitize_key( wp_unslash( $_GET['message'] ) );
        $text = array(
            'created' => 'Snapshot created successfully.', 'deleted' => 'Snapshot and archive deleted.', 'settings' => 'Monitoring settings saved.', 'reset' => 'Known-good state reset. The next snapshot will establish a new starting point.',
            'restored' => 'Recovery completed and verification passed.', 'restore_warning' => 'Recovery completed with warnings. Review the investigation report and verification status.', 'restore_error' => 'Recovery was stopped or failed before completion.',
            'item_recovered' => 'Recovery action completed. A pre-recovery emergency snapshot was created first.', 'item_recovery_error' => 'The requested recovery action could not be completed.'
        );
        if ( isset( $text[ $m ] ) ) echo '<div class="notice ' . ( in_array( $m, array( 'restore_error', 'restore_warning', 'item_recovery_error' ), true ) ? 'notice-warning' : 'notice-success' ) . ' is-dismissible"><p>' . esc_html( $text[ $m ] ) . '</p></div>';
    }
}
