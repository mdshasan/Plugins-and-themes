<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }
$keys = array( 'wpes_settings', 'wpes_current_state', 'wpes_file_baseline', 'wpes_snapshots', 'wpes_last_snapshot' );
foreach ( $keys as $key ) { delete_option( $key ); }
$upload = wp_upload_dir();
$dir = trailingslashit( $upload['basedir'] ) . 'wpes-archives';
if ( is_dir( $dir ) ) {
    $it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
    foreach ( $it as $file ) { $file->isDir() ? @rmdir( $file->getPathname() ) : @unlink( $file->getPathname() ); }
    @rmdir( $dir );
}
