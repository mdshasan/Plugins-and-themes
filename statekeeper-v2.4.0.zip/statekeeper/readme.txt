=== StateKeeper ===
Contributors: ms-hasan
Tags: monitoring, snapshots, change detection, recovery, security
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 2.4.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Detect, investigate, and recover important WordPress environment changes with scheduled snapshots and local file archives.

* Recovery restores only missing or modified files from a known-good snapshot; unchanged files are skipped.
* Optional one-click cleanup removes monitored files and directories that were added after the selected known-good snapshot, within the selected recovery scope.
* Every recovery creates a pre-restore emergency snapshot first.

== Description ==
WP Environment Snapshot records WordPress environment state and detects changes between snapshots. It can also create local archives of monitored PHP/configuration files so an administrator can restore files from a known-good snapshot.

Monitors include:
* WordPress/PHP/environment information
* Plugin and theme installation, removal, activation and version changes
* User creation/removal, role changes, administrator creation and email-change detection without storing the email address
* Important WordPress options
* Database table/schema fingerprints
* WP-Cron events (the plugin's own scheduled snapshot event is excluded from incident reports)
* PHP files and directory structure in WordPress core, plugins, themes and MU plugins
* wp-config.php and .htaccess fingerprints

Recovery features:
* Local snapshot archive of monitored files
* Known-good snapshot restore
* Restore scope for core, plugins, themes, MU plugins, configuration, or all monitored files
* Automatic pre-restore emergency snapshot
* Optional one-click removal of post-snapshot monitored files and directories
* Snapshot archive cleanup follows retention

Uploads are excluded from recursive scanning and archiving for performance and safety. Post/page changes are not monitored.

== Important security note ==
This plugin is an incident-response aid, not an antivirus and not a replacement for off-site backups. A server-level compromise can potentially modify or delete local snapshots. Keep independent backups and use hosting/server logs to investigate the original entry vector.

Recovery restores only missing or modified monitored files from the selected known-good snapshot; unchanged files are skipped. With cleanup enabled, monitored files and directories that were added after the selected snapshot are removed within the selected recovery scope. Because this can remove legitimate changes made after the snapshot, cleanup requires an explicit administrator action and a pre-restore emergency snapshot is created first.

== Privacy ==
No external service is required. User email addresses are represented by SHA-256 hashes rather than stored as plaintext. wp-config.php contents are not stored as database state; its file archive is kept locally only when snapshot archiving succeeds.
