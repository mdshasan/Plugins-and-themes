<?php
/**
 * Plugin Name: StateKeeper
 * Description: Automatically monitors important WordPress environment, database, and PHP file changes to help investigate broken sites and security incidents.
 * Version: 2.4.0
 * Author: MS Hasan
 * License: GPL-2.0-or-later
 * Text Domain: statekeeper
 * Requires at least: 6.4
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'WPES_VERSION', '2.4.0' );
define( 'WPES_FILE', __FILE__ );
define( 'WPES_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPES_URL', plugin_dir_url( __FILE__ ) );

require_once WPES_DIR . 'includes/class-wpes-snapshot.php';
require_once WPES_DIR . 'includes/class-wpes-files.php';
require_once WPES_DIR . 'includes/class-wpes-admin.php';

register_activation_hook( __FILE__, 'wpes_activate' );
register_deactivation_hook( __FILE__, 'wpes_deactivate' );

/**
 * Load plugin text domain for translations.
 */
function wpes_load_textdomain() {
    load_plugin_textdomain( 'statekeeper', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'plugins_loaded', 'wpes_load_textdomain' );

/**
 * Register the custom cron recurrence schedules on every request so that
 * WP-Cron can resolve the interval when it fires outside of activation or
 * settings-save requests.
 *
 * @param array $schedules Existing cron schedules.
 * @return array
 */
function wpes_cron_schedules( $schedules ) {
    $settings = get_option( 'wpes_settings', array() );
    $hours    = isset( $settings['interval'] ) ? (int) $settings['interval'] : 12;
    $hours    = max( 1, min( 168, $hours ) );
    $key      = 'wpes_every_' . $hours . '_hours';

    if ( ! isset( $schedules[ $key ] ) ) {
        $schedules[ $key ] = array(
            'interval' => $hours * HOUR_IN_SECONDS,
            /* translators: %d: number of hours */
            'display'  => sprintf( __( 'Every %d hours', 'statekeeper' ), $hours ),
        );
    }

    return $schedules;
}
add_filter( 'cron_schedules', 'wpes_cron_schedules' );

function wpes_activate() {
    if ( false === get_option( 'wpes_settings', false ) ) {
        add_option(
            'wpes_settings',
            array(
                'interval'  => '12',
                'retention' => 30,
                'enabled'   => 1,
            ),
            '',
            false
        );
    }

    if ( false === get_option( 'wpes_file_baseline', false ) ) {
        add_option( 'wpes_file_baseline', array(), '', false );
    }

    if ( false === get_option( 'wpes_snapshots', false ) ) {
        add_option( 'wpes_snapshots', array(), '', false );
    }

    wpes_schedule_event();
}

function wpes_deactivate() {
    wp_clear_scheduled_hook( 'wpes_scheduled_snapshot' );
}

function wpes_schedule_event() {
    wp_clear_scheduled_hook( 'wpes_scheduled_snapshot' );

    $settings = get_option( 'wpes_settings', array() );
    if ( empty( $settings['enabled'] ) ) {
        return;
    }

    $hours      = isset( $settings['interval'] ) ? (int) $settings['interval'] : 12;
    $hours      = max( 1, min( 168, $hours ) );
    $recurrence = 'wpes_every_' . $hours . '_hours';

    wp_schedule_event( time() + 60, $recurrence, 'wpes_scheduled_snapshot' );
}

add_action( 'wpes_scheduled_snapshot', array( 'WPES_Snapshot', 'create' ) );
add_action( 'plugins_loaded', array( 'WPES_Admin', 'init' ) );
