<?php
/**
 * Plugin Name: Hasan Client Onboarding
 * Description: Client-specific proposal, payment methods and payment verification workflow.
 * Version: 3.0.0
 * Author: Hasan
 */
if (!defined('ABSPATH')) exit;

class Hasan_Client_Onboarding {
    const CPT='hasco_client', DB='hasco_submissions';

    public function __construct(){
        add_action('init',[$this,'register_cpt']);
        add_action('admin_menu',[$this,'admin_menu']);
        add_action('add_meta_boxes',[$this,'meta_boxes']);
        add_action('save_post_'.self::CPT,[$this,'save_meta'],10,2);
        add_shortcode('hasan_client_onboarding',[$this,'shortcode']);
        add_action('wp_enqueue_scripts',[$this,'assets']);
        add_action('wp_ajax_hasco_submit',[$this,'submit']);
        add_action('wp_ajax_nopriv_hasco_submit',[$this,'submit']);
        add_action('admin_post_hasco_status',[$this,'change_status']);
        add_action('admin_post_hasco_download',[$this,'download']);
        register_activation_hook(__FILE__,[$this,'activate']);
        register_deactivation_hook(__FILE__,[$this,'deactivate']);
    }

    public function register_cpt(){
        register_post_type(self::CPT,[
            'labels'=>[
                'name'=>'Client Onboarding','singular_name'=>'Client Onboarding',
                'add_new'=>'Add New Client','add_new_item'=>'Add New Client Onboarding',
                'edit_item'=>'Edit Client Onboarding','new_item'=>'New Client Onboarding',
                'view_item'=>'View Client Onboarding','search_items'=>'Search Clients',
                'not_found'=>'No client onboardings found','menu_name'=>'Client Onboarding'
            ],
            'public'=>false,'show_ui'=>true,'show_in_menu'=>true,'menu_icon'=>'dashicons-id-alt',
            'supports'=>['title'],'capability_type'=>'post','map_meta_cap'=>true
        ]);
    }

    public function activate(){
        $this->register_cpt();
        global $wpdb;
        $t=$wpdb->prefix.self::DB; $charset=$wpdb->get_charset_collate();
        $sql="CREATE TABLE $t (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        onboarding_id bigint(20) unsigned NOT NULL,
        client varchar(190) NOT NULL, project varchar(190) NOT NULL, amount varchar(50) NOT NULL,
        method varchar(100) NOT NULL, transaction_id varchar(190) NOT NULL, decision varchar(30) NOT NULL,
        revision_note text NOT NULL, screenshot_id bigint(20) unsigned NOT NULL DEFAULT 0,
        status varchar(30) NOT NULL DEFAULT 'pending', submitted_at datetime NOT NULL,
        PRIMARY KEY(id), KEY onboarding_id(onboarding_id), KEY status(status)
        ) $charset;";
        require_once ABSPATH.'wp-admin/includes/upgrade.php'; dbDelta($sql);
        flush_rewrite_rules();
    }
    public function deactivate(){flush_rewrite_rules();}

    private function defaults(){return [
        'client'=>'','project'=>'Website Redesign','total'=>'3500','deposit'=>'1750','balance'=>'1750','currency'=>'USD','timeline'=>'3–4 weeks',
        'email'=>get_option('admin_email'),'proposal_pdf_url'=>'','payment_intro'=>'Choose one payment method below to complete your initial deposit.',
        'wire_enabled'=>1,'wire_title'=>'Wire Transfer','wire_description'=>'Send the initial deposit by bank wire using the details below.',
        'bank_name'=>'Demo Bank','account_name'=>'Hasan Web Services','account_no'=>'1234567890','routing'=>'021000021','wire_link'=>'',
        'xoom_enabled'=>1,'xoom_title'=>'Xoom (PayPal)','xoom_description'=>'Use Xoom by PayPal to send your initial deposit.','xoom_link'=>'https://www.xoom.com/',
        'taptapsend_enabled'=>1,'taptapsend_title'=>'TapTap Send','taptapsend_description'=>'Use the TapTap Send app to send your initial deposit.','taptapsend_link'=>'https://www.taptapsend.com/'
    ];}

    private function get($id){
        $d=$this->defaults(); $o=[];
        foreach($d as $k=>$v){$meta=get_post_meta($id,'_hasco_'.$k,true);$o[$k]=($meta!==''?$meta:$v);}
        return $o;
    }

    public function admin_menu(){
        add_submenu_page('edit.php?post_type='.self::CPT,'Payment Submissions','Payment Submissions','manage_options','hasco-submissions',[$this,'submissions_page']);
    }

    public function meta_boxes(){
        add_meta_box('hasco_client_details','Client & Project Details',[$this,'details_box'],self::CPT,'normal','high');
        add_meta_box('hasco_payment_methods','Payment Methods',[$this,'payment_box'],self::CPT,'normal','default');
        add_meta_box('hasco_shortcode','Client Shortcode',[$this,'shortcode_box'],self::CPT,'side','high');
    }

    private function field($k,$label,$value,$type='text'){
        echo '<p><label><strong>'.esc_html($label).'</strong></label><br><input style="width:100%" type="'.esc_attr($type).'" name="hasco['.esc_attr($k).']" value="'.esc_attr($value).'"></p>';
    }
    private function area($k,$label,$value){
        echo '<p><label><strong>'.esc_html($label).'</strong></label><br><textarea style="width:100%" rows="3" name="hasco['.esc_attr($k).']">'.esc_textarea($value).'</textarea></p>';
    }
    private function check($k,$label,$value){
        echo '<p><label><input type="checkbox" name="hasco['.esc_attr($k).']" value="1" '.checked($value,1,false).'> '.esc_html($label).'</label></p>';
    }

    public function details_box($post){
        wp_nonce_field('hasco_save','hasco_nonce'); $s=$this->get($post->ID);
        echo '<p>All fields below belong only to this client. Create a new Client Onboarding record for another client.</p>';
        $this->field('client','Client / Company',$s['client']);$this->field('project','Project Name',$s['project']);
        $this->field('total','Total Project Price',$s['total']);$this->field('deposit','Initial Deposit',$s['deposit']);$this->field('balance','Remaining Balance',$s['balance']);
        $this->field('currency','Currency',$s['currency']);$this->field('timeline','Estimated Timeline',$s['timeline']);
        $this->field('email','Payment Verification Email',$s['email'],'email');$this->field('proposal_pdf_url','Proposal PDF URL',$s['proposal_pdf_url'],'url');
        $this->area('payment_intro','Payment Introduction',$s['payment_intro']);
    }

    public function payment_box($post){
        $s=$this->get($post->ID);
        echo '<h3>Wire Transfer</h3>'; $this->check('wire_enabled','Show Wire Transfer',$s['wire_enabled']);
        $this->field('wire_title','Title',$s['wire_title']);$this->area('wire_description','Description',$s['wire_description']);
        $this->field('bank_name','Bank Name',$s['bank_name']);$this->field('account_name','Account Name',$s['account_name']);
        $this->field('account_no','Account Number',$s['account_no']);$this->field('routing','Routing / SWIFT',$s['routing']);$this->field('wire_link','Wire Instructions Link',$s['wire_link'],'url');
        echo '<hr><h3>Xoom (PayPal)</h3>'; $this->check('xoom_enabled','Show Xoom (PayPal)',$s['xoom_enabled']);
        $this->field('xoom_title','Title',$s['xoom_title']);$this->area('xoom_description','Description',$s['xoom_description']);$this->field('xoom_link','Xoom Website / Payment Link',$s['xoom_link'],'url');
        echo '<hr><h3>TapTap Send</h3>'; $this->check('taptapsend_enabled','Show TapTap Send',$s['taptapsend_enabled']);
        $this->field('taptapsend_title','Title',$s['taptapsend_title']);$this->area('taptapsend_description','Description',$s['taptapsend_description']);$this->field('taptapsend_link','TapTap Send Website / App Link',$s['taptapsend_link'],'url');
    }

    public function shortcode_box($post){
        echo '<p>Put this shortcode on the client onboarding page:</p><input readonly style="width:100%" value="[hasan_client_onboarding id=&quot;'.esc_attr($post->ID).'&quot;]"><p><small>Each client has a separate record and separate settings.</small></p>';
    }

    public function save_meta($post_id,$post){
        if(!isset($_POST['hasco_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hasco_nonce'])),'hasco_save'))return;
        if(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE)return;
        if(!current_user_can('edit_post',$post_id))return;
        $in=isset($_POST['hasco'])?(array)$_POST['hasco']:[];
        $d=$this->defaults();
        foreach($d as $k=>$default){
            if(in_array($k,['proposal_pdf_url','wire_link','xoom_link','taptapsend_link'],true))
                $v=isset($in[$k])?esc_url_raw(wp_unslash($in[$k])):'';
            elseif(in_array($k,['wire_enabled','xoom_enabled','taptapsend_enabled'],true))
                $v=!empty($in[$k])?'1':'0';
            elseif(in_array($k,['payment_intro','wire_description','xoom_description','taptapsend_description'],true))
                $v=isset($in[$k])?sanitize_textarea_field(wp_unslash($in[$k])):'';
            elseif(in_array($k,['total','deposit','balance'],true))
                $v=isset($in[$k])?preg_replace('/[^0-9.\-]/','',wp_unslash($in[$k])):'';
            elseif($k==='email')
                $v=isset($in[$k])&&is_email(sanitize_email(wp_unslash($in[$k])))?sanitize_email(wp_unslash($in[$k])):get_option('admin_email');
            else $v=isset($in[$k])?sanitize_text_field(wp_unslash($in[$k])):'';
            update_post_meta($post_id,'_hasco_'.$k,$v);
        }
    }

    public function assets(){
        wp_register_style('hasco-style',plugins_url('assets/css/style.css',__FILE__),[],'3.0.0');
        wp_register_script('hasco-script',plugins_url('assets/js/script.js',__FILE__),['jquery'],'3.0.0',true);
        wp_localize_script('hasco-script','hascoData',['ajaxUrl'=>admin_url('admin-ajax.php')]);
    }

    public function shortcode($atts){
        $atts=shortcode_atts(['id'=>0],$atts,'hasan_client_onboarding'); $id=absint($atts['id']);
        if(!$id||get_post_type($id)!==self::CPT)return '<p>Client onboarding record not found.</p>';
        $s=$this->get($id); wp_enqueue_style('hasco-style');wp_enqueue_script('hasco-script');
        $methods=[];
        if($s['wire_enabled'])$methods[]=['id'=>'wire','title'=>$s['wire_title'],'description'=>$s['wire_description'],'link'=>$s['wire_link']];
        if($s['xoom_enabled'])$methods[]=['id'=>'xoom','title'=>$s['xoom_title'],'description'=>$s['xoom_description'],'link'=>$s['xoom_link']];
        if($s['taptapsend_enabled'])$methods[]=['id'=>'taptapsend','title'=>$s['taptapsend_title'],'description'=>$s['taptapsend_description'],'link'=>$s['taptapsend_link']];
        ob_start(); ?>
        <div class="hasco-wrap"><div class="hasco-card"><div class="hasco-head"><span class="hasco-kicker">CLIENT PROJECT PORTAL</span><h2><?php echo esc_html($s['project']);?></h2><p><?php echo esc_html($s['client']);?></p></div>
        <div class="hasco-steps"><div class="hasco-step is-active" data-step="1"><b>1</b><span>Decision</span></div><div class="hasco-line"></div><div class="hasco-step" data-step="2"><b>2</b><span>Payment</span></div><div class="hasco-line"></div><div class="hasco-step" data-step="3"><b>3</b><span>Verification</span></div></div>
        <form id="hasco-form-<?php echo esc_attr($id);?>" class="hasco-form" enctype="multipart/form-data"><input type="hidden" name="action" value="hasco_submit"><input type="hidden" name="nonce" value="<?php echo esc_attr(wp_create_nonce('hasco_nonce'));?>">
        <input type="hidden" name="onboarding_id" value="<?php echo esc_attr($id);?>"><input type="hidden" name="client" value="<?php echo esc_attr($s['client']);?>"><input type="hidden" name="project" value="<?php echo esc_attr($s['project']);?>"><input type="hidden" name="amount" value="<?php echo esc_attr($s['deposit']);?>">
        <section class="hasco-panel is-active" data-panel="1"><h3>Review your proposal</h3><p>Review the proposal before choosing whether to accept it or request a revision.</p>
        <?php if(!empty($s['proposal_pdf_url'])): ?><p class="hasco-proposal-link"><a class="hasco-view-proposal" href="<?php echo esc_url($s['proposal_pdf_url']);?>" target="_blank" rel="noopener noreferrer">View Proposal ↗</a></p><?php endif;?>
        <div class="hasco-summary"><div><span>Project</span><strong><?php echo esc_html($s['project']);?></strong></div><div><span>Total Investment</span><strong><?php echo esc_html($s['currency'].' '.$s['total']);?></strong></div><div><span>Initial Deposit</span><strong><?php echo esc_html($s['currency'].' '.$s['deposit']);?></strong></div><div><span>Estimated Timeline</span><strong><?php echo esc_html($s['timeline']);?></strong></div></div>
        <div class="hasco-options"><label class="hasco-option"><input type="radio" name="decision" value="accept"><span><strong>Accept Proposal</strong><small>I approve the scope and would like to proceed.</small></span></label>
        <label class="hasco-option"><input type="radio" name="decision" value="revision"><span><strong>Request Revision</strong><small>I would like changes before proceeding.</small></span></label></div>
        <textarea name="revision_note" placeholder="If requesting a revision, briefly tell us what you'd like changed."></textarea><button type="button" class="hasco-btn" data-next="2">Continue</button></section>
        <section class="hasco-panel" data-panel="2"><h3>Complete your initial payment</h3><p><?php echo esc_html($s['payment_intro']);?></p><div class="hasco-payment-box"><div class="hasco-amount"><?php echo esc_html($s['currency'].' '.$s['deposit']);?></div><p><strong>Initial Deposit</strong></p>
        <?php foreach($methods as $m): ?><label class="hasco-method"><input type="radio" name="payment_method" value="<?php echo esc_attr($m['id']);?>"><span><strong><?php echo esc_html($m['title']);?></strong><small><?php echo esc_html($m['description']);?></small><?php if($m['link']):?><a href="<?php echo esc_url($m['link']);?>" target="_blank" rel="noopener noreferrer">Open payment / instructions ↗</a><?php endif;?></span></label><?php endforeach;?>
        <?php if($s['wire_enabled']): ?><div class="hasco-wire-details"><h4>Wire Transfer Details</h4><p><b>Bank:</b> <?php echo esc_html($s['bank_name']);?></p><p><b>Account Name:</b> <?php echo esc_html($s['account_name']);?></p><p><b>Account Number:</b> <?php echo esc_html($s['account_no']);?></p><p><b>Routing / SWIFT:</b> <?php echo esc_html($s['routing']);?></p><?php if($s['wire_link']):?><a href="<?php echo esc_url($s['wire_link']);?>" target="_blank" rel="noopener noreferrer">Open wire instructions ↗</a><?php endif;?></div><?php endif;?>
        <p class="hasco-note">Choose the payment method you used before continuing.</p></div><div class="hasco-actions"><button type="button" class="hasco-back" data-back="1">Back</button><button type="button" class="hasco-btn" data-next="3">I've Completed Payment</button></div></section>
        <section class="hasco-panel" data-panel="3"><h3>Submit payment for verification</h3><p>Send your transaction/reference ID and payment screenshot. Submission does not mean payment has already been confirmed.</p>
        <label>Transaction / Reference ID<input type="text" name="transaction_id" required placeholder="e.g. TXN-123456"></label><label>Payment Screenshot<input type="file" name="payment_screenshot" accept="image/jpeg,image/png,image/webp,application/pdf"></label>
        <label class="hasco-check"><input type="checkbox" name="confirm_info" value="1" required><span>I confirm that the information submitted is accurate.</span></label>
        <div class="hasco-actions"><button type="button" class="hasco-back" data-back="2">Back</button><button type="submit" class="hasco-btn">Submit for Verification</button></div><div class="hasco-message" aria-live="polite"></div></section></form>
        <div class="hasco-success"><div class="hasco-success-icon">✓</div><h3>Payment submitted successfully</h3><p>Your payment information has been submitted for verification.</p><p><strong>After your payment is positively verified, you will receive your private client-dashboard login credentials.</strong></p></div>
        <div class="hasco-footer">Need help? <a href="mailto:<?php echo esc_attr($s['email']);?>"><?php echo esc_html($s['email']);?></a></div></div></div>
        <?php return ob_get_clean();
    }

    public function submit(){
        if(empty($_POST['nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])),'hasco_nonce'))wp_send_json_error(['message'=>'Security check failed.'],403);
        $oid=absint($_POST['onboarding_id']??0);
        if(!$oid||get_post_type($oid)!==self::CPT)wp_send_json_error(['message'=>'Invalid onboarding record.'],400);
        $s=$this->get($oid);
        $transaction=sanitize_text_field(wp_unslash($_POST['transaction_id']??''));$method=sanitize_text_field(wp_unslash($_POST['payment_method']??''));$decision=sanitize_text_field(wp_unslash($_POST['decision']??''));$revision=sanitize_textarea_field(wp_unslash($_POST['revision_note']??''));
        if(!$transaction||!$method||empty($_POST['confirm_info']))wp_send_json_error(['message'=>'Please complete the required fields.']);
        global $wpdb;$table=$wpdb->prefix.self::DB;$sid=0;
        if(!empty($_FILES['payment_screenshot']['name'])){
            $f=$_FILES['payment_screenshot'];if(!empty($f['error']))wp_send_json_error(['message'=>'The screenshot could not be uploaded.']);
            if($f['size']>5*1024*1024)wp_send_json_error(['message'=>'Screenshot/file must be 5 MB or smaller.']);
            $check=wp_check_filetype_and_ext($f['tmp_name'],$f['name']);$allowed=['jpg','jpeg','png','webp','pdf'];
            if(empty($check['ext'])||!in_array(strtolower($check['ext']),$allowed,true))wp_send_json_error(['message'=>'Only JPG, PNG, WEBP or PDF files are allowed.']);
            require_once ABSPATH.'wp-admin/includes/file.php';
            $up=wp_handle_upload($f,['test_form'=>false,'unique_filename_callback'=>function($dir,$name,$ext){return 'hasco-'.wp_generate_password(24,false,false).$ext;}]);
            if(!empty($up['error']))wp_send_json_error(['message'=>'File upload failed.']);
            $att=['post_mime_type'=>$up['type'],'post_title'=>'Payment proof '.$transaction,'post_content'=>'','post_status'=>'private'];$sid=wp_insert_attachment($att,$up['file']);
            if($sid&&!is_wp_error($sid)){require_once ABSPATH.'wp-admin/includes/image.php';wp_update_attachment_metadata($sid,wp_generate_attachment_metadata($sid,$up['file']));}else $sid=0;
        }
        $wpdb->insert($table,['onboarding_id'=>$oid,'client'=>$s['client'],'project'=>$s['project'],'amount'=>$s['deposit'],'method'=>$method,'transaction_id'=>$transaction,'decision'=>$decision,'revision_note'=>$revision,'screenshot_id'=>$sid,'status'=>'pending','submitted_at'=>current_time('mysql')],['%d','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s']);
        wp_mail($s['email'],'New Payment Verification - '.$s['client'],"New payment verification submission.\n\nClient: ".$s['client']."\nProject: ".$s['project']."\nAmount: ".$s['deposit']."\nMethod: ".$method."\nTransaction ID: ".$transaction."\nDecision: ".$decision."\nRevision note: ".$revision."\nProof uploaded: ".($sid?'Yes':'No'));
        wp_send_json_success();
    }

    public function submissions_page(){
        if(!current_user_can('manage_options'))return;global $wpdb;$t=$wpdb->prefix.self::DB;$rows=$wpdb->get_results("SELECT * FROM $t ORDER BY submitted_at DESC LIMIT 200"); ?>
        <div class="wrap"><h1>Payment Submissions</h1><p>Submissions are linked to their specific Client Onboarding record.</p>
        <table class="widefat striped"><thead><tr><th>ID</th><th>Client</th><th>Project</th><th>Amount</th><th>Method</th><th>Transaction</th><th>Proof</th><th>Status</th><th>Date</th><th>Action</th></tr></thead><tbody>
        <?php if(!$rows):?><tr><td colspan="10">No submissions yet.</td></tr><?php else:foreach($rows as $r):?><tr><td><?php echo esc_html($r->id);?></td><td><?php echo esc_html($r->client);?></td><td><?php echo esc_html($r->project);?></td><td><?php echo esc_html($r->amount);?></td><td><?php echo esc_html($r->method);?></td><td><code><?php echo esc_html($r->transaction_id);?></code></td><td><?php if($r->screenshot_id){$u=wp_nonce_url(admin_url('admin-post.php?action=hasco_download&id='.$r->id),'hasco_download_'.$r->id);echo '<a href="'.esc_url($u).'">View file</a>';}else echo 'None';?></td><td><strong><?php echo esc_html(ucfirst($r->status));?></strong></td><td><?php echo esc_html($r->submitted_at);?></td><td><?php if($r->status==='pending'):foreach(['approved','rejected'] as $st):?><form style="display:inline" method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><input type="hidden" name="action" value="hasco_status"><input type="hidden" name="id" value="<?php echo esc_attr($r->id);?>"><input type="hidden" name="status" value="<?php echo esc_attr($st);?>"><?php wp_nonce_field('hasco_status_'.$r->id);?><button class="button" type="submit"><?php echo esc_html(ucfirst($st));?></button></form><?php endforeach;else:?>—<?php endif;?></td></tr><?php endforeach;endif;?></tbody></table></div><?php
    }

    public function change_status(){
        if(!current_user_can('manage_options'))wp_die('Unauthorized.');$id=absint($_POST['id']??0);check_admin_referer('hasco_status_'.$id);$status=sanitize_text_field(wp_unslash($_POST['status']??''));
        if(!in_array($status,['approved','rejected'],true))wp_die('Invalid status.');
        global $wpdb;$wpdb->update($wpdb->prefix.self::DB,['status'=>$status],['id'=>$id],['%s'],['%d']);wp_safe_redirect(admin_url('edit.php?post_type='.self::CPT.'&page=hasco-submissions'));exit;
    }

    public function download(){
        if(!current_user_can('manage_options'))wp_die('Unauthorized.');$id=absint($_GET['id']??0);check_admin_referer('hasco_download_'.$id);
        global $wpdb;$r=$wpdb->get_row($wpdb->prepare("SELECT screenshot_id FROM ".$wpdb->prefix.self::DB." WHERE id=%d",$id));
        if(!$r||!$r->screenshot_id)wp_die('File not found.');$file=get_attached_file($r->screenshot_id);if(!$file||!file_exists($file))wp_die('File not found.');
        $type=wp_check_filetype($file);header('Content-Type:'.($type['type']?:'application/octet-stream'));header('Content-Disposition:inline; filename="'.basename($file).'"');header('Content-Length:'.filesize($file));readfile($file);exit;
    }
}
new Hasan_Client_Onboarding();
