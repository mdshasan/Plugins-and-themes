HASAN CLIENT ONBOARDING v3.0

This version supports multiple client-specific onboarding records.

INSTALL
1. WordPress Dashboard > Plugins > Add New > Upload Plugin.
2. Upload and activate this ZIP.

CREATE A CLIENT
1. Dashboard > Client Onboarding > Add New.
2. Enter that client's project, pricing, proposal PDF URL, email and payment methods.
3. Publish/save the client record.
4. The right-side Client Shortcode box gives a unique shortcode such as:
   [hasan_client_onboarding id="123"]
5. Put that shortcode on the private/client-specific page.

MULTIPLE CLIENTS
Create one Client Onboarding record per client. Each shortcode ID loads only that client's settings.

PAYMENT SUBMISSIONS
Payment submissions are linked to the specific onboarding record. Verify payments manually and mark them Approved or Rejected under Client Onboarding > Payment Submissions.

PROPOSAL PDF
Upload the PDF in WordPress Media, copy its URL, and paste it into the client's Proposal PDF URL field. The View Proposal button opens the PDF in a new tab.

IMPORTANT
The plugin does not automatically verify bank, Xoom or TapTap Send payments. Configure reliable SMTP for production email delivery.
